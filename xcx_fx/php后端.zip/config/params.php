<?php
/**
 * Created by PhpStorm.
 * User: 999
 * Date: 2019/9/5
 * Time: 18:56
 */
//分页配置
use think\facade\Env;

return [
    //系统用户微信公众号信息
    'user_appid'=>'', //公众号appid
    'user_appsecret'=>'', //公众号appsecret

    //微信支付相关配置
    'wechat_pay'=>[
        'appid'=>'', //当前h5用户对应的公众号appid，且必须开通了微信支付
        'mchid'=>'', //商户号
        'key'=>'', //支付appkey
        'application_cert'=>Env::get('root_path').'/cert/application_cert.pem',
        //将文件放到根目录下cert里，然后从宝塔或者服务器读取到cert目录的绝对路径
        'application_key'=>Env::get('root_path').'/cert/application_key.pem',
        //将文件放到根目录下cert里，然后从宝塔或者服务器读取到cert目录的绝对路径
    ],

    //腾讯云短信配置
    'sms'=>[
        'template'=>'1429313',//模板id
        'appid'=>'1400688334',
        'appkey'=>'991bc9b886865483e26c052fb2ed5746',//在这里看https://console.cloud.tencent.com/smsv2/app-manage
        'sign_name'=>'趣用科技',//签名内容，不是签名id
        'expire_time'=>5,//多少分钟内有效

    ],

    //注意，固有的数字id不可以删除，可以修改文字，或增加，按顺序加
    'wallpaper_tags'=>[
        1=>'动漫',
        2=>'风景',
        3=>'人物',
        4=>'科幻',
        5=>'游戏',
        6=>'汽车',
        7=>'怀旧',
        8=>'艺术',
        9=>'文字',
        10=>'抒情',
        11=>'头像',
        12=>'宠物',
        13=>'珠宝',
        14=>'潮流',
        15=>'时尚',
        16=>'奢侈品',
        17=>'机车',
        18=>'创意',
        19=>'科技',
        20=>'二次元',
    ],//素材标签

    'thumb_size' => [ //根据素材类型生成不同的缩略图
        1=>['294x480','441x720'], //手机壁纸、动态壁纸
        3=>['200x200','516x315','400x400'],//背景图
        4=>['339x339','200x200'],//头像
        5=>['339x339','200x200'],//表情包
    ],

    'ffmpeg'=>'/usr/local/bin/ffmpeg',//服务器控制台通过输入 whereis ffmpeg 找到路径
    'ffprobe'=>'/usr/local/bin/ffprobe', //服务器控制台通过输入 whereis ffprobe 找到路径
];
<?php
/**
 * Created by PhpStorm.
 * User: 999
 * Date: 2019/9/5
 * Time: 16:09
 */
//分页配置
return [
    'type'      => 'page\LayuiPage',
    'var_page'  => 'page',
    'list_rows' => 15,
];
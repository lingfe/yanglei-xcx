<?php /*a:2:{s:78:"/www/wwwroot/cs.dyhot.cn/php-retail/application/backend/view/config/index.html";i:1639561548;s:84:"/www/wwwroot/cs.dyhot.cn/php-retail/application/backend/view/base/common_header.html";i:1635745947;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">

<head>
    <meta charset="UTF-8">
<title>壁纸小程序后台管理</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" href="/static/css/font.css">
<link rel="stylesheet" href="/static/css/xadmin.css">
<!-- <link rel="stylesheet" href="./css/theme5.css"> -->
<script src="/static/lib/layui/layui.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/xadmin.js"></script>
<!--<script type="text/javascript" src="/static/js/jquery.min.js"></script>-->
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="/static/js/html5.min.js"></script>
<script src="/static/js/respond.min.js"></script>
<![endif]-->
<script>
    // 是否开启刷新记忆tab功能
    // var is_remember = false;
</script>
    <style>
        .layui-table td, .layui-table th { min-width: auto; }
    </style>
</head>

<body>
<div class="x-nav">
            <span class="layui-breadcrumb">
                <a href="/platform">首页</a>
                <a href="/platform/config">系统配置</a>
            </span>
    <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" onclick="location.reload()" title="刷新">
        <i class="layui-icon layui-icon-refresh" style="line-height:30px"></i>
    </a>
</div>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <form class="layui-form topic-form ">
                    <div class="layui-tab layui-tab-brief" lay-filter="docDemoTabBrief">
                        <ul class="layui-tab-title">
                            <?php if(is_array($new) || $new instanceof \think\Collection || $new instanceof \think\Paginator): $k = 0; $__LIST__ = $new;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($k % 2 );++$k;?>
                            <li class="<?php if($k == 1): ?>layui-this <?php endif; ?> change-config" data-module="<?php echo htmlentities($vv['base']['module']); ?>"><?php echo htmlentities($vv['base']['module_name']); ?></li>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </ul>
                        <div class="layui-tab-content">
                            <?php if(is_array($new) || $new instanceof \think\Collection || $new instanceof \think\Paginator): $k2 = 0; $__LIST__ = $new;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv2): $mod = ($k2 % 2 );++$k2;if(is_array($vv2['data']) || $vv2['data'] instanceof \think\Collection || $vv2['data'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vv2['data'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;if($v['type'] == 1): ?>
                            <div class="layui-form-item <?php echo htmlentities($v['module']); ?>-div config-item" <?php if($v['module'] != $firstShow): ?>style="display:none"<?php endif; ?>>
                                <label for="username" class="layui-form-label">
                                    <?php echo htmlentities($v['config_name']); ?></label>
                                <div class="layui-input-block">
                                    <input type="text" id="<?php echo htmlentities($v['config_key']); ?>" name="config_value[<?php echo htmlentities($v['config_key']); ?>]" value="<?php echo htmlentities($v['config_value']); ?>"  autocomplete="off" class="layui-input">
                                    <p style="color: red;"><?php echo htmlentities($v['config_note']); ?></p>
                                </div>
                                <input type="hidden" name="id[<?php echo htmlentities($v['config_key']); ?>]" value="<?php echo htmlentities($v['id']); ?>">
                                <input type="hidden" name="config_name[<?php echo htmlentities($v['config_key']); ?>]" value="<?php echo htmlentities($v['config_name']); ?>">
                                <input type="hidden" name="config_key[<?php echo htmlentities($v['config_key']); ?>]" value="<?php echo htmlentities($v['config_key']); ?>">
                            </div>
                            <?php endif; if($v['type'] == 2): ?>
                            <div class="layui-form-item <?php echo htmlentities($v['module']); ?>-div config-item" <?php if($v['module'] != $firstShow): ?>style="display:none"<?php endif; ?>>
                                <label for="desc" class="layui-form-label">
                                    <?php echo htmlentities($v['config_name']); ?></label>
                                <div class="layui-input-block">
                                    <button type="button" class="layui-btn" id="<?php echo htmlentities($v['config_key']); ?>">
                                        <i class="layui-icon">&#xe67c;</i>上传图片
                                    </button>
                                    <div class="banner-show" style="width: 200px;margin-top: 5px;"><img src="<?php echo htmlentities($v['config_value']); ?>" class="banner-show" style="width: auto;max-width: 100%;max-height: 100%"></div>
                                    <input type="hidden" name="config_value[<?php echo htmlentities($v['config_key']); ?>]" value="<?php echo htmlentities($v['config_value']); ?>" class="banner_img">
                                    <input type="hidden" name="id[<?php echo htmlentities($v['config_key']); ?>]" value="<?php echo htmlentities($v['id']); ?>">
                                    <input type="hidden" name="config_name[<?php echo htmlentities($v['config_key']); ?>]" value="<?php echo htmlentities($v['config_name']); ?>">
                                    <input type="hidden" name="config_key[<?php echo htmlentities($v['config_key']); ?>]" value="<?php echo htmlentities($v['config_key']); ?>">
                                    <p style="color: red;"><?php echo htmlentities($v['config_note']); ?></p>
                                </div>
                            </div>
                            <script type="text/javascript">
                                /**
                                 * 图片上传
                                 * */
                                layui.use('upload', function(){
                                    var upload = layui.upload;

                                    //执行实例
                                    upload.render({
                                        elem: "#<?php echo htmlentities($v['config_key']); ?>" //绑定元素
                                        ,url: '/api/fileUpload' //上传接口code
                                        ,size: 512
                                        ,data:{useOrigin:1}
                                        ,done: function(res){
                                            //上传完毕回调
                                            if(res.code == 1){
                                                console.log(1);
                                                $("#<?php echo htmlentities($v['config_key']); ?>").parents('.layui-input-block').find('.banner-show').find('img').attr('src',res.photo)
                                                $("#<?php echo htmlentities($v['config_key']); ?>").parents('.layui-input-block').find('.banner_img').val(res.photo)
                                            }
                                        }
                                        ,error: function(){
                                            //请求异常回调
                                            layer.msg('上传失败')
                                        }
                                    });
                                });
                            </script>
                            <?php endif; if($v['type'] == 3): ?>
                            <div class="layui-form-item <?php echo htmlentities($v['module']); ?>-div config-item" <?php if($v['module'] != $firstShow): ?>style="display:none"<?php endif; ?>>
                                <label for="username" class="layui-form-label">
                                    <?php echo htmlentities($v['config_name']); ?></label>
                                <div class="layui-input-block">
                                    <textarea name="config_value[<?php echo htmlentities($v['config_key']); ?>]"  class="layui-textarea"><?php echo htmlentities($v['config_value']); ?></textarea>
                                    <p style="color: red;"><?php echo htmlentities($v['config_note']); ?></p>
                                </div>
                                <input type="hidden" name="id[<?php echo htmlentities($v['config_key']); ?>]" value="<?php echo htmlentities($v['id']); ?>">
                                <input type="hidden" name="config_name[<?php echo htmlentities($v['config_key']); ?>]" value="<?php echo htmlentities($v['config_name']); ?>">
                                <input type="hidden" name="config_key[<?php echo htmlentities($v['config_key']); ?>]" value="<?php echo htmlentities($v['config_key']); ?>">
                            </div>
                            <?php endif; if($v['type'] == 5): ?>
                            <div class="layui-form-item <?php echo htmlentities($v['module']); ?>-div config-item" <?php if($v['module'] != $firstShow): ?>style="display:none"<?php endif; ?>>
                                <label for="username" class="layui-form-label">
                                    <?php echo htmlentities($v['config_name']); ?></label>
                                <div class="layui-input-block">
                                    <?php if($v['config_key'] == 'save_way'): ?>
                                    <input type="radio" name="config_value[<?php echo htmlentities($v['config_key']); ?>]" value="0" title="本地" <?php if($v['config_value'] == 0): ?>checked<?php endif; ?>>
                                    <input type="radio" name="config_value[<?php echo htmlentities($v['config_key']); ?>]" value="1" title="阿里云OSS" <?php if($v['config_value'] == 1): ?>checked<?php endif; ?>>
                                    <input type="radio" name="config_value[<?php echo htmlentities($v['config_key']); ?>]" value="2" title="七牛云OSS" <?php if($v['config_value'] == 2): ?>checked<?php endif; ?>>
                                    <?php elseif($v['config_key'] == 'pay_way'): ?>
                                    <input type="radio" name="config_value[<?php echo htmlentities($v['config_key']); ?>]" value="0" title="支付宝账号手动打款" <?php if($v['config_value'] == 0): ?>checked<?php endif; ?>>
                                    <input type="radio" name="config_value[<?php echo htmlentities($v['config_key']); ?>]" value="1" title="微信付款到零钱" <?php if($v['config_value'] == 1): ?>checked<?php endif; ?>>
                                    <input type="radio" name="config_value[<?php echo htmlentities($v['config_key']); ?>]" value="2" title="微信收款码手动打款" <?php if($v['config_value'] == 2): ?>checked<?php endif; ?>>
                                    <input type="radio" name="config_value[<?php echo htmlentities($v['config_key']); ?>]" value="3" title="支付宝收款码手动打款" <?php if($v['config_value'] == 3): ?>checked<?php endif; ?>>
                                    <?php else: ?>
                                    <input type="radio" name="config_value[<?php echo htmlentities($v['config_key']); ?>]" value="0" title="否" <?php if($v['config_value'] == 0): ?>checked<?php endif; ?>>
                                    <input type="radio" name="config_value[<?php echo htmlentities($v['config_key']); ?>]" value="1" title="是" <?php if($v['config_value'] == 1): ?>checked<?php endif; ?>>
                                    <?php endif; ?>
                                    <p style="color: red;"><?php echo htmlentities($v['config_note']); ?></p>
                                </div>
                                <input type="hidden" name="id[<?php echo htmlentities($v['config_key']); ?>]" value="<?php echo htmlentities($v['id']); ?>">
                                <input type="hidden" name="config_name[<?php echo htmlentities($v['config_key']); ?>]" value="<?php echo htmlentities($v['config_name']); ?>">
                                <input type="hidden" name="config_key[<?php echo htmlentities($v['config_key']); ?>]" value="<?php echo htmlentities($v['config_key']); ?>">
                            </div>
                            <?php endif; ?>

                            <?php endforeach; endif; else: echo "" ;endif; ?>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label for="L_repass" class="layui-form-label"></label>
                        <button class="layui-btn" lay-filter="add" lay-submit="">修改</button></div>
                        <br/><br/>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
<script>
    layui.use(['form', 'layer'],
        function() {
            $ = layui.jquery;
            var form = layui.form,
                layer = layui.layer;
            //监听提交
            form.on('submit(add)',
                function(data) {
                    $.post("/admin/config/save",$('.topic-form').serialize(),function (res) {
                        if(res.error_code != 0){
                            layer.msg(res.msg,{icon:5});
                        }else{
                            //发异步，把数据提交给php
                            layer.msg("修改成功", {
                                    icon: 6
                                },
                                function() {
                                    window.location.reload();
                                });
                        }
                    },'json')
                    return false;
                });

            $('.change-config').click(function () {
                var _module = $(this).data('module')
                console.log(_module)
                console.log($(_module + '-div'));
                $('.config-item').css('display','none')
                $('.'+_module+'-div').css('display','')
            })
        })
</script>

</html>
<?php /*a:2:{s:76:"/www/wwwroot/img.qutubao.com/php/application/backend/view/questions/add.html";i:1646556566;s:81:"/www/wwwroot/img.qutubao.com/php/application/backend/view/base/common_header.html";i:1647852764;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">

<head>
    <meta charset="UTF-8">
<title>壁纸小程序后台管理</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" href="/static/css/font.css">
<link rel="stylesheet" href="/static/css/xadmin.css">
<!-- <link rel="stylesheet" href="./css/theme5.css"> -->
<script src="/static/lib/layui/layui.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/xadmin.js"></script>
<!--<script type="text/javascript" src="/static/js/jquery.min.js"></script>-->
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="/static/js/html5.min.js"></script>
<script src="/static/js/respond.min.js"></script>
<![endif]-->
<script>
    // 是否开启刷新记忆tab功能
    var is_remember = false;
</script>
    <style>
        .w-e-toolbar{
            flex-wrap:wrap;
        }
    </style>
    <script type="text/javascript" charset="utf-8" src="/static/ueditor/ueditor.config.js?v=1"></script>
    <script type="text/javascript" charset="utf-8" src="/static/ueditor/ueditor.all.js?v=1"> </script>
    <!--建议手动加在语言，避免在ie下有时因为加载语言失败导致编辑器加载失败-->
    <!--这里加载的语言文件会覆盖你在配置项目里添加的语言类型，比如你在配置项目里配置的是英文，这里加载的中文，那最后就是中文-->
    <script type="text/javascript" charset="utf-8" src="/static/ueditor/lang/zh-cn/zh-cn.js"></script>

</head>

<body>
<div class="layui-fluid">
    <div class="layui-row">
        <form class="layui-form topic-form layui-col-space10">
            <div class="layui-col-md6">

                <div class="layui-form-item">
                    <label for="username" class="layui-form-label">
                        <span class="x-red">*</span>问题呢</label>
                    <div class="layui-input-inline">
                        <input type="text" id="question" name="question" required="" lay-verify="required" autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item layui-form-text">
                    <label for="desc" class="layui-form-label">
                        <span class="x-red">*</span>答案</label>
                    <div class="layui-input-block">
                        <textarea id="content-show" class="layui-textarea" name="answer"></textarea>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">权重</label>
                    <div class="layui-input-block">
                        <input type="text" id="weight" name="weight" value="0" required="" lay-verify="required" autocomplete="off" class="layui-input">
                        <p style="color: red">输入数字，越小排越前</p>
                    </div>
                </div>
            </div>
            <div class="layui-form-item">
                <label for="L_repass" class="layui-form-label"></label>
                <button class="layui-btn" lay-filter="add" lay-submit="">增加</button></div>
        </form>
    </div>
</div>


<script>





    layui.use(['form', 'layer'],
        function() {
            $ = layui.jquery;
            var form = layui.form,
                layer = layui.layer;
            //监听提交
            form.on('submit(add)',
                function(data) {
                    var index = layer.load(1); //添加laoding,0-2两种方式
                    $.post("/admin/questions/deal",$('.topic-form').serialize(),function (res) {
                        layer.close(index)
                        if(res.error_code != 0){
                            layer.msg(res.msg,{icon:5});
                        }else{
                            //发异步，把数据提交给php
                            layer.msg("增加成功", {
                                    icon: 6
                                },
                                function() {
                                    window.parent.location.reload();
                                    // 获得frame索引
                                    var index = parent.layer.getFrameIndex(window.name);
                                    //关闭当前frame
                                    parent.layer.close(index);
                                });
                        }
                    },'json')
                    return false;
                });
        });




</script>

</body>

</html>
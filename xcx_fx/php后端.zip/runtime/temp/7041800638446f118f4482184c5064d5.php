<?php /*a:2:{s:75:"/www/wwwroot/meitu.ilanchong.cn/application/backend/view/index/welcome.html";i:1650452886;s:80:"/www/wwwroot/meitu.ilanchong.cn/application/backend/view/base/common_header.html";i:1647852764;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">
<head>
    <meta charset="UTF-8">
<title>壁纸小程序后台管理</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" href="/static/css/font.css">
<link rel="stylesheet" href="/static/css/xadmin.css">
<!-- <link rel="stylesheet" href="./css/theme5.css"> -->
<script src="/static/lib/layui/layui.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/xadmin.js"></script>
<!--<script type="text/javascript" src="/static/js/jquery.min.js"></script>-->
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="/static/js/html5.min.js"></script>
<script src="/static/js/respond.min.js"></script>
<![endif]-->
<script>
    // 是否开启刷新记忆tab功能
    var is_remember = false;
</script>
</head>
<body>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-body ">
                    <blockquote class="layui-elem-quote">欢迎管理员：
                        <span class="x-red"><?php echo htmlentities($admin_name); ?></span>！
                    </blockquote>
                </div>
            </div>
        <div class="layui-col-md12">
            <div class="layui-col-md6">
                <div class="layui-card">
                    <div class="layui-card-body ">
                        小程序部分重要数据展现使用规则说明：
                        <p>1、首页顶部跑马灯数据为后台Banner管理中的数据， 并按权重排序，数值越小越排前</p>
                        <p>2、首页达人推荐为已成功入驻且在后台达人系统—>达人列表中有被推荐的并有上传素材的达人，按照权重数值越大越靠前排</p>
                        <p>3、首页显示的5种素材类型的数据为后台平台上传的素材+达人素材组合而成，在后台系统管理—>系统配置的基础设置中，设置每种素材的展示数量。
                        后台数据为已显示+已推荐，并按权重数值排序，若不足展示量，则从达人对应素材类型中按下载量补充数量</p>
                        <p>4、达人列表排序按照权重数值越大越靠前排序</p>
                        <p>5、在后台系统管理—>系统配置的分销设置中每日看广告次数以及免费下载原始数据次数，超过则提示当日可使用次数已用完</p>
                        <p>待续补充。。。。。。。</p>
                        <p>😁😁😁😁</p>
                    </div>
                </div>
            </div>
            <div class="layui-col-md6">
                <div class="layui-card">
                    <div class="layui-card-body ">
                        达人H5端部分重要数据展现使用规则说明：
                        <p>1、在后台系统管理—>系统配置的基础设置中可以开启或关闭达人H5入口</p>
                        <p>2、目前达人登陆支持短信/密码登陆，短信配置需要在项目代码中配置短信相关信息，路径为config/params.php，具体看文件内容说明</p>
                        <p>3、目前结算达人佣金方式中支持微信企业付款到零钱，这个需要提供认证服务号带支付、且系统开启公众号授权，且微信商家支付有企业付款到零钱的权限。公众号的基础配置在系统管理—系统配置中的公众号设置
                            ，然后配置微信支付的相关配置，路径为config/params.php。最后将微信支付的两个文件放到cert里，具体看文件内容说明</p>
                        <p>4、在后台系统管理—>系统配置的佣金设置中可配置预估佣金，只做展示参考，不是用于实际佣金结算</p>
                        <p>5、佣金结算规则，在达人系统—>分销明细中，按不同项目结算某一天的佣金。结算规则为计算单次看广告可分润给达人+达人上级的佣金</p>
                        <p>6、佣金结算后，达人并未能提现，该金额进入冻结金额中，需要在后台达人系统—>真实佣金列表中操作结算，达人则可以提现这部分的收益</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="layui-col-md12">
            <div class="layui-col-md6">
                <div class="layui-card">
                    <div class="layui-card-body">
                        注意事项：
                        <p>1、系统部署环境说明：centos7、php7.2、mysql5.7，需支持ffmpeg扩展，php禁用函数里去掉scandir，exec、system、shell_exec、proc_open</p>
                        <p>2、每次更新迭代系统后需要手动清除缓存，操作按钮在右上角</p>
                        <p>3、若自己对源码进行二开，在对原系统做版本迭代时出现互斥问题，需自己解决</p>
                        <p>4、有自己的想法可以找原作者进行定制化开发</p>
                        <p>5、系统使用中有什么问题可以与原作者反馈，一起合作强化系统功能</p>
                        <p>6、邀请团队的海报背景图路径为/public/static/h5/dist/images/poster_bg.png，需要自己可以修改替换</p>
                        <p>7、上线qq小程序，需要在提交审核前，走一遍图片接口校验请求<br/>
                            接口：<span style="color: red"><?php echo htmlentities($php_domain); ?>/api/qqCheckImg?sign=dj3jJ2j4Ej</span></p>
                    </div>
                </div>
            </div>
            <div class="layui-col-md6">
                <div class="layui-card">
                    <div class="layui-card-body ">
                        系统中所使用的到定时任务脚本：
                        <p>1、每日清空昨天排行佣金数据，脚本为：</p>
                        <p><span style="color: red">php <?php echo htmlentities($rootPath); ?>think refreshmoney</span> 设置每天凌晨0点执行</p>
                        <p>2、每日恢复当天可上传素材次数，脚本为：</p>
                        <p><span style="color: red">php <?php echo htmlentities($rootPath); ?>think revertuploadnum</span> 设置每天凌晨0点执行</p>
                        <p>3、定时更新达人收获的点赞数、收藏数，脚本为：</p>
                        <p><span style="color: red">php <?php echo htmlentities($rootPath); ?>think updateexpertdata</span> 设置每一小时执行</p>
                        <p>4、每小时更新accesstoken，脚本为：</p>
                        <p><span style="color: red">php <?php echo htmlentities($rootPath); ?>think updateaccesstoken</span> 设置每一小时执行</p>
                        <p>5、每5分钟推送模板消息，脚本为：</p>
                        <p><span style="color: red">php <?php echo htmlentities($rootPath); ?>think templatepush</span> 设置每5分钟执行</p>
                        <p>6、每天恢复扣量基础，脚本为：</p>
                        <p><span style="color: red">php <?php echo htmlentities($rootPath); ?>think clearcache</span> 设置每天凌晨0点执行</p>

                        <p>注意：命令中的php为服务器里的全局变量，若不是需要找到php的执行路径替换</p>
                    </div>
                </div>
            </div>
        </div>

<!--        <div class="layui-col-md12">-->
<!--            <div class="layui-card">-->
<!--                <div class="layui-card-header">数据统计</div>-->
<!--                <div class="layui-card-body ">-->
<!--                    <ul class="layui-row layui-col-space10 layui-this x-admin-carousel x-admin-backlog">-->
<!--                        <li class="layui-col-md2 layui-col-xs6">-->
<!--                            <a href="javascript:;" class="x-admin-backlog-body">-->
<!--                                <h3>达人人数</h3>-->
<!--                                <p>-->
<!--                                    <cite><?php echo htmlentities($expert); ?></cite></p>-->
<!--                            </a>-->
<!--                        </li>-->
<!--                        <li class="layui-col-md2 layui-col-xs6">-->
<!--                            <a href="javascript:;" class="x-admin-backlog-body">-->
<!--                                <h3>达人素材总数</h3>-->
<!--                                <p>-->
<!--                                    <cite><?php echo htmlentities($wallpaper); ?></cite></p>-->
<!--                            </a>-->
<!--                        </li>-->


<!--                    </ul>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-header">系统信息</div>
                <div class="layui-card-body ">
                    <table class="layui-table">
                        <tbody>
                        <tr>
                            <th>服务器地址</th>
                            <td><?php echo htmlentities($data['server_ip']); ?></td></tr>
                        <tr>
                            <th>操作系统</th>
                            <td><?php echo htmlentities($data['s']); ?></td></tr>
                        <tr>
                            <th>运行环境</th>
                            <td><?php echo htmlentities($data['sysos']); ?></td></tr>
                        <tr>
                            <th>PHP版本</th>
                            <td><?php echo htmlentities($data['sysversion']); ?></td></tr>
                        <tr>
                            <th>PHP运行方式</th>
                            <td>cgi-fcgi</td></tr>
                        <tr>
                            <th>上传附件限制</th>
                            <td><?php echo htmlentities($data['max_upload']); ?></td></tr>
                        <tr>
                            <th>执行时间限制</th>
                            <td><?php echo htmlentities($data['max_ex_time']); ?></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
  </div>
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-header">运营者</div>
                <div class="layui-card-body ">
                    <table class="layui-table">
                        <tbody>
                        <tr>
                            <th>运营者</th>
                            <td>请根据相关规定做好运营，风险自行承担</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <style id="welcome_style"></style>
    </div>
</div>
</div>
</body>
</html>
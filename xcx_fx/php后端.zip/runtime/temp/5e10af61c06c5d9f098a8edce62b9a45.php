<?php /*a:2:{s:79:"/www/wwwroot/img.qutubao.com/php/application/backend/view/user_price/index.html";i:1646556620;s:81:"/www/wwwroot/img.qutubao.com/php/application/backend/view/base/common_header.html";i:1647852764;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">

<head>
    <meta charset="UTF-8">
<title>壁纸小程序后台管理</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" href="/static/css/font.css">
<link rel="stylesheet" href="/static/css/xadmin.css">
<!-- <link rel="stylesheet" href="./css/theme5.css"> -->
<script src="/static/lib/layui/layui.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/xadmin.js"></script>
<!--<script type="text/javascript" src="/static/js/jquery.min.js"></script>-->
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="/static/js/html5.min.js"></script>
<script src="/static/js/respond.min.js"></script>
<![endif]-->
<script>
    // 是否开启刷新记忆tab功能
    var is_remember = false;
</script>
    <style>
        .layui-table td, .layui-table th { min-width: auto; }
    </style>
</head>

<body>
<div class="x-nav">
            <span class="layui-breadcrumb">
                <a href="/admin">首页</a>
                <a href="/admin/userPrice">佣金提现</a>
            </span>
    <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" onclick="location.reload()" title="刷新">
        <i class="layui-icon layui-icon-refresh" style="line-height:30px"></i>
    </a>
</div>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-body ">
                    <form class="layui-form layui-col-space5">
                        <div class="layui-input-inline layui-show-xs-block">
                            <input type="text" value="<?php echo htmlentities($user_id); ?>" name="user_id" placeholder="请输入用户ID" autocomplete="off" class="layui-input"></div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <input type="text" value="<?php echo htmlentities($name); ?>" name="name" placeholder="请输入达人口令" autocomplete="off" class="layui-input"></div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <button class="layui-btn" lay-submit="" lay-filter="sreach">
                                <i class="layui-icon">&#xe615;</i></button>
                        </div>
                    </form>
                </div>
                <div class="layui-card-body ">
                    <p style="color:red;font-size: 16px;">目前支持支付宝账号付款、微信企业到零钱、微信收款码转账、支付宝收款码转账，人工打款请确认转账后再点右侧确认按钮</p>
                    <table class="layui-table layui-form">
                        <thead>
                        <tr>
                            <th>用户ID</th>
                            <th>用户昵称</th>
                            <th>提现金额</th>
                            <th>提现方式</th>
                            <th>真实姓名</th>
                            <th>收款码</th>
                            <th>申请时间</th>
                            <th>转账时间</th>
                            <th>状态</th>
                            <th>管理操作</th>
                        </thead>
                        <tbody>
                        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$info): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <td><?php echo htmlentities($info['user_id']); ?></td>
                            <td><?php echo htmlentities($info['user']['user_code']); ?><br><?php echo htmlentities(urldecode($info['user']['user_nickname'])); ?></td>
                            <td><?php echo htmlentities($info['price']); ?></td>
                            <td><?php switch($info['pay_way']): case "0": ?>支付宝账号付款<?php break; case "1": ?>微信付款到零钱<?php break; case "2": ?>微信收款码<?php break; case "3": ?>支付宝收款码<?php break; ?>
                                <?php endswitch; ?>
                            </td>
                            <td><?php echo htmlentities($info['real_name']); ?></td>
                            <td>
                                <?php if($info['apply_account']): ?><?php echo htmlentities($info['apply_account']); ?><?php endif; if($info['code_img']): ?><img class="code-img" data-img="<?php echo htmlentities($info['code_img']); ?>" src="<?php echo htmlentities($info['code_img']); ?>" width="70px" height="120px"><?php endif; ?>
                            </td>
                            <td><?php echo htmlentities(date("Y-m-d H:i:s",!is_numeric($info['ceated_at'])? strtotime($info['ceated_at']) : $info['ceated_at'])); ?></td>
                            <td><?php if(!empty($info['get_at'])): ?><?php echo htmlentities(date("Y-m-d H:i:s",!is_numeric($info['get_at'])? strtotime($info['get_at']) : $info['get_at'])); ?><?php endif; ?></td>
                            <td>
                                <?php switch($info['is_get']): case "0": ?>待处理<?php break; case "1": ?>已处理<?php break; ?>
                                <?php endswitch; ?>
                            </td>
                            <td>
                                <?php switch($info['is_get']): case "0": ?>
                                <a title="确认转账" class="layui-btn layui-btn-sm" onclick="returnPrice(this,'<?php echo htmlentities($info['id']); ?>','<?php echo htmlentities($info['pay_way']); ?>')" href="javascript:;">
                                    确认转账</a>
                                <?php break; case "1": ?>已转账<?php break; ?>
                                <?php endswitch; ?>
                            </td>
                        </tr>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="layui-card-body ">
                    <?php echo $page; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function returnPrice(obj, id,type) {
        var _url = parseInt(type) == 1?'/admin/userPrice/wxDeal':'/admin/userPrice/deal'
        layer.confirm('确认转账吗？',
            function(index) {
                //发异步删除数据
                var index = layer.load(1); //添加laoding,0-2两种方式
                $.post(_url,{id:id},function (data) {
                    layer.close(index)
                    console.log(data)
                    if(data.error_code == 0){
                        layer.msg('操作成功!', {
                            icon: 1,
                            time: 1000
                        },function () {
                            window.location.reload()
                        });
                    }else{
                        layer.msg(data.msg, {icon:2});
                    }
                },"json")

            });
    }

    layui.use(['form', 'layer'],
        function() {
            $ = layui.jquery;
            var form = layui.form,
                layer = layui.layer;

            $('.code-img').click(function () {
                layer.open({
                    type: 1,
                    skin: 'layui-layer-rim', //加上边框
                    area: ['60%', '100%'], //宽高
                    shadeClose: true, //开启遮罩关闭
                    end: function (index, layero) {
                        return false;
                    },
                    content: '<div style="text-align:center;"><img src="' + $(this).data('img') + '" style="width: 50%;height: 70%"/></div>'
                })
            })
        }
    )

</script>
</body>

</html>
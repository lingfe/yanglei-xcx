<?php /*a:4:{s:73:"/www/wwwroot/meitu.ilanchong.cn/application/backend/view/index/index.html";i:1636441390;s:80:"/www/wwwroot/meitu.ilanchong.cn/application/backend/view/base/common_header.html";i:1647852764;s:84:"/www/wwwroot/meitu.ilanchong.cn/application/backend/view/base/common_miniheader.html";i:1646189938;s:83:"/www/wwwroot/meitu.ilanchong.cn/application/backend/view/base/common_left_menu.html";i:1635745948;}*/ ?>
<!doctype html>
<html class="x-admin-sm">
<head>
    <meta charset="UTF-8">
<title>壁纸小程序后台管理</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" href="/static/css/font.css">
<link rel="stylesheet" href="/static/css/xadmin.css">
<!-- <link rel="stylesheet" href="./css/theme5.css"> -->
<script src="/static/lib/layui/layui.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/xadmin.js"></script>
<!--<script type="text/javascript" src="/static/js/jquery.min.js"></script>-->
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="/static/js/html5.min.js"></script>
<script src="/static/js/respond.min.js"></script>
<![endif]-->
<script>
    // 是否开启刷新记忆tab功能
    var is_remember = false;
</script>
</head>
<body class="index">
<!-- 顶部开始 -->
<div class="container">
    <div class="logo">
        <a href="/admin">后台管理</a></div>
    <div class="left_open">
        <a><i title="展开左侧栏" class="iconfont">&#xe699;</i></a>
    </div>
    <ul class="layui-nav right" lay-filter="">
        <li class="layui-nav-item">
            <a href="javascript:;"><?php echo htmlentities($admin_name); ?></a>
            <dl class="layui-nav-child">
                <!-- 二级菜单 -->
                <dd>
                    <a onclick="xadmin.open('修改密码','/admin/changePwd','','',true)">修改密码</a></dd>
                <dd>
                    <a href="/admin/logout">退出</a></dd>
            </dl>
        </li>
        <li class="layui-nav-item to-index">
            <a onclick="clearCache()">清除缓存</a></li>
    </ul>
</div>
<!-- 顶部结束 -->
<!-- 中部开始 -->
<!-- 左侧菜单开始 -->
<div class="left-nav">
    <div id="side-nav">
        <ul id="nav">
            <?php if(!empty($permissions)): if(is_array($permissions) || $permissions instanceof \think\Collection || $permissions instanceof \think\Paginator): $k = 0; $__LIST__ = $permissions;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$p): $mod = ($k % 2 );++$k;?>
            <li>
                <a href="javascript:;">
                    <i class="iconfont left-nav-li" lay-tips="<?php echo htmlentities($p['name']); ?>"><?php echo $p['icon']; ?></i>
                    <cite><?php echo htmlentities($p['name']); ?></cite>
                    <i class="iconfont nav_right">&#xe697;</i></a>
                <ul class="sub-menu">
                    <?php if(!empty($p['value'])): if(is_array($p['value']) || $p['value'] instanceof \think\Collection || $p['value'] instanceof \think\Paginator): $i = 0; $__LIST__ = $p['value'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$p2): $mod = ($i % 2 );++$i;?>
                    <li>
                        <a onclick="xadmin.add_tab('<?php echo htmlentities($p2['menu_name']); ?>','<?php echo htmlentities($p2['menu_url']); ?>',true)">
                            <i class="iconfont">&#xe6a7;</i>
                            <cite><?php echo htmlentities($p2['menu_name']); ?></cite></a>
                    </li>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
            <?php endif; ?>
        </ul>
    </div>
</div>
<!-- <div class="x-slide_left"></div> -->
<!-- 左侧菜单结束 -->
<!-- 右侧主体开始 -->
<div class="page-content">
    <div class="layui-tab tab" lay-filter="xbs_tab" lay-allowclose="false">
        <ul class="layui-tab-title">
            <li class="home">
                <i class="layui-icon">&#xe68e;</i>我的桌面</li></ul>
        <div class="layui-unselect layui-form-select layui-form-selected" id="tab_right">
            <dl>
                <dd data-type="this">关闭当前</dd>
                <dd data-type="other">关闭其它</dd>
                <dd data-type="all">关闭全部</dd></dl>
        </div>
        <div class="layui-tab-content">
            <div class="layui-tab-item layui-show">
                <iframe src='/admin/welcome' frameborder="0" scrolling="yes" class="x-iframe"></iframe>
            </div>
        </div>
        <div id="tab_show"></div>
    </div>
</div>
<div class="page-content-bg"></div>
<style id="theme_style"></style>
<!-- 右侧主体结束 -->
<!-- 中部结束 -->
</body>
<script type="text/javascript">
    layui.use(['form', 'layer'],
        function() {
            var form = layui.form,
                layer = layui.layer,
            $ = layui.jquery;
        })
    function clearCache(){
        $.get('/admin/clearCache',{},function (r){
            layer.msg('清除成功');
        })
    }
</script>
</html>
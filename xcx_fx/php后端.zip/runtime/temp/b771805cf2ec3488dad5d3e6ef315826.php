<?php /*a:2:{s:84:"/www/wwwroot/cs.dyhot.cn/php-retail/application/backend/view/distribution/index.html";i:1644463434;s:84:"/www/wwwroot/cs.dyhot.cn/php-retail/application/backend/view/base/common_header.html";i:1635745947;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">

<head>
    <meta charset="UTF-8">
<title>壁纸小程序后台管理</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" href="/static/css/font.css">
<link rel="stylesheet" href="/static/css/xadmin.css">
<!-- <link rel="stylesheet" href="./css/theme5.css"> -->
<script src="/static/lib/layui/layui.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/xadmin.js"></script>
<!--<script type="text/javascript" src="/static/js/jquery.min.js"></script>-->
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="/static/js/html5.min.js"></script>
<script src="/static/js/respond.min.js"></script>
<![endif]-->
<script>
    // 是否开启刷新记忆tab功能
    // var is_remember = false;
</script>
    <style>
        .layui-table td, .layui-table th { min-width: auto; }
        .layui-form-label{
            width: 100px;}
        .layui-form-item .layui-input-inline{
            width: 290px;
        }
    </style>
</head>

<body>
<div class="x-nav">
            <span class="layui-breadcrumb">
                <a href="/admin">首页</a>
                <a href="/admin/distribution">分佣明细</a>
            </span>
    <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" onclick="location.reload()" title="刷新">
        <i class="layui-icon layui-icon-refresh" style="line-height:30px"></i>
    </a>
</div>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-body ">
                    <form class="layui-form layui-col-space5">
                        <div class="layui-input-inline layui-show-xs-block">
                            <select name="project_id">
                                <option value="" <?php if($project_id == ''): ?>selected<?php endif; ?>>全部项目</option>
                                <?php if($project_list): if(is_array($project_list) || $project_list instanceof \think\Collection || $project_list instanceof \think\Paginator): $i = 0; $__LIST__ = $project_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                                <option value="<?php echo htmlentities($v['id']); ?>" <?php if($project_id == $v['id']): ?>selected<?php endif; ?>><?php echo htmlentities($v['name']); ?></option>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="layui-input-inline" >
                            <input type="text" name="time" placeholder="获得佣金开始时间" value="<?php echo htmlentities($time); ?>" class="layui-input" id="test1">
                        </div>
                        <div class="layui-input-inline" >
                            <input type="text" name="time2" placeholder="获得佣金结束时间" value="<?php echo htmlentities($time2); ?>" class="layui-input" id="test2">
                        </div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <input type="text" value="<?php echo htmlentities($user_id); ?>" name="user_id" placeholder="请输入用户ID" autocomplete="off" class="layui-input"></div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <input type="text" value="<?php echo htmlentities($name); ?>" name="name" placeholder="请输入达人口令" autocomplete="off" class="layui-input"></div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <select name="type">
                                <option value="0" <?php if($type == 0): ?>selected<?php endif; ?>>全部推广</option>
                                <option value="1" <?php if($type == 1): ?>selected<?php endif; ?>>自推</option>
                                <option value="2" <?php if($type == 2): ?>selected<?php endif; ?>>下级推广</option>
                            </select>
                        </div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <button class="layui-btn" lay-submit="" lay-filter="sreach">
                                <i class="layui-icon">&#xe615;</i></button>
                            <button type="button" class="layui-btn deal-money">
                                <i class="layui-icon"></i>操作结算</button>
                        </div>
                    </form>
                </div>
                <div class="layui-card-body ">
                    <p style="font-size: 20px;color:red">统计广告自推总累计次数为：<?php echo htmlentities($playCount); ?>次</p>
                    <p style="font-size: 20px;color:red">统计广告上级总累计次数为：<?php echo htmlentities($playCount2); ?>次</p>
                    <table class="layui-table layui-form">
                        <thead>
                        <tr>
                            <th width="5%">ID</th>
                            <th width="10%">昵称</th>
                            <th width="6%">获佣类型</th>
                            <th width="6%">获佣素材ID</th>
                            <th width="6%">获佣渠道</th>
                            <th width="10%">收益来源</th>
                            <th width="10%">预计佣金</th>
                            <th width="10%">获佣时间</th>
                            <th width="10%">结算佣金</th>
                            <th width="8%">是否结算</th>
                            <th width="10%">结算时间</th>
                            <th width="10%">小程序用户</th>
                        </thead>
                        <tbody>
                        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$topic): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <td><?php echo htmlentities($topic['id']); ?></td>
                            <td><?php echo htmlentities($topic['user']['user_code']); ?><br><?php echo htmlentities(urldecode($topic['user']['user_nickname'])); ?></td>
                            <td>
                                <?php if($topic['type'] == 1): ?>自推<?php endif; if($topic['type'] == 2): ?>下级推广<?php endif; ?>
                            </td>
                            <td><?php echo htmlentities($topic['wallpaper_id']); ?></td>
                            <td><?php echo htmlentities($project_list2[$topic['platform']]); ?></td>
                            <td><?php echo htmlentities($topic['origin_user_id']); ?><br><?php echo htmlentities(urldecode($topic['userFrom']['nickname'])); ?></td>
                            <td><?php echo htmlentities($topic['predict_price']); ?></td>
                            <td>
                                <?php if(!empty($topic['created_at'])): ?><?php echo htmlentities(date("Y-m-d",!is_numeric($topic['created_at'])? strtotime($topic['created_at']) : $topic['created_at'])); ?><?php endif; ?><br>
                                <?php if(!empty($topic['created_at'])): ?><?php echo htmlentities(date("H:i:s",!is_numeric($topic['created_at'])? strtotime($topic['created_at']) : $topic['created_at'])); ?><?php endif; ?>
                            </td>
                            <td><?php echo htmlentities($topic['true_price']); ?></td>
                            <td>
                                <?php switch($topic['price_deal_staus']): case "0": ?>待结算<?php break; case "1": ?>已结算<?php break; case "2": ?>结算中<?php break; case "4": ?>违规冻结<?php break; ?>
                                <?php endswitch; ?>
                            </td>
                            <td>
                                <?php if(!empty($topic['priece_deal_at'])): ?><?php echo htmlentities(date("Y-m-d",!is_numeric($topic['priece_deal_at'])? strtotime($topic['priece_deal_at']) : $topic['priece_deal_at'])); ?><?php endif; ?><br>
                                <?php if(!empty($topic['priece_deal_at'])): ?><?php echo htmlentities(date("H:i:s",!is_numeric($topic['priece_deal_at'])? strtotime($topic['priece_deal_at']) : $topic['priece_deal_at'])); ?><?php endif; ?>
                            </td>
                            <td><?php echo htmlentities($topic['openid']); ?><br><?php echo htmlentities(urldecode($topic['nickname'])); ?><br><?php echo htmlentities($topic['ip']); ?></td>
                        </tr>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="layui-card-body ">
                    <?php echo $page; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<div id="id" style="display: none">
    <div style="margin-top: 30px"></div>
    <form class="layui-form topic-form layui-col-space10">
        <div style="color: red;margin-left: 30px">这里只处理用户佣金结算，但未真正下方给用户提现，需要到用户真实佣金列表中操作发放</div>
        <div class="layui-col-md10">
            <div class="layui-form-item">
                <label for="" class="layui-form-label">
                    <span class="x-red">*</span>结算项目</label>
                <div class="layui-input-inline">
                    <select name="project_id">
                        <option value="0" >请选择</option>
                        <?php if($project_list): if(is_array($project_list) || $project_list instanceof \think\Collection || $project_list instanceof \think\Paginator): $i = 0; $__LIST__ = $project_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                        <option value="<?php echo htmlentities($v['id']); ?>" ><?php echo htmlentities($v['name']); ?></option>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        <?php endif; ?>
                    </select>
                </div>
            </div>
            <div class="layui-form-item">
                <label for="username" class="layui-form-label">
                    <span class="x-red">*</span>结算日期</label>
                <div class="layui-input-inline">
                    <input type="text" id="deal-time" name="deal_start"  required="" lay-verify="required" autocomplete="off" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">
                    <span class="x-red">*</span>自推佣金</label>
                <div class="layui-input-inline">
                    <input type="number"  name="fir_ad_money" required=""  autocomplete="off" class="layui-input">
                    <div style="color: red;">注意：该佣金为单次广告自推推广者可获得的佣金，最终推广者得到的总佣金为单次佣金乘以推广成功次数,填写数字
                    ，小数点不能超过3位，出错自己负责</div>
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">
                    <span class="x-red">*</span>上级佣金</label>
                <div class="layui-input-inline">
                    <input type="number"  name="sec_ad_money" value="0" required=""  autocomplete="off" class="layui-input">
                    <div style="color: red;">注意：该佣金为单次广告上级推广者可获得的佣金，最终推广者得到的总佣金为单次佣金乘以推广成功次数,填写数字
                    ，小数点不能超过3位，出错自己负责</div>
                </div>
            </div>
            <div class="layui-form-item" style="display: none;">
                <label class="layui-form-label">
                    <span class="x-red">*</span>上上级佣金</label>
                <div class="layui-input-inline">
                    <input type="number"  name="thr_ad_money" value="0" required=""  autocomplete="off" class="layui-input">
                    <div style="color: red;">注意：该佣金为单次广告上上级推广者可获得的佣金，最终推广者得到的总佣金为单次佣金乘以推广成功次数,填写数字
                    ，小数点不能超过3位，出错自己负责</div>
                </div>
            </div>
            <div class="layui-form-item">
                <label for="L_repass" class="layui-form-label"></label>
                <button class="layui-btn" lay-filter="add" lay-submit="">确认结算</button></div>
        </div>
    </form>
</div>
</body>



<script src="/static/js/jquery.min.js"></script>
<script>
    layui.use(['form', 'layer'],function () {
        $ = layui.jquery;
        var form = layui.form,
            layer = layui.layer;

        form.on('submit(add)',
            function(data) {
                $.post("/admin/distribution/money",$('.topic-form').serialize(),function (res) {
                    if(res.error_code != 0){
                        layer.msg(res.msg,{icon:5});
                    }else{
                        //发异步，把数据提交给php
                        layer.msg("操作成功", {
                                icon: 6
                            },
                            function() {
                                window.location.reload();

                            });
                    }
                },'json')
                return false;
            });

    })
    layui.use('laydate', function(){
        var laydate = layui.laydate;

        //执行一个laydate实例
        laydate.render({
            elem: '#test1' //指定元素
        });
    });
    layui.use('laydate', function(){
        var laydate = layui.laydate;

        //执行一个laydate实例
        laydate.render({
            elem: '#test2' //指定元素
        });
    });
    layui.use('laydate', function(){
        var laydate = layui.laydate;

        //执行一个laydate实例
        laydate.render({
            elem: '#deal-time' //指定元素
        });
    });
    layui.use('laydate', function(){
        var laydate = layui.laydate;

        //执行一个laydate实例
        laydate.render({
            elem: '#deal-time2' //指定元素
        });
    });
    $('.deal-money').click(function () {
        layer.open({
            type: 1,
            title:'佣金结算',
            area:['800px','500px'],
            content: $('#id'), //注意，如果str是object，那么需要字符拼接。
            cancel: function(index, layero){
                $('#id').css('display','none')
                layer.close(index)
                return false;
            }
        })
    })
</script>
</html>
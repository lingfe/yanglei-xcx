<?php /*a:4:{s:79:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/new_index/money.html";i:1639126057;s:74:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/base/title.html";i:1638609045;s:74:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/base/h5_v2.html";i:1641441303;s:82:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/base/expert_review.html";i:1638155221;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,target-densitydpi=high-dpi,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <title><?php echo htmlentities($platform_name); ?></title>
<link rel="stylesheet" href="/static/h5/dist/css/index.min.css?v=1.2.10">
<?php if(empty($isMobile)): ?>
<style>
    body {
        max-width: 420px !important;
        margin: 0 auto !important;
    }
    @media screen and (min-width: 420px) {
        .material-btns,
        .footer-tab {
            max-width: 420px !important;
            left: auto !important;
            right: auto !important;
        }
        .float-home {
            left: 50% !important;
            margin-left: 150px !important;
            width: 50px;
        }
    }
</style>
<?php endif; ?>

<!--<script type="text/javascript" src="/static/h5/new_dist/scripts/form.min.js"></script>-->
<!--<script src="https://cdn.bootcss.com/vConsole/3.3.4/vconsole.min.js"></script>-->

<!--<script>-->



<!--    var vConsole =new VConsole();-->

<!--    console.log(1230);-->

<!--</script>-->
    <link rel="stylesheet" href="/static/h5/dist/scripts/libs/swiper-bundle.min.css">
    <link rel="stylesheet" href="/static/h5/dist/scripts/libs/need/layer.css">
    <script type="text/javascript" src="/static/h5/dist/scripts/libs/layer.js"></script>
    <script src="/static/lib/layui/layui.js" charset="utf-8"></script>
    <link rel="stylesheet" href="/static/h5_v2/css/v2.css?v=1.1.38" type="text/css">
</head>
<body>
<header class="header-normal">
    <a class="back" href="/"></a>
    <h5>数据</h5>
    <span></span>
</header>

<section class="profit">
    <div class="profit-data">
        <dl>
            <dt class="data-dt">
                今日数据
            </dt>
            <dd>
                <p>
                    <strong><?php echo htmlentities($dayPrice['count']); ?></strong>
                    <span>访问人数</span>
                </p>
                <p>
                    <strong><?php if($dayPrice['predict_price']): ?><?php echo htmlentities($dayPrice['predict_price']); else: ?>0.000<?php endif; ?></strong>
                    <span>预估收益</span>
                </p>

            </dd>
            <dt class="data-dt">
                昨日数据
            </dt>
            <dd>
                <p>
                    <strong><?php echo htmlentities($yesterdayPrice['count']); ?></strong>
                    <span>访问人数</span>
                </p>
                <p>
                    <strong><?php if($yesterdayPrice['predict_price']): ?><?php echo htmlentities($yesterdayPrice['predict_price']); else: ?>0.000<?php endif; ?></strong>
                    <span>预估收益</span>
                </p>
                <p>
                    <strong><?php if($yesterdayPrice['true_price']): ?><?php echo htmlentities($yesterdayPrice['true_price']); else: ?>0.000<?php endif; ?></strong>
                    <span>实际收益</span>
                </p>
            </dd>
        </dl>
    </div>
<!--    <div class="profit-banner">-->
<!--        <a href="/user/team">-->
<!--            <img src="/static/h5/dist/images/profit_banner.png" alt="">-->
<!--        </a>-->
<!--    </div>-->
    <dl class="profit-tab">
        <dt>
            <span class="active">推广明细</span>
        </dt>
        <dd class="active cpm-log">
            <?php if($list): if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <div class="profit-tabitem" onclick="redirectDetail('<?php echo htmlentities($vo['created_at']); ?>')">
                <div class="profit-tabitem-l">
                    <strong><?php echo htmlentities($vo['created_at']); ?></strong>
                    <span>查看明细</span>
                </div>
                <div class="profit-tabitem-r">
                    <p><?php echo htmlentities($vo['true_price']); ?>元</p>
                </div>
            </div>
            <?php endforeach; endif; else: echo "" ;endif; ?>
            <?php endif; ?>
        </dd>
        <dd>
        </dd>
    </dl>
</section>

<input type="hidden" value="<?php echo htmlentities($total); ?>" id="total-page">
<input type="hidden" value="2" id="next-page">

<p class="footer-padding"></p>
<footer class="footer-tab">
    <a href="/" class="footer-home">
        <i></i>
        首页
    </a>
    <a href="/profit" class="footer-profit active">
        <i></i>
        数据
    </a>
    <a href="/user" class="footer-user">
        <i></i>
        我的
    </a>
</footer>
<script type="text/javascript" src="/static/h5/dist/scripts/libs/zepto.min.js"></script>
<script type="text/javascript" src="/static/h5/dist/scripts/libs/swiper-bundle.min.js"></script>
<script type="text/javascript">
    layui.use('layer', function() {
        var form = layui.form,
            layer = layui.layer





    })
    $('.profit-tab dt span').on('click', function () {
        var index = $(this).index();
        $(this).addClass('active').siblings().removeClass('active');
        $('.profit-tab dd').eq(index).addClass('active').siblings().removeClass('active');
    });

    window.addEventListener('scroll', scrollHandle);
    var isLoading = false;

    function scrollHandle() {
        if (isLoading) return;
        var windowHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
        var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
        var documentHeight = document.documentElement.scrollHeight || document.body.scrollHeight;
        if (documentHeight - windowHeight - scrollTop < 50) {

            var _nextPage = parseInt($('#next-page').val())
                , _totalPage = parseInt($('#total-page').val())
            console.log('滚动到底部了！');
            if (_nextPage > _totalPage) {
                return;
            }


            isLoading = true;
            // 加载数据
            $.ajax({
                url: '/profit',
                type: 'get',
                data: {page: _nextPage},
                dataType: 'json',
                success: function (r) {
                    var _html = '';
                    $(r.data).each(function (k, v) {
                        _html += '<div class="profit-tabitem" onclick="redirectDetail(\'' + v.created_at + '\')">\n' +
                            '                <div class="profit-tabitem-l">\n' +
                            '                    <strong>' + v.created_at + '</strong>\n' +
                            '                    <span>查看明细</span>\n' +
                            '                </div>\n' +
                            '                <div class="profit-tabitem-r">\n' +
                            '                    <p>' + v.true_price + '</p>\n' +
                            '                </div>\n' +
                            '            </div>'
                    })
                    $('.cpm-log').append(_html)
                    _nextPage++
                    $('#next-page').val(_nextPage)
                    // 加载完重新设置isLoading为false
                    isLoading = false;
                },
                error: function () {

                }
            })

        }
    }
    function redirectDetail(time) {
        window.location.href = '/money/detail?time=' + time
    }
</script>


<div class="ewm platform-notify " id="platform-notify">
  <div class="ewm-container">
    <h5>平台公告<br/>【达人入驻<?php echo htmlentities($platform_name); ?>注意事项】</h5>
    <p>1、通过手机号码注册或登录进入平台，需完善自己的账号信息</p>
    <p>2、达人可以通过电脑、手机浏览器上传素材</p>
    <p>3、每日可以在数据页面中查看自己当日的推广明细以及佣金收益</p>
    <p>4、每日需等待平台工作人员结算昨日佣金</p>
    <p>5、若有疑问，请到我的页面中联系客服</p>
    <div class="platform-btns">
      <button>我已阅读并知悉，去完善信息</button>
    </div>
  </div>
</div>

<script type="text/javascript">
  $('.platform-btns').click(function (){
    window.location.href = '/user/improve/init'
  })
  <?php if(empty($expertInfoBase['wechat_num'])): ?>
    $('#platform-notify').addClass('active')
  <?php endif; ?>
</script>


</body>
</html>

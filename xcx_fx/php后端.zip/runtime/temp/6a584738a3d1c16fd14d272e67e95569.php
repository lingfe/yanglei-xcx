<?php /*a:2:{s:75:"/www/wwwroot/img.qutubao.com/php/application/backend/view/expert/index.html";i:1649937168;s:81:"/www/wwwroot/img.qutubao.com/php/application/backend/view/base/common_header.html";i:1647852764;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">

<head>
    <meta charset="UTF-8">
<title>壁纸小程序后台管理</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" href="/static/css/font.css">
<link rel="stylesheet" href="/static/css/xadmin.css">
<!-- <link rel="stylesheet" href="./css/theme5.css"> -->
<script src="/static/lib/layui/layui.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/xadmin.js"></script>
<!--<script type="text/javascript" src="/static/js/jquery.min.js"></script>-->
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="/static/js/html5.min.js"></script>
<script src="/static/js/respond.min.js"></script>
<![endif]-->
<script>
    // 是否开启刷新记忆tab功能
    var is_remember = false;
</script>
    <style>
        .layui-table td, .layui-table th { min-width: auto; }
    </style>
</head>

<body>
<div class="x-nav">
            <span class="layui-breadcrumb">
                <a href="/admin">首页</a>
                <a href="/admin/expert">用户信息</a>
            </span>
    <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" onclick="location.reload()" title="刷新">
        <i class="layui-icon layui-icon-refresh" style="line-height:30px"></i>
    </a>
</div>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-body ">
                    <form class="layui-form layui-col-space5">
                        <div class="layui-input-inline layui-show-xs-block">
                            <input type="text" value="<?php echo htmlentities($code); ?>" name="code" placeholder="请输入达人口令" autocomplete="off" class="layui-input"></div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <input type="text" value="<?php echo htmlentities($user_id); ?>" name="user_id" placeholder="请输入达人id" autocomplete="off" class="layui-input"></div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <input type="text" value="<?php echo htmlentities($user_phone); ?>" name="user_phone" placeholder="请输入达人手机号码" autocomplete="off" class="layui-input"></div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <select name="is_recommend">
                                <option value="-1" <?php if($is_recommend == -1): ?>selected<?php endif; ?>>全部达人</option>
                                <option value="1" <?php if($is_recommend == 1): ?>selected<?php endif; ?>>推荐</option>
                                <option value="0" <?php if($is_recommend == 0): ?>selected<?php endif; ?>>未推荐</option>
                            </select>
                        </div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <select name="is_reviewed">
                                <option value="-1" <?php if($is_reviewed == -1): ?>selected<?php endif; ?>>全部状态</option>
                                <option value="0" <?php if($is_reviewed == 0): ?>selected<?php endif; ?>>待审核</option>
                                <option value="1" <?php if($is_reviewed == 1): ?>selected<?php endif; ?>>已通过</option>
                                <option value="2" <?php if($is_reviewed == 2): ?>selected<?php endif; ?>>未通过</option>
                            </select>
                        </div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <button class="layui-btn" lay-submit="" lay-filter="sreach">
                                <i class="layui-icon">&#xe615;</i></button>
                        </div>
                    </form>
                </div>
                <div class="layui-card-body ">
                    <?php if($is_super == 1): ?>
                    <p style="font-size: 20px;color:red">全站推广达人人数为：<?php echo htmlentities($total_user); ?></p>
                    <p style="font-size: 20px;color:red">昨日新增推广达人人数为：<?php echo htmlentities($yesterday_user); ?></p>
                    <?php endif; ?>
                    <table class="layui-table layui-form">
                        <thead>
                        <tr>
                            <th>用户ID</th>
                            <th>用户昵称<br/>审核状态</th>
                            <th>用户头像</th>
                            <th>微信号<br>达人口令<br>手机号</th>
                            <th>上级用户</th>
                            <th>总累计佣金</th>
                            <th>可提现佣金</th>
<!--                            <th>已提现佣金</th>-->
                            <th>注册时间</th>
                            <th>是否推荐</th>
                            <th>是否封号</th>
                            <th >操作</th>
                        </thead>
                        <tbody>
                        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$user): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <td><?php echo htmlentities($user['user_id']); ?></td>
                            <td>昵称：<?php echo htmlentities(urldecode($user['user_nickname'])); ?><br><?php if($user['wechat_num'] == ''): ?>待完善信息<?php elseif($user['is_reviewed'] == 0): ?>审核中<?php elseif($user['is_reviewed'] == 1): ?>通过<?php else: ?>驳回<?php endif; ?></td>
                            <td><?php if(!empty($user['user_headimg'])): ?><img src="<?php echo htmlentities($user['user_headimg']); ?>" width="80px" height="80px"><?php endif; ?></td>
                            <td><?php echo htmlentities($user['wechat_num']); ?><br/><?php echo htmlentities($user['user_code']); ?><br/><?php echo htmlentities($user['user_phone']); ?></td>
                            <td>口令:<?php echo htmlentities($user['parent_info']['user_code']); ?><br>微信:<?php echo htmlentities($user['parent_info']['wechat_num']); ?><br>号码：<?php echo htmlentities($user['parent_info']['user_phone']); ?>
                                <br/><a href="javascript:;" class="changeTeam" data-id="<?php echo htmlentities($user['user_id']); ?>">转移上级</a></td>
                            <td><?php echo htmlentities($user['total_money']); ?></td>
                            <td><?php echo htmlentities($user['withdraw_money']); ?></td>
<!--                            <td><?php echo htmlentities($user['history_money']); ?></td>-->
                            <td><?php echo htmlentities(date("Y-m-d",!is_numeric($user['created_at'])? strtotime($user['created_at']) : $user['created_at'])); ?><br><?php echo htmlentities(date("H:i:s",!is_numeric($user['created_at'])? strtotime($user['created_at']) : $user['created_at'])); ?></td>
                            <td><input type="checkbox" name="recommend" value="<?php echo htmlentities($user['user_id']); ?>" lay-skin="switch" lay-filter="recommend" <?php if($user['is_recommend'] == 1): ?>checked<?php endif; ?>></td>
                            <td><input type="checkbox" name="top" value="<?php echo htmlentities($user['user_id']); ?>" lay-skin="switch" lay-filter="top" <?php if($user['is_freeze'] == 1): ?>checked<?php endif; ?>></td>
                            <td class="td-manage">
                                <a title="佣金明细" class="layui-btn layui-btn-xs layui-btn-success" onclick="xadmin.open('查看佣金明细','/admin/expert/details/<?php echo htmlentities($user['user_id']); ?>','','',true)" href="javascript:;">
                                    佣金明细</a>
                                <a title="查看下级" class="layui-btn layui-btn-xs layui-btn-primary" onclick="xadmin.open('查看下级','/admin/expert/person/<?php echo htmlentities($user['user_id']); ?>','','',true)" href="javascript:;">
                                    查看下级</a>
                                <br>
                                <a title="冻结违规佣金" class="layui-btn layui-btn-xs layui-btn-danger deal-money" data-id="<?php echo htmlentities($user['user_id']); ?>" href="javascript:;">
                                    冻结违规佣金</a>
                                <a title="虚拟调整总佣金" class="layui-btn layui-btn-xs layui-btn-warm deal-money2" data-id="<?php echo htmlentities($user['user_id']); ?>" data-money="<?php echo htmlentities($user['yesterday_money']); ?>" href="javascript:;">
                                    虚拟改佣金</a>
                                <br>
                                <a title="详情" class="layui-btn layui-btn-xs layui-btn-primary" onclick="xadmin.open('达人详情','/admin/expert/expertDetail/<?php echo htmlentities($user['user_id']); ?>','','',true)" href="javascript:;">
                                    详情</a>
                                <a title="素材管理" class="layui-btn layui-btn-xs layui-btn" onclick="xadmin.open('素材管理','/admin/expert/wallpaper?user_id=<?php echo htmlentities($user['user_id']); ?>','','',true)" href="javascript:;">
                                    素材管理</a>
                            </td>
                        </tr>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="layui-card-body ">
                    <?php echo $page; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<div id="id" style="display: none">
    <div style="margin-top: 30px"></div>
    <form class="layui-form topic-form layui-col-space10">
        <div style="color:red;margin-left: 50px">这里冻结用户待结算及待发放的佣金数据</div>
        <div class="layui-col-md10">
            <div class="layui-form-item">
                <label for="username" class="layui-form-label">
                    <span class="x-red">*</span>冻结开始时间</label>
                <div class="layui-input-inline">
                    <input type="text" id="deal-time" name="deal_start"  required="" lay-verify="required" autocomplete="off" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label for="username" class="layui-form-label">
                    <span class="x-red">*</span>冻结结束时间</label>
                <div class="layui-input-inline">
                    <input type="text" id="deal-time2" name="deal_end"  required="" lay-verify="required" autocomplete="off" class="layui-input">
                </div>
            </div>
            <input type="hidden" name="user_id" class="frooze-user">
            <div class="layui-form-item">
                <label for="L_repass" class="layui-form-label"></label>
                <button class="layui-btn" lay-filter="add" lay-submit="">确认冻结</button></div>
        </div>
    </form>
</div>
<div id="id2" style="display: none">
    <div style="margin-top: 30px"></div>
    <form class="layui-form topic-form2 layui-col-space10">
        <div class="layui-col-md10">
            <div class="layui-form-item">
                <label for="username" class="layui-form-label">
                    <span class="x-red">*</span>新总佣金</label>
                <div class="layui-input-inline">
                    <input type="text" id="new-money" name="new_money" required="" lay-verify="required" autocomplete="off" class="layui-input">
                    <p style="color:red">该佣金只是修改用户昨日真实佣金，只影响总排名，不影响用户真实获取的佣金，用于虚拟调整排行榜功能</p>
                </div>
            </div>
            <input type="hidden" name="user_id" class="frooze-user2">
            <div class="layui-form-item">
                <label for="L_repass" class="layui-form-label"></label>
                <button class="layui-btn" lay-filter="add2" lay-submit="">确认修改</button></div>
        </div>
    </form>
</div>

<div id="teamId" style="display: none">
    <div style="color:red;margin-left: 50px;margin-top: 20px">注意：转移上级，会将当前达人转入新的达人团队中</div>
    <form class="layui-form team-form layui-col-space10">
        <div class="layui-col-md10">
            <div class="layui-form-item">
                <label for="username" class="layui-form-label">
                    <span class="x-red">*</span>新上级</label>
                <div class="layui-input-inline">
                    <input type="text" id="higher-code" name="higher-code" placeholder="输入口令查询" required="" lay-verify="required" autocomplete="off" class="layui-input">
                </div>
                <div class="layui-form-mid layui-word-aux search-team" style="cursor: pointer">查询上级</div>
            </div>
            <div class="layui-form-item layui-form-text higher-div" style="display: none">
                <label for="desc" class="layui-form-label">
                    上级信息</label>
                <div class="layui-input-block">
                    <div class="banner-show" style="width: 200px;margin-top: 5px"><img src="" style="width: auto;max-width: 100%;max-height: 100%"></div>
                    <div>上级昵称：<span class="higher-name"></span></div>
                </div>
            </div>
            <input type="hidden" name="user_id" class="team-user">
            <input type="hidden" name="fir_distribution" class="team-higher">
            <div class="layui-form-item">
                <label for="L_repass" class="layui-form-label"></label>
                <button class="layui-btn" lay-filter="add3" lay-submit="">确认修改</button></div>
        </div>
    </form>
</div>
</body>
<script>
    layui.use(['form', 'layer'],function () {
        $ = layui.jquery;
        var form = layui.form,
            layer = layui.layer;

        form.on('submit(add)',
            function(data) {
                var index = layer.load(1); //添加laoding,0-2两种方式
                $.post("/admin/expert/money",$('.topic-form').serialize(),function (res) {
                    layer.close(index)
                    if(res.error_code != 0){
                        layer.msg(res.msg,{icon:5});
                    }else{
                        //发异步，把数据提交给php
                        layer.msg("操作成功", {
                                icon: 6
                            },
                            function() {
                                window.location.reload();

                            });
                    }
                },'json')
                return false;
            });
        form.on('submit(add2)',
            function(data) {
                var index = layer.load(1); //添加laoding,0-2两种方式
                $.post("/admin/expert/money/update",$('.topic-form2').serialize(),function (res) {
                    layer.close(index)
                    if(res.error_code != 0){
                        layer.msg(res.msg,{icon:5});
                    }else{
                        //发异步，把数据提交给php
                        layer.msg("操作成功", {
                                icon: 6
                            },
                            function() {
                                window.location.reload();

                            });
                    }
                },'json')
                return false;
            });

        form.on('submit(add3)',
            function(data) {
                var index = layer.load(1); //添加laoding,0-2两种方式
                $.post("/admin/expert/changeTeam",$('.team-form').serialize(),function (res) {
                    layer.close(index)
                    if(res.error_code != 0){
                        layer.msg(res.msg,{icon:5});
                    }else{
                        //发异步，把数据提交给php
                        layer.msg("操作成功", {
                                icon: 6
                            },
                            function() {
                                window.location.reload();

                            });
                    }
                },'json')
                return false;
            });

        $('.deal-money').click(function () {
            var _id = $(this).data('id')
            $('.frooze-user').val(_id)
            layer.open({
                type: 1,
                title:'佣金冻结操作',
                area:['800px','500px'],
                content: $('#id') //注意，如果str是object，那么需要字符拼接。
            })
        })
        $('.deal-money2').click(function () {
            var _id = $(this).data('id')
            $('.frooze-user2').val(_id)
            $('#new-money').val($(this).data('money'))
            layer.open({
                type: 1,
                title:'佣金冻结操作',
                area:['800px','500px'],
                content: $('#id2') //注意，如果str是object，那么需要字符拼接。
            })
        })

        //改变上级
        $('.changeTeam').click(function () {
            var _id = $(this).data('id')
            $('.team-user').val(_id)
            layer.open({
                type: 1,
                title:'转移上级',
                area:['800px','500px'],
                content: $('#teamId') //注意，如果str是object，那么需要字符拼接。
            })
        })
        //查询上级
        $('.search-team').click(function (){
            let _code = $('input[name=higher-code]').val()
            if(_code == '' || _code == undefined){
                layer.msg('请输入上级口令');return false;
            }
            var index = layer.load(1); //添加laoding,0-2两种方式
            //删掉旧数据先
            $('.banner-show').find('img').prop('src','')
            $('.team-higher').val(0)
            $('.higher-name').text('')
            $('.higher-div').css('display','none')
            $.post("/admin/expert/searchHigher",{code:_code},function (res) {
                layer.close(index)
                if(res.error_code != 0){
                    layer.msg(res.msg,{icon:5});
                }else{
                    $('.banner-show').find('img').prop('src',res.data.user_headimg)
                    $('.team-higher').val(res.data.user_id)
                    $('.higher-name').text(decodeURIComponent(res.data.user_nickname))
                    $('.higher-div').css('display','')
                }
            },'json')
        })


        //监听冻结操作
        form.on('switch(top)', function(obj){
            var _val = obj.elem.checked == true ? 1:0
            $.post('/admin/expert/freeze',{id:this.value,status:_val},{},function (data) {
                if(data.error_code == 0){
                    layer.tips('修改成功', obj.othis);
                }else{
                    layer.tips('修改失败',obj.othis);
                }
            },"json")
        });
        //监听推荐操作
        form.on('switch(recommend)', function(obj){
            var _val = obj.elem.checked == true ? 1:0
            $.post('/admin/expert/recommend',{id:this.value,status:_val},{},function (data) {
                if(data.error_code == 0){
                    layer.tips('修改成功', obj.othis);
                }else{
                    layer.tips('修改失败',obj.othis);
                }
            },"json")
        });
    })
    layui.use('laydate', function(){
        var laydate = layui.laydate;

        //执行一个laydate实例
        laydate.render({
            elem: '#test1' //指定元素
        });
    });
    layui.use('laydate', function(){
        var laydate = layui.laydate;

        //执行一个laydate实例
        laydate.render({
            elem: '#deal-time' //指定元素
        });
    });
    layui.use('laydate', function(){
        var laydate = layui.laydate;

        //执行一个laydate实例
        laydate.render({
            elem: '#deal-time2' //指定元素
        });
    });

</script>
</html>
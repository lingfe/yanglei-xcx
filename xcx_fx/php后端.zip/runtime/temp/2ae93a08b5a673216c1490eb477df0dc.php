<?php /*a:2:{s:73:"/www/wwwroot/img.qutubao.com/php/application/backend/view/user/index.html";i:1635745947;s:81:"/www/wwwroot/img.qutubao.com/php/application/backend/view/base/common_header.html";i:1647852764;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">

<head>
    <meta charset="UTF-8">
<title>壁纸小程序后台管理</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" href="/static/css/font.css">
<link rel="stylesheet" href="/static/css/xadmin.css">
<!-- <link rel="stylesheet" href="./css/theme5.css"> -->
<script src="/static/lib/layui/layui.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/xadmin.js"></script>
<!--<script type="text/javascript" src="/static/js/jquery.min.js"></script>-->
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="/static/js/html5.min.js"></script>
<script src="/static/js/respond.min.js"></script>
<![endif]-->
<script>
    // 是否开启刷新记忆tab功能
    var is_remember = false;
</script>
    <style>
        .layui-table td, .layui-table th { min-width: auto; }
    </style>
</head>

<body>
<div class="x-nav">
            <span class="layui-breadcrumb">
                <a href="/admin">首页</a>
                <a href="/admin/user">用户信息</a>
            </span>
    <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" onclick="location.reload()" title="刷新">
        <i class="layui-icon layui-icon-refresh" style="line-height:30px"></i>
    </a>
</div>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-body ">
                    <form class="layui-form layui-col-space5">
                        <div class="layui-input-inline layui-show-xs-block">
                            <select name="platform">
                                <option value="" <?php if($platform == ''): ?>selected<?php endif; ?>>全部平台</option>
                                <option value="qq" <?php if($platform == 'qq'): ?>selected<?php endif; ?>>QQ</option>
                                <option value="wx" <?php if($platform == 'wx'): ?>selected<?php endif; ?>>微信</option>
                                <option value="dy" <?php if($platform == 'dy'): ?>selected<?php endif; ?>>抖音</option>
                                <option value="ks" <?php if($platform == 'ks'): ?>selected<?php endif; ?>>快手</option>
                            </select>
                        </div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <input type="text" value="<?php echo htmlentities($user_id); ?>" name="user_id" placeholder="请输入用户ID" autocomplete="off" class="layui-input"></div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <input type="text" value="<?php echo htmlentities($name); ?>" name="name" placeholder="请输入用户名" autocomplete="off" class="layui-input"></div>
                       <div class="layui-input-inline layui-show-xs-block">
                            <button class="layui-btn" lay-submit="" lay-filter="sreach">
                                <i class="layui-icon">&#xe615;</i></button>
                        </div>
                    </form>
                </div>
                <div class="layui-card-body ">
                    <?php if($is_super == 1): ?>
                    <p style="font-size: 20px;color:red">全站人数为：<?php echo htmlentities($total_user); ?></p>
                    <p style="font-size: 20px;color:red">昨日新增人数为：<?php echo htmlentities($yesterday_user); ?></p>
                    <?php endif; ?>
                    <table class="layui-table layui-form">
                        <thead>
                        <tr>
                            <th>用户ID</th>
                            <th>平台</th>
                            <th>用户昵称</th>
                            <th>用户头像</th>
                            <th>注册时间</th>
                        </thead>
                        <tbody>
                        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$user): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <td><?php echo htmlentities($user['user_id']); ?></td>
                            <td><?php if($user['platform'] == 'qq'): ?>QQ<?php endif; if($user['platform'] == 'wx'): ?>微信<?php endif; if($user['platform'] == 'dy'): ?>抖音<?php endif; if($user['platform'] == 'ks'): ?>快手<?php endif; ?>
                            </td>
                            <td><?php echo htmlentities(urldecode($user['nickname'])); ?><br/><?php echo htmlentities($user['openid']); ?></td>
                            <td><?php if(!empty($user['avatar_url'])): ?><img src="<?php echo htmlentities($user['avatar_url']); ?>" width="80px" height="80px"><?php endif; ?></td>
                            <td><?php echo htmlentities($user['created_at']); ?></td>

                        </tr>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="layui-card-body ">
                    <?php echo $page; ?>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
<script>
    layui.use(['form', 'layer'],function () {
        $ = layui.jquery;
        var form = layui.form,
            layer = layui.layer;


    })


</script>
</html>
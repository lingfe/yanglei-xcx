<?php /*a:2:{s:86:"/www/wwwroot/cs.dyhot.cn/php-retail/application/backend/view/expert/expert_detail.html";i:1639103961;s:84:"/www/wwwroot/cs.dyhot.cn/php-retail/application/backend/view/base/common_header.html";i:1635745947;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">

<head>
  <meta charset="UTF-8">
<title>壁纸小程序后台管理</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" href="/static/css/font.css">
<link rel="stylesheet" href="/static/css/xadmin.css">
<!-- <link rel="stylesheet" href="./css/theme5.css"> -->
<script src="/static/lib/layui/layui.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/xadmin.js"></script>
<!--<script type="text/javascript" src="/static/js/jquery.min.js"></script>-->
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="/static/js/html5.min.js"></script>
<script src="/static/js/respond.min.js"></script>
<![endif]-->
<script>
    // 是否开启刷新记忆tab功能
    // var is_remember = false;
</script>
  <style>
    .layui-table td, .layui-table th { min-width: auto; }
  </style>
</head>

<body>
<div class="layui-fluid">
  <div class="layui-row layui-col-space15">
    <div class="layui-col-md12">
      <div class="layui-card">
        <form class="layui-form topic-form layui-col-space10">
          <div class="layui-form-item">
            <label for="username" class="layui-form-label">
              达人微信号</label>
            <div class="layui-input-inline">
              <input type="text"  value="<?php echo htmlentities($info['wechat_num']); ?>" name="wechat_num" required="" lay-verify="required"  autocomplete="off" class="layui-input">
            </div>
          </div>
          <div class="layui-form-item">
            <label for="username" class="layui-form-label">
              达人手机号</label>
            <div class="layui-input-inline">
              <input type="text"  value="<?php echo htmlentities($info['user_phone']); ?>" name="user_phone" required="" lay-verify="required"  autocomplete="off" class="layui-input">
            </div>
          </div>
          <div class="layui-form-item">
            <label for="username" class="layui-form-label">
              达人昵称</label>
            <div class="layui-input-inline">
              <input type="text"  value="<?php echo htmlentities(urldecode($info['user_nickname'])); ?>" name="user_nickname" required="" lay-verify="required"  autocomplete="off" class="layui-input">
            </div>
          </div>
          <div class="layui-form-item">
            <label for="username" class="layui-form-label">
              图集搜索口令</label>
            <div class="layui-input-inline">
              <input type="text"  value="<?php echo htmlentities($info['user_code']); ?>" name="user_code" required="" lay-verify="required"  autocomplete="off" class="layui-input">
            </div>
          </div>
          <div class="layui-form-item layui-form-text">
            <label for="desc" class="layui-form-label">
              <span class="x-red">*</span>达人头像</label>
            <div class="layui-input-block">
              <div class="banner-show" style="width: 200px;margin-top: 5px"><img src="<?php echo htmlentities($info['user_headimg']); ?>" style="width: auto;max-width: 100%;max-height: 100%"></div>
            </div>
          </div>
          <div class="layui-form-item">
            <label for="username" class="layui-form-label">
              权重</label>
            <div class="layui-input-inline">
              <input type="number" value="<?php echo htmlentities($info['weight']); ?>" id="weight" name="weight"  autocomplete="off" class="layui-input">
              <p style="color: red">请输入0-100000 之间的数值，设置越大排序越靠前</p>
            </div>
          </div>
          <div class="layui-form-item">
            <label class="layui-form-label">
              <span class="x-red">*</span>是否通过</label>
            <div class="layui-input-block">
              <input type="radio"  name="is_reviewed" value="1" title="通过" checked>
              <input type="radio"  name="is_reviewed" value="2" title="驳回" >
            </div>
          </div>
          <div class="layui-form-item">
            <input type="hidden" name="user_id" value="<?php echo htmlentities($info['user_id']); ?>">
            <label for="L_repass" class="layui-form-label"></label>
            <button class="layui-btn" lay-filter="add" lay-submit="">操作</button></div>
        </form>
      </div>
    </div>
  </div>
</div>
</body>
<script>
  layui.use(['form', 'layer'],
          function() {
            $ = layui.jquery;
            var form = layui.form,
                    layer = layui.layer;
            //监听提交
            form.on('submit(add)',
                    function(data) {
                      $.post("/admin/expert/expertDetailDeal",$('.topic-form').serialize(),function (res) {
                        if(res.error_code != 0){
                          layer.msg(res.msg,{icon:5});
                        }else{
                          //发异步，把数据提交给php
                          layer.msg("操作成功", {
                                    icon: 6
                                  },
                                  function() {
                                    // 获得frame索引
                                    var index = parent.layer.getFrameIndex(window.name);
                                    //关闭当前frame
                                    parent.layer.close(index);
                                    window.parent.location.reload();
                                  });
                        }
                      },'json')
                      return false;
                    });
          })


</script>

</html>
<?php /*a:3:{s:83:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/login/user_register.html";i:1642560402;s:74:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/base/title.html";i:1638609045;s:74:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/base/h5_v2.html";i:1641441303;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?php echo htmlentities($platform_name); ?></title>
<link rel="stylesheet" href="/static/h5/dist/css/index.min.css?v=1.2.10">
<?php if(empty($isMobile)): ?>
<style>
    body {
        max-width: 420px !important;
        margin: 0 auto !important;
    }
    @media screen and (min-width: 420px) {
        .material-btns,
        .footer-tab {
            max-width: 420px !important;
            left: auto !important;
            right: auto !important;
        }
        .float-home {
            left: 50% !important;
            margin-left: 150px !important;
            width: 50px;
        }
    }
</style>
<?php endif; ?>

<!--<script type="text/javascript" src="/static/h5/new_dist/scripts/form.min.js"></script>-->
<!--<script src="https://cdn.bootcss.com/vConsole/3.3.4/vconsole.min.js"></script>-->

<!--<script>-->



<!--    var vConsole =new VConsole();-->

<!--    console.log(1230);-->

<!--</script>-->
  <meta name="viewport" content="width=device-width,target-densitydpi=high-dpi,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link rel="stylesheet" href="/static/h5/dist/scripts/libs/swiper-bundle.min.css">
  <link rel="stylesheet" href="/static/h5/dist/scripts/libs/need/layer.css">
  <link rel="stylesheet" href="/static/h5/dist/scripts/libs/weui/weui.min.css">
  <link rel="stylesheet" href="/static/h5_v2/css/v2.css?v=1.1.38" type="text/css">
  <script src="/static/lib/layui/layui.js" charset="utf-8"></script>
  <link id="layuicss-layer" rel="stylesheet" href="/static/lib/layui/css/modules/layer/default/layer.css?v=3.1.1" media="all"></head>
<body>
<div class="login">
  <div class="login-t">
    <div class="login-tc">
      <h1>你好，小伙伴</h1>
      <h2>欢迎注册<?php echo htmlentities($platform_name); ?></h2>
    </div>
    <img src="/static/h5_v2/images/login.jpg" />
  </div>
  <form id="loginForm">
    <div class="login-c">
      <div class="form-item">
        <input type="text" placeholder="手机号码" name="user_phone" />
        <button type="button" class="btn-code" id="btn-code">获取验证码</button>
      </div>
      <div class="form-item">
        <input type="text" placeholder="图形验证码" name="img_code" />
        <img class="codeimg" style="width: 110px;height: 40px;" src="/common/verify.html" onclick='this.src=this.src+"?"+Math.random()'/>
      </div>
      <input type="hidden" name="type" value="3">
      <div class="form-item">
        <input type="text" placeholder="短信验证码" name="phone_code"/>
      </div>
      <div class="form-item">
        <input type="password" placeholder="登陆密码" name="pwd"/>
      </div>
      <div class="form-item">
        <input type="text" placeholder="邀请码" name="user_code"/>
      </div>
      <button type="button" class="btn-submit">注册</button>

    </div>
  </form>
  <div class="login-nav">
    <a href="/userLogin?callbackUrl=<?php echo htmlentities($url2); ?>">手机登陆</a>
    <span></span>
    <a href="/userLoginPwd?callbackUrl=<?php echo htmlentities($url2); ?>">密码登陆</a>
  </div>
</div>
<script type="text/javascript" src="/static/h5/dist/scripts/libs/zepto.min.js"></script>
<script type="text/javascript">
  layui.use(['form', 'layer'],
          function() {
            $ = layui.jquery;
            var form = layui.form,
                    layer = layui.layer;
          })
  var $btnCode = $('#btn-code');
  var isSending = false;
  var timeNum = 60;
  var timeout = null;

  function countDownStart() {
    if (timeNum < 1) {
      timeNum = 60;
      isSending = false;
      $btnCode.html('获取验证码').removeClass('disabled');
    } else {
      $btnCode.html(timeNum + 's后重新发送').addClass('disabled');
      timeNum --;
      timeout && clearTimeout(timeout);
      timeout = setTimeout(function() {
        countDownStart();
      }, 1000);
    }
  }

  $btnCode.on('click', function() {
    let _phone = $('input[name="user_phone"]').val()
    let _code = $('input[name="img_code"]').val()

    if(_phone ==''){layer.msg('请输入手机号');return false;}
    let mg =/^1[3456789]{1}\d{9}$/
    if(!mg.exec(_phone)){layer.msg('手机号码有误');return false;}
    if(_code == ''){layer.msg('请输入图形验证码');return false;}

    if (isSending) return;
    $.post('/api/sms/send',{phone:_phone,code:_code,type:2},function (r){
      if(r.code == 0){
        isSending = true;
        countDownStart();
      }
      else{
        layer.msg(r.msg)
      }
    },'json')
  });

  $('.btn-submit').on('click',function (){
    let _ur = '<?php echo htmlentities($url); ?>'
    let _phone = $('input[name="user_phone"]').val()
    let _code = $('input[name="phone_code"]').val()
    let _pwd = $('input[name="pwd"]').val()
    let _userCode = $('input[name="user_code"]').val()
    if(_phone ==''){layer.msg('请输入手机号');return false;}
    let mg =/^1[3456789]{1}\d{9}$/
    if(!mg.exec(_phone)){layer.msg('手机号码有误');return false;}
    if(_code ==''){layer.msg('请输入验证码');return false;}
    if(_pwd == ''){layer.msg('请输入登陆密码');return false;}
    $.post('/userLogin/deal',{phone:_phone,code:_code,pwd:_pwd,type:$('input[name="type"]').val(),user_code:_userCode},function (r){
      if(r.error_code == 0){window.location.href = _ur}
      else{
        layer.msg(r.msg)
      }
    },'json')
  })
</script>
</body>
</html>
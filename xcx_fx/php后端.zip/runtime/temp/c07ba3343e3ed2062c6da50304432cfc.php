<?php /*a:2:{s:88:"/www/wwwroot/cs.dyhot.cn/php-retail/application/backend/view/expert_wallpaper/index.html";i:1644463434;s:84:"/www/wwwroot/cs.dyhot.cn/php-retail/application/backend/view/base/common_header.html";i:1635745947;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">

<head>
    <meta charset="UTF-8">
<title>壁纸小程序后台管理</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" href="/static/css/font.css">
<link rel="stylesheet" href="/static/css/xadmin.css">
<!-- <link rel="stylesheet" href="./css/theme5.css"> -->
<script src="/static/lib/layui/layui.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/xadmin.js"></script>
<!--<script type="text/javascript" src="/static/js/jquery.min.js"></script>-->
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="/static/js/html5.min.js"></script>
<script src="/static/js/respond.min.js"></script>
<![endif]-->
<script>
    // 是否开启刷新记忆tab功能
    // var is_remember = false;
</script>
    <style>
        .layui-table td, .layui-table th { min-width: auto; }
    </style>
</head>

<body>
<div class="x-nav">
            <span class="layui-breadcrumb">
                <a href="/admin">首页</a>
                <a href="/admin/expertWallpaper">素材管理</a>
            </span>
    <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" onclick="location.reload()" title="刷新">
        <i class="layui-icon layui-icon-refresh" style="line-height:30px"></i>
    </a>
</div>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-body ">
                    <form class="layui-form layui-col-space5">
                        <div class="layui-input-inline layui-show-xs-block">
                            <select name="type">
                                <option value="0" <?php if($type == 0): ?>selected<?php endif; ?>>全部类型</option>
                                <option value="1" <?php if($type == 1): ?>selected<?php endif; ?>>手机壁纸</option>
                                <option value="2" <?php if($type == 2): ?>selected<?php endif; ?>>动态壁纸</option>
                                <option value="3" <?php if($type == 3): ?>selected<?php endif; ?>>背景图</option>
                                <option value="4" <?php if($type == 4): ?>selected<?php endif; ?>>头像</option>
                                <option value="5" <?php if($type == 5): ?>selected<?php endif; ?>>表情包</option>
                            </select>
                        </div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <select name="status">
                                <option value="0" <?php if($status == 0): ?>selected<?php endif; ?>>全部状态</option>
                                <option value="1" <?php if($status == 1): ?>selected<?php endif; ?>>已通过</option>
                                <option value="2" <?php if($status == 2): ?>selected<?php endif; ?>>审核中</option>
                                <option value="3" <?php if($status == 3): ?>selected<?php endif; ?>>未通过</option>
                                <option value="4" <?php if($status == 4): ?>selected<?php endif; ?>>下架</option>
                            </select>
                        </div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <input type="text" value="<?php echo htmlentities($title); ?>" name="title" placeholder="输入达人id，达人管理里的用户id" autocomplete="off" class="layui-input" style="width: 200px"></div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <input type="text" value="<?php echo htmlentities($name); ?>" name="name" placeholder="请输入达人口令" autocomplete="off" class="layui-input"></div>
                        <div class="layui-input-inline layui-show-xs-block">
                            <button class="layui-btn" lay-submit="" lay-filter="sreach">
                                <i class="layui-icon">&#xe615;</i></button>
                        </div>
                    </form>
                </div>
                <div class="layui-card-body ">
                    <button type="button" class="layui-btn layui-btn layui-btn-sm multi-del" data-status="1">批量同意</button>
                    <button type="button" class="layui-btn layui-btn-danger layui-btn-sm multi-del" data-status="3">批量拒绝</button>
                    <button type="button" class="layui-btn layui-btn-warm layui-btn-sm multi-del" data-status="4">批量下架</button>
                    <button type="button" class="layui-btn layui-btn-primary layui-btn-sm multi-del2">批量删除</button>
                    <p style="color: red">注意在满足条件下进行批量操作，出错自己负责。同意或拒绝待审核的素材、下架已通过的素材</p>
                    <table class="layui-table layui-form">
                        <thead>
                        <tr>
                            <th width="20px"><input type="checkbox" lay-skin="primary"  id="c_all" lay-filter="c_all" title="全部"></th>
                            <th>ID</th>
                            <th>素材名称</th>
                            <th>素材类型</th>
                            <th>作者</th>
                            <th>素材</th>
                            <th>下载数</th>
                            <th>是否置顶</th>
                            <th>状态</th>
                            <th>上传时间</th>
                            <th width="15%">操作</th></tr>
                        </thead>
                        <tbody>
                        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$wallpaper): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <td><input type="checkbox" name="cityId" lay-skin="primary" lay-filter="c_one" class="cityId"  value="<?php echo htmlentities($wallpaper['id']); ?>"></td>
                            <td><?php echo htmlentities($wallpaper['id']); ?></td>
                            <td><?php echo htmlentities($wallpaper['name']); ?></td>
                            <td>
                                <?php if($wallpaper['type'] == 1): ?>手机壁纸<?php endif; if($wallpaper['type'] == 2): ?>动态壁纸<?php endif; if($wallpaper['type'] == 3): ?>背景图<?php endif; if($wallpaper['type'] == 4): ?>头像<?php endif; if($wallpaper['type'] == 5): ?>表情包<?php endif; ?>
                            </td>
                            <td><?php echo htmlentities($wallpaper['expert']['user_code']); ?><br><?php echo htmlentities(urldecode($wallpaper['expert']['user_nickname'])); ?></td>
                            <td><?php if($wallpaper['img']): ?><a href="<?php if($wallpaper['type'] != 2): ?><?php echo htmlentities($wallpaper['img']); else: ?><?php echo htmlentities($wallpaper['video_url']); ?><?php endif; ?>" target="_blank" title="点击查看原图"><img src="<?php echo htmlentities($wallpaper['img']); ?>" <?php if($wallpaper['type'] < 3): ?>width="60px" height="90px"<?php elseif($wallpaper['type'] == 3): ?>width="60px" height="60px"<?php else: ?>width="60px" height="60px"<?php endif; ?>></a><?php endif; ?></td>
                            <td><?php echo htmlentities($wallpaper['download_count']); ?></td>
                            <td><?php if($wallpaper['is_recommend'] == 0): ?>否<?php else: ?>是<?php endif; ?></td>
                            <td>
                                <?php if($wallpaper['status'] == 1): ?>已通过<?php endif; if($wallpaper['status'] == 2): ?>审核中<?php endif; if($wallpaper['status'] == 3): ?>未通过<?php endif; if($wallpaper['status'] == 4): ?>下架<?php endif; ?>
                            </td>
                            <td><?php echo htmlentities($wallpaper['created_at']); ?></td>
                            <td class="td-manage">
                                <?php if($wallpaper['status'] == 2): ?>
                                <a title="通过" class="layui-btn layui-btn-sm" onclick="wallpaper_del(this,'<?php echo htmlentities($wallpaper['id']); ?>',1)" href="javascript:;">
                                    通过</a>
                                <a title="拒绝" class="layui-btn layui-btn-sm layui-btn-danger" onclick="wallpaper_del(this,'<?php echo htmlentities($wallpaper['id']); ?>',3)" href="javascript:;">
                                    拒绝</a>
                                <?php endif; if($wallpaper['status'] == 1): ?>
                                <a title="下架" class="layui-btn layui-btn-sm layui-btn-danger" onclick="wallpaper_del(this,'<?php echo htmlentities($wallpaper['id']); ?>',4)" href="javascript:;">
                                    下架</a>
                                <?php endif; ?>
                                <a title="删除" class="layui-btn layui-btn-sm layui-btn-warm" onclick="topic_del(this,'<?php echo htmlentities($wallpaper['id']); ?>')" href="javascript:;">
                                    删除</a>
                            </td>
                        </tr>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="layui-card-body ">
                    <?php echo $page; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<script>
    layui.use(['form', 'layer'],function () {

        var form = layui.form,
            layer = layui.layer,
        $ = layui.jquery;
        //全选
        form.on('checkbox(c_all)', function (data) {
            var a = data.elem.checked;
            if (a == true) {
                $(".cityId").prop("checked", true);
                form.render('checkbox');
            } else {
                $(".cityId").prop("checked", false);
                form.render('checkbox');
            }

        });

        //有一个未选中全选取消选中
        form.on('checkbox(c_one)', function (data) {
            var item = $(".cityId");
            for (var i = 0; i < item.length; i++) {
                if (item[i].checked == false) {
                    $("#c_all").prop("checked", false);
                    form.render('checkbox');
                    break;
                }
            }
            //如果都勾选了  勾上全选
            var  all=item.length;
            for (var i = 0; i < item.length; i++) {
                if (item[i].checked == true) {
                    all--;
                }
            }
            if(all==0){
                $("#c_all").prop("checked", true);
                form.render('checkbox');}
        });

        $('.multi-del').on('click',function (){
            let _ids = $(".cityId:checked")
            if(_ids.length == 0){layer.msg('请勾选要操作的素材');return false;}

            let _id = []
            $(_ids).each(function (k,v){
                _id.push($(this).val())
            })

            wallpaper_del({},_id.join(","),parseInt($(this).data('status')))


        })

        $('.multi-del2').on('click',function (){
            let _ids = $(".cityId:checked")
            if(_ids.length == 0){layer.msg('请勾选要操作的素材');return false;}

            let _id = []
            $(_ids).each(function (k,v){
                _id.push($(this).val())
            })

            topic_del({},_id.join(","))


        })
    })
function wallpaper_del(obj, id,status) {
    layer.confirm('确认要操作吗？',
        function(index) {
            //发异步操作数据
            $.post('/admin/expertWallpaper/deal',{id:id,status:status},function (data) {
                console.log(data)
                if(data.error_code == 0){
                    layer.msg('操作成功!', {
                        icon: 1,
                        time: 1000
                    },function () {
                        window.location.reload()
                    });
                }else{
                    layer.msg('操作失败!', {
                        icon: 1,
                        time: 1000
                    });
                }
            },"json")

        });
}

    function topic_del(obj, id) {
        layer.confirm('确认要删除吗？',
            function(index) {
                //发异步删除数据
                $.post('/admin/expertWallpaper/del',{id:id},function (data) {
                    console.log(data)
                    if(data.error_code == 0){
                        layer.msg('操作成功!', {
                            icon: 1,
                            time: 1000
                        },function () {
                            window.location.reload()
                            // window.location.href = '/admin/expertWallpaper'
                        });
                    }else{
                        layer.msg('操作失败!', {
                            icon: 1,
                            time: 1000
                        });
                    }
                },"json")

            });
    }
</script>

</html>
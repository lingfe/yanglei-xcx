<?php /*a:2:{s:77:"/www/wwwroot/img.qutubao.com/php/application/backend/view/analysis/index.html";i:1641437034;s:81:"/www/wwwroot/img.qutubao.com/php/application/backend/view/base/common_header.html";i:1647852764;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">

<head>
  <meta charset="UTF-8">
<title>壁纸小程序后台管理</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" href="/static/css/font.css">
<link rel="stylesheet" href="/static/css/xadmin.css">
<!-- <link rel="stylesheet" href="./css/theme5.css"> -->
<script src="/static/lib/layui/layui.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/xadmin.js"></script>
<!--<script type="text/javascript" src="/static/js/jquery.min.js"></script>-->
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="/static/js/html5.min.js"></script>
<script src="/static/js/respond.min.js"></script>
<![endif]-->
<script>
    // 是否开启刷新记忆tab功能
    var is_remember = false;
</script>
  <style>
    .layui-table td, .layui-table th { min-width: auto; }
  </style>
  <style type="text/css">
    .auth h5 {
      margin: 20px 0;
      color: #999;
    }
    .auth-body {
      overflow: hidden;
      margin-top: 10px;
    }
    .auth-body-code {
      float: left;
      width: 30%;
      margin-right: 5%;
    }
    .auth-body-code img {
      display: block;
      width: 100%;
    }
    .auth-body-desc {
      float: left;
      width: 65%;
      color: #999;
    }
    .auth-body-desc dt {
      color: #333;
    }
    .auth-body-desc p {
      margin-top: 5px;
    }

    .layui-this{
      background-color: #009688;
    }
  </style>
</head>

<body>
<div class="layui-fluid">
  <div class="layui-row layui-col-space15">
    <div class="layui-col-md12">
      <div class="layui-card">
        <div class="layui-card-body ">
          <ul class="layui-tab-title">
            <li class="<?php if($id == 'dy'): ?>layui-this <?php endif; ?> " onclick="changeModule(this)" data-module="dy">抖音数据</li>
            <li class="<?php if($id == 'ks'): ?>layui-this <?php endif; ?> " onclick="changeModule(this)" data-module="ks">快手数据</li>
            <li class="<?php if($id == 'wx'): ?>layui-this <?php endif; ?> " onclick="changeModule(this)" data-module="wx">微信数据</li>
            <li class="<?php if($id == 'qq'): ?>layui-this <?php endif; ?> " onclick="changeModule(this)" data-module="qq">QQ数据</li>
          </ul>
        </div>
        <div class="layui-card-body ">
          <div class="layui-btn-group" id="fansFilter">
            <button type="button" class="layui-btn layui-btn-primary" data-value="7" onclick="datetab(7,this)">近7天</button>
            <button type="button" class="layui-btn" data-value="30" onclick="datetab(30,this)">30天</button>
          </div>
          <div id="main" style="width: 100%;height:500px;margin-top:50px;"></div>
        </div>
        <div class="layui-card-body ">
          <p>近60天的具体明细</p>
          <table class="layui-table layui-form">
            <thead>
            <tr>
              <th>进入小程序次数</th>
              <th>进入素材详情页次数</th>
              <th>点击看广告下载次数</th>
              <th>点击普通下载次数</th>
              <th>看完广告次数（达人素材）</th>
              <th>看完广告次数（平台素材）</th>
              <th>未正常看完广告的次数</th>
              <th>广告加载异常次数</th>
              <th>真实下载次数</th>
              <th>时间</th>
            </tr>
            </thead>
            <tbody>
            <?php if(is_array($thirtyDataOld) || $thirtyDataOld instanceof \think\Collection || $thirtyDataOld instanceof \think\Paginator): $i = 0; $__LIST__ = $thirtyDataOld;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <tr>
              <td><?php echo htmlentities($vo['enter_num']); ?></td>
              <td><?php echo htmlentities($vo['wallpaper_num']); ?></td>
              <td><?php echo htmlentities($vo['ad_num']); ?></td>
              <td><?php echo htmlentities($vo['normal_num']); ?></td>
              <td><?php echo htmlentities($vo['ad_end']); ?></td>
              <td><?php echo htmlentities($vo['ad_end_platform']); ?></td>
              <td><?php echo htmlentities($vo['ad_stop']); ?></td>
              <td><?php echo htmlentities($vo['ad_error']); ?></td>
              <td><?php echo htmlentities($vo['total_download']); ?></td>
              <td><?php echo htmlentities($vo['created_format']); ?></td>
            </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
<script type="text/javascript" src="/static/js/echarts.min.js"></script>
<script>
  var dateRange,enterNum,wallpaperNum,adNum,normalNum,adEnd,adEndPlatform,adStop,adError,totalDownload;
  function datetab(n,self){
    if(self != null){$(self).addClass('layui-btn-primary').siblings().removeClass('layui-btn-primary');}
    switch(n){

      case 7:
        dateRange = <?php echo json_encode(array_column($sevenData,'created_format')); ?>;
        enterNum = <?php echo json_encode(array_column($sevenData,'enter_num'));  ?>;
        wallpaperNum = <?php echo json_encode(array_column($sevenData,'wallpaper_num'));  ?>;
        adNum  = <?php echo json_encode(array_column($sevenData,'ad_num'));  ?>;
        normalNum = <?php echo json_encode(array_column($sevenData,'normal_num'));  ?>;
        adEnd = <?php echo json_encode(array_column($sevenData,'ad_end'));  ?>;
        adEndPlatform = <?php echo json_encode(array_column($sevenData,'ad_end_platform'));  ?>;
        adStop = <?php echo json_encode(array_column($sevenData,'ad_stop'));  ?>;
        adError = <?php echo json_encode(array_column($sevenData,'ad_error'));  ?>;
        totalDownload = <?php echo json_encode(array_column($sevenData,'total_download'));  ?>;
        break;
    case 30:
        dateRange = <?php echo json_encode(array_column($thirtyData,'created_format')); ?>;
        enterNum = <?php echo json_encode(array_column($thirtyData,'enter_num'));  ?>;
        wallpaperNum = <?php echo json_encode(array_column($thirtyData,'wallpaper_num'));  ?>;
        adNum  = <?php echo json_encode(array_column($thirtyData,'ad_num'));  ?>;
        normalNum = <?php echo json_encode(array_column($thirtyData,'normal_num'));  ?>;
        adEnd = <?php echo json_encode(array_column($thirtyData,'ad_end'));  ?>;
        adEndPlatform = <?php echo json_encode(array_column($thirtyData,'ad_end_platform'));  ?>;
        adStop = <?php echo json_encode(array_column($thirtyData,'ad_stop'));  ?>;
        adError = <?php echo json_encode(array_column($thirtyData,'ad_error'));  ?>;
        totalDownload = <?php echo json_encode(array_column($thirtyData,'total_download'));  ?>;
        break;
    default:
        dateRange = <?php echo json_encode(array_column($sevenData,'created_format'));  ?>;

  }


  // 基于准备好的dom，初始化echarts实例
          var myChart = echarts.init(document.getElementById('main'));
          // 指定图表的配置项和数据
          var option = {
              title: {
                  text: '数据图表'
              },
              tooltip: {
                  trigger: 'axis',
                  axisPointer: {
                      type: 'cross',
                      label: {
                          backgroundColor: '#6a7985'
                      }
                  }
              },
              legend: {
                  data:['进入小程序次数','进入素材详情页次数','点击看广告下载次数','点击普通下载次数','看完广告次数(达人素材)','看完广告次数(平台素材)','未正常看完广告次数','广告加载异常次数','真实下载次数']
              },
              toolbox: {
                  feature: {
                      saveAsImage: {}
                  }
              },
              grid: {
                  left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: {
      type:'category',
              boundaryGap: false,
              data: dateRange,
              nameGap: 7,
              axisTick: {
        inside: true
      }
    },
    yAxis: {
      minInterval: 1,
              type:'value',
              boundaryGap: false,
    },
    series: [
      {name:"进入小程序次数", areaStyle: {}, type: 'line',data: enterNum },
      {name:"进入素材详情页次数", areaStyle: {}, type: 'line',data: wallpaperNum },
      {name:"点击看广告下载次数", areaStyle: {}, type: 'line',data: adNum },
      {name:"点击普通下载次数", areaStyle: {}, type: 'line',data: normalNum },
      {name:"看完广告次数(达人素材)", areaStyle: {}, type: 'line',data: adEnd },
      {name:"看完广告次数(平台素材)", areaStyle: {}, type: 'line',data: adEndPlatform },
      {name:"未正常看完广告次数", areaStyle: {}, type: 'line',data: adStop },
      {name:"广告加载异常次数", areaStyle: {}, type: 'line',data: adError },
      {name:"真实下载次数", areaStyle: {}, type: 'line',data: totalDownload },
    ]
  };

  // 使用刚指定的配置项和数据显示图表。
  myChart.setOption(option);

  }
  datetab(7,null);



  function changeModule(d){
    let _id = $(d).data('module')
    window.location.href='/admin/analysis?id='+_id
  }

</script>

</html>
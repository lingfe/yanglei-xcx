<?php /*a:2:{s:84:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/wallpaper/create_new.html";i:1644209265;s:74:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/base/title.html";i:1638609045;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title><?php echo htmlentities($platform_name); ?></title>
<link rel="stylesheet" href="/static/h5/dist/css/index.min.css?v=1.2.10">
<?php if(empty($isMobile)): ?>
<style>
    body {
        max-width: 420px !important;
        margin: 0 auto !important;
    }
    @media screen and (min-width: 420px) {
        .material-btns,
        .footer-tab {
            max-width: 420px !important;
            left: auto !important;
            right: auto !important;
        }
        .float-home {
            left: 50% !important;
            margin-left: 150px !important;
            width: 50px;
        }
    }
</style>
<?php endif; ?>

<!--<script type="text/javascript" src="/static/h5/new_dist/scripts/form.min.js"></script>-->
<!--<script src="https://cdn.bootcss.com/vConsole/3.3.4/vconsole.min.js"></script>-->

<!--<script>-->



<!--    var vConsole =new VConsole();-->

<!--    console.log(1230);-->

<!--</script>-->
    <link rel="stylesheet" href="/static/h5/new_dist/css/index.min.css">
    <script src="/static/js/jquery.min.js"></script>
    <script type="text/javascript" src="/static/h5/new_dist/scripts/plugins.min.js"></script>
    <link rel="stylesheet" href="/static/h5/dist/scripts/libs/need/layer.css">
    <script src="/static/lib/layui/layui.js" charset="utf-8"></script>
    <style type="text/css">
        #upload_img_list1,#upload_img_list2,#upload_img_list3,#upload_img_list4,#upload_img_list5 {
            margin: 20px 0 0 0;
            overflow: hidden;width:100%;
        }
        dd {
            position: relative;
            margin: 0 10px 10px 0;
            float: left;
        }
        .operate {
            position: absolute;
            top: 0;
            right: 0;
            z-index: 1
        }
        .operate i {
            cursor: pointer;
            background: #2F4056;
            padding: 2px;
            line-height: 15px;
            text-align: center;
            color: #fff;
            margin-left: 1px;
            float: left;
            filter: alpha(opacity=80);
            -moz-opacity: .8;
            -khtml-opacity: .8;
            opacity: .8
        }
        dd .img {
            height: 100px;
            width: 100px
        }
    </style>
</head>
<body>
<header class="header-normal">
    <a class="back" href="/"></a>
    <h5>上传素材</h5>
    <span></span>
</header>
<section class="page">
    <form name="wallpaperForm" id="wallpaperForm">
        <p class="form-tips">
            交互兼容提示<br/>
            1、苹果手机全部支持多选;<br/>
            2、安卓手机支持多选的浏览器为QQ浏览器、华为浏览器、小米浏览器、三星浏览器、百度浏览器、火狐浏览器等;<br/>
            3、电脑端全部支持多选。

        </p>
        <div class="form-block">
            <label class="form-label first">素材类型：</label>
            <div class="create-type">
                <span class="radio">手机壁纸<input type="hidden" value="1"/></span>
                <span class="radio">动态壁纸<input type="hidden" value="2" /></span>
                <span class="radio">背景图<input type="hidden" value="3" /></span>
                <br/>
                <span class="radio">头像<input type="hidden" value="4" /></span>
                <span class="radio">表情包<input type="hidden" value="5" /></span>
            </div>
        </div>
        <div class="form-block">
            <label class="form-label">先选择素材类型，然后打开相册，选择高清素材：</label>
            <div class="upload-imgs">
                <div class="upload-imgs-btn">
                    <span>+</span><br/>上传素材
                </div>
                <input type="file" multiple="multiple"   accept="image/jpg,image/jpeg,image/png,image/gif,video/mp4" onchange="uploadChoose()">
            </div>
            <div class="show-file" id="upload_img_list1" ></div>
            <div class="show-file" id="upload_img_list2" style="display: none"></div>
            <div class="show-file" id="upload_img_list3" style="display: none"></div>
            <div class="show-file" id="upload_img_list4" style="display: none"></div>
            <div class="show-file" id="upload_img_list5" style="display: none"></div>
            <p class="form-tips tips1">正在上传的图片，总数：<span class="total-ing">0</span>，成功：<span class="success-ing">0</span>，失败：<span class="error-ing">0</span></p>
            <p class="form-tips tips1">提示：仅支持JPG或PNG格式、GIF格式，单个素材不超过5M，一次最多选6个。</p>
            <p class="form-tips tips2" style="display: none">提示：仅支持MP4格式，单个素材不超过10M，一次最多选6个。</p>
            <p class="form-tips">今日总上传限额<span><?php echo htmlentities($day_upload_num); ?></span>个，已上传<span class="day_upload_num"><?php echo htmlentities($userInfo['day_upload_num']); ?></span>个。</p>
        </div>
        <div class="form-block">
            <label class="form-label">标签：</label>
            <div class="create-labels">
                <?php if(is_array($tags) || $tags instanceof \think\Collection || $tags instanceof \think\Paginator): $i = 0; $__LIST__ = $tags;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                <span class="checkbox"><?php echo htmlentities($v); ?><input type="hidden" value="<?php echo htmlentities($key); ?>" /></span>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
            <p class="form-tips">提示：您所上传的图片受云平台及抖音内容管理规范约束，我们将通过技术/人工方式实施内容审查，但仍无法保证完全的合规性，请创作者严格自查图片的合规性。
            </p>
        </div>
        <input type="hidden" name="type">
        <input type="hidden" name="tag_ids">
        <button type="button" class="btn-submit" onclick="submitAction()">上传素材</button>
    </form>
</section>
<script>

    layui.use(['form', 'layer'],
        function() {

            var form = layui.form,
                layer = layui.layer
        })

    var _day_upload_num = parseInt('<?php echo htmlentities($day_upload_num); ?>') //每日上传素材的次数
    var _using_num = parseInt('<?php echo htmlentities($userInfo['day_upload_num']); ?>') //已使用次数

    let _totaling , _successing , _erroring

    $(".radio").on("click",
        function() {
            $(this).toggleClass("active").siblings().removeClass("active")
            let types = '';
            $('.create-type .radio').each(function(k, v) {
                if ($(v).hasClass('active')) {
                    types = $(v).find('input').val();
                }
            });
            types = parseInt(types)
            if(types == 2){$('.tips1').css('display','none');$('.tips2').css('display','');}
            else{$('.tips2').css('display','none');$('.tips1').css('display','');}
            //显示对应素材区域
            $('.show-file').css('display','none')
            $('#upload_img_list'+types).css('display','')
        }),
    $(".checkbox").on("click",
        function() {
            $(this).toggleClass("active")
        });


    var _chooseFile = [];
    // 选择素材
    function uploadChoose() {
        // 获取单选类型d
        let types = '';
        $('.create-type .radio').each(function(k, v) {
            if ($(v).hasClass('active')) {
                types = $(v).find('input').val();
            }
        });
        if (types === '') {$(event.target).val('');return $.$toast('请选择素材类型');}
        if(_day_upload_num <= _using_num) {$(event.target).val('');return $.$toast('今日上传素材额度已用完');}

        //判断当前选的素材是否符合当前所选的素材类型
        let _files = event.target.files;
        for (var i=0;i<_files.length;i++){
            console.log(_files[i].type);
            if(types == 2){
                //视频资源
                if(_files[i].type !='video/mp4') {$(event.target).val('');return $.$toast('您选的素材不符合当前素材类型')}
            }else{
                if(!isAssetTypeAnImage(_files[i].type))  {$(event.target).val('');return $.$toast('您选的素材不符合当前素材类型')}
            }

        }

        // if (_files.length > (_day_upload_num - _using_num)) {
        //     $.$toast('上传数量最多只能'+(_day_upload_num - _using_num)+'个');
        //     $(event.target).val('');
        //     return;
        // }

        if (_files.length > 6) {
            $.$toast('上传数量最多只能6个');
            $(event.target).val('');
            return;
        }

        if(_files.length > 0){
            _chooseFile = Array.prototype.slice.call(_files);
            console.log(_chooseFile);
            _totaling = _files.length
            _successing = 0;_erroring = 0;
            $('.total-ing').text(_totaling)
            $('.success-ing').text(_successing)
            $('.error-ing').text(_erroring)
            uploadFile(_files,types,0)
            $(event.target).val('');
        }
    }

    function uploadFile(file,types, index){
        let _ext = types == 2?'video':'images'
        let _form = new FormData();
        _form.append('file',file[index])
        _form.append('fileType',types)
        _form.append('fileExt',_ext)
        $.ajax({
            url:'/wallpaper/uploadFile',
            type:'POST',
            data:_form,
            dataType:'json',
            async: false,
            cache: false,
            contentType: false, //禁止设置请求类型
            processData: false, //禁止jquery对DAta数据的处理,默认会处理
            success:function (r){
                if(r.error == 0){
                    // _using_num++
                    //根据类型渲染不同模块
                    let _html = '<dd class="item_img">\n' +
                        '                    <div class="operate">\n' +
                        '                        <i onclick="deleteImg(this)" data-type="'+types+'" data-img="'+r.photo+'" data-video="'+r.video_url+'" data-thumb="'+r.thumb_img+'" class="close"><img src="https://wallpaper.xcx.letaohelper.com/static/h5/delete.png"></i>\n' +
                        '                    </div>\n' +
                        '                    <img src="'+r.photo+'" class="img">\n' +
                        '                    <input type="hidden" name="file_type[]" value="'+types+'">\n' +
                        '                    <input type="hidden" name="file_img[]" value="'+r.photo+'">\n' +
                        '                    <input type="hidden" name="file_video[]" value="'+r.video_url+'">\n' +
                        '                    <input type="hidden" name="file_thumb[]" value="'+r.thumb_img+'">\n' +
                        '                </dd>'
                    $('#upload_img_list'+types).append(_html)
                    _successing++
                    $('.success-ing').text(_successing)
                }else{
                    $.$toast(r.msg)
                    _erroring++
                    $('.error-ing').text(_erroring)
                }

                if (index < file.length - 1) {
                    setTimeout(() => {
                        index ++;
                        console.log(_chooseFile, types, index);
                        uploadFile(_chooseFile, types, index);
                    });
                }

            },
            error:function (e){
                $.$toast('素材上传失败');
                _erroring++
                $('.error-ing').text(_erroring)
            }
        })
    }


    function isAssetTypeAnImage(filePath) {
        var index= filePath.lastIndexOf("/");
        //获取后缀
        var ext = filePath.substr(index+1);
        return [
            'png', 'jpg', 'jpeg', 'gif'].
        indexOf(ext.toLowerCase()) !== -1;
    }





    // 提交
    function submitAction() {
        // 获取单选类型
        let types = '';
        $('.create-type .radio').each(function(k, v) {
            if ($(v).hasClass('active')) {
                types = $(v).find('input').val();
            }
        });
        console.log(types)
        if (types === '') return $.$toast('请选择素材类型');

        if($('input[name="file_img[]"]').length === 0) return $.$toast('请上传素材资源');

        // 获取单选类型
        let check_types = [];
        $('.create-labels .checkbox').each(function(k, v) {
            if ($(v).hasClass('active')) {
                check_types.push(parseInt($(v).find('input').val()));
            }
        });


        $('input[name="type"]').val(types)
        $('input[name="tag_ids"]').val(check_types.join(','))
        $.post('/wallpaper/createDeal',$('#wallpaperForm').serialize(),function (r){
            if(r.error_code == 0){
                $.$toast('上传成功，等待平台审核')
                setTimeout(function (){
                    window.location.reload()
                },500)
            }else{
                $.$toast(r.msg)
            }
        },'json')

    }

    //删除素材
    function deleteImg(data) {
        let _img = $(data).data('img'),
            _video = $(data).data('video'),
            _thumb = $(data).data('thumb'),
            _type = $(data).data('type');
        $(data).parents('.item_img').remove()

        $.post('/wallpaper/delFile',{img:_img,video:_video,thumb:_thumb,type:_type},function (r){
            console.log(r);},'json')
    }
</script>
</body>
</html>
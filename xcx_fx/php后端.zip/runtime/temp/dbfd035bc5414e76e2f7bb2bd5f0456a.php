<?php /*a:2:{s:82:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/index/improve_init.html";i:1642560180;s:74:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/base/title.html";i:1638609045;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,target-densitydpi=high-dpi,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <title><?php echo htmlentities($platform_name); ?></title>
<link rel="stylesheet" href="/static/h5/dist/css/index.min.css?v=1.2.10">
<?php if(empty($isMobile)): ?>
<style>
    body {
        max-width: 420px !important;
        margin: 0 auto !important;
    }
    @media screen and (min-width: 420px) {
        .material-btns,
        .footer-tab {
            max-width: 420px !important;
            left: auto !important;
            right: auto !important;
        }
        .float-home {
            left: 50% !important;
            margin-left: 150px !important;
            width: 50px;
        }
    }
</style>
<?php endif; ?>

<!--<script type="text/javascript" src="/static/h5/new_dist/scripts/form.min.js"></script>-->
<!--<script src="https://cdn.bootcss.com/vConsole/3.3.4/vconsole.min.js"></script>-->

<!--<script>-->



<!--    var vConsole =new VConsole();-->

<!--    console.log(1230);-->

<!--</script>-->
    <link rel="stylesheet" href="/static/h5/dist/scripts/libs/swiper-bundle.min.css">
    <link rel="stylesheet" href="/static/h5/dist/scripts/libs/need/layer.css">
    <script type="text/javascript" src="/static/h5/dist/scripts/libs/layer.js"></script>
    <script src="/static/lib/layui/layui.js" charset="utf-8"></script>
</head>
<body>
<section class="tx" style="height: 10%">
    <header class="header">
        <a class="back" href="/user"></a>
        <h5>完善信息</h5>
        <span></span>
    </header>

    <div class="tx-form">
        <div class="tx-form-item">
            <label>微信号</label>
            <input type="text" class="wechat-num" value="<?php echo htmlentities($userInfo['wechat_num']); ?>" <?php if($userInfo['is_reviewed'] == 1): ?>readonly<?php endif; ?> placeholder="请输入微信号码，用于平台和下级联系">
            <p style="color: red;font-size: 1.4rem">注意：审核通过后微信号不可以修改</p>
        </div>
<!--        <div class="tx-form-item">-->
<!--            <label>手机号</label>-->
<!--            <input type="text" class="phone" placeholder="请输入手机号码" value="<?php echo htmlentities($userInfo['user_phone']); ?>" <?php if($userInfo['is_reviewed'] == 1): ?>readonly<?php endif; ?>>-->
<!--            <p style="color: red;font-size: 1.4rem">注意：作为登陆账号使用，审核通过后不可以修改</p>-->
<!--        </div>-->
        <div class="tx-form-item">
            <label>达人昵称</label>
            <input type="text" class="user-nickname" value="<?php echo htmlentities(urldecode($userInfo['user_nickname'])); ?>" placeholder="请输入达人昵称，用于小程序端展现">
        </div>
        <div class="tx-form-item">
            <label>图集搜索口令（邀请码）</label>
            <input type="text" class="user-code" value="<?php echo htmlentities($userInfo['user_code']); ?>" placeholder="请输入专属你的图集搜索口令，注意保持唯一">
            <p style="color: red;font-size: 1.4rem">注意：达人口令只能是数字、字母、下划线组成</p>
        </div>
        <div class="tx-form-item">
            <label>达人头像</label>
            <div class="upload" style="height: 15rem">
                <input type="file" name="file" id="file1">
                <img class="code-pay" <?php if(!empty($userInfo['user_headimg'])): ?>src="<?php echo htmlentities($userInfo['user_headimg']); ?>"<?php else: ?>style="display:none"<?php endif; ?> alt="">
                <span>+</span>
                <input type="hidden" name="user_headimg" class="user-headimg" value="<?php echo htmlentities($userInfo['user_headimg']); ?>">
            </div>
        </div>
        <div class="tx-form-item">
            <label>登陆密码</label>
            <input type="text" class="password" value="" placeholder="请输入用于登陆的密码">
            <p style="color: red;font-size: 1.4rem">注意：若不改新密码则留空</p>
        </div>
        <div class="tx-form-item" style="color: red;font-size: 1.4rem;">请保证资料信息填写正确，若审核不通过则无法使用达人权限</div>
        <button class="tx-submit">确认提交</button>
    </div>
</section>

<script type="text/javascript" src="/static/h5/dist/scripts/libs/zepto.min.js"></script>
<script>


    layui.use(['form', 'layer'],
        function() {
            $ = layui.jquery;
            var form = layui.form,
                layer = layui.layer;


            $('.tx-submit').click(function () {
                var _name = $('.user-nickname').val()
                var _code = $('.user-code').val()
                var _wechat_num = $('.wechat-num').val()
                // var _phone = $('.phone').val()
                var _img = $('.user-headimg').val()
                var _pwd = $('.password').val()

                if(_name == ''){layer.msg('请填写达人昵称',{icon:2});return false;}
                if(_code == ''){layer.msg('请填写图集口令',{icon:2});return false;}
                if(_wechat_num == ''){layer.msg('请填写微信号',{icon:2});return false;}
                // if(_phone == ''){layer.msg('请填写手机号',{icon:2});return false;}
                if(_img == ''){layer.msg('请上传达人头像',{icon:2});return false;}
                // if(_pwd == ''){layer.msg('登陆密码不能为空',{icon:2});return false;}

                $.post('/user/improve',{wechat_num:_wechat_num,user_code:_code,user_headimg:_img,user_nickname:_name,password:_pwd},function (r) {
                    if(r.error_code == 0){
                        layer.msg('完成信息完善',{icon:1},function () {
                            window.location.href = '/user'
                        })
                    }else{
                        layer.msg(r.msg,{icon:2})
                    }
                },'json')

            })
        }
    )


    layui.use('upload', function(){
        var upload = layui.upload;

        //执行实例
        upload.render({
            elem: '#file1' //绑定元素
            ,url: '/api/fileUpload' //上传接口
            ,size: 512
            ,data:{fileType:0}
            ,done: function(res){
                //上传完毕回调
                if(res.code == 1){
                    $('input[name="user_headimg"]').val(res.photo)
                    $('.code-pay').attr('src',res.photo)
                    $('.code-pay').css('display','')
                }else{
                    layer.msg('系统异常，请联系客服');
                }
            }
            ,error: function(){
                //请求异常回调
                layer.msg('上传失败')
            }
        });
    });
</script>
</body>
</html>

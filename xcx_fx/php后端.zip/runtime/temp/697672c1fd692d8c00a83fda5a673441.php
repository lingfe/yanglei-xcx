<?php /*a:2:{s:77:"/www/wwwroot/img.qutubao.com/php/application/backend/view/wallpaper/edit.html";i:1647571631;s:81:"/www/wwwroot/img.qutubao.com/php/application/backend/view/base/common_header.html";i:1647852764;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">

<head>
    <meta charset="UTF-8">
<title>壁纸小程序后台管理</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" href="/static/css/font.css">
<link rel="stylesheet" href="/static/css/xadmin.css">
<!-- <link rel="stylesheet" href="./css/theme5.css"> -->
<script src="/static/lib/layui/layui.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/xadmin.js"></script>
<!--<script type="text/javascript" src="/static/js/jquery.min.js"></script>-->
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="/static/js/html5.min.js"></script>
<script src="/static/js/respond.min.js"></script>
<![endif]-->
<script>
    // 是否开启刷新记忆tab功能
    var is_remember = false;
</script>
    <style>
        .layui-table td, .layui-table th { min-width: auto; }
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <form class="layui-form topic-form layui-col-space10">
                    <div class="layui-form-item">
                        <label for="2" class="layui-form-label"></label>
                            <div class="layui-input-inline" style="width: 300px">
                                <p style="color: red">当前为<?php if($bannerInfo['type'] == 1): ?>手机壁纸<?php endif; if($bannerInfo['type'] == 2): ?>动态壁纸<?php endif; if($bannerInfo['type'] == 3): ?>背景图<?php endif; if($bannerInfo['type'] == 4): ?>头像<?php endif; if($bannerInfo['type'] == 5): ?>表情包<?php endif; ?>类型，不可修改类型</p>
                                <p style="color: red">注意：动态壁纸只能上传mp4文件，每次新增只能处理一种类型，切勿上传错误素材，出问题请删除</p>
                            </div>
                    </div>
                    <div class="layui-form-item">
                        <label for="username" class="layui-form-label">
                            素材名称</label>
                        <div class="layui-input-inline">
                            <input type="text" id="self_name" name="self_name" value="<?php echo htmlentities($bannerInfo['self_name']); ?>"  autocomplete="off" class="layui-input">
                        </div>
                    </div>
                    <div class="layui-form-item layui-form-text">
                        <label for="desc" class="layui-form-label">
                            <span class="x-red">*</span>素材</label>
                        <div class="layui-input-block">
                            <button type="button" class="layui-btn" id="test1">
                                <i class="layui-icon">&#xe67c;</i>上传素材
                            </button>
                            <div class="banner-show" style="width: 200px;margin-top: 5px"><img src="<?php echo htmlentities($bannerInfo['img']); ?>" style="width: auto;max-width: 100%;max-height: 100%"></div>
                            <input type="hidden" name="img" value="<?php echo htmlentities($bannerInfo['img']); ?>" class="banner_img">
                            <input type="hidden" name="video_url" value="<?php echo htmlentities($bannerInfo['video_url']); ?>" class="banner_img2">
                            <input type="hidden" name="thumb_img" value="<?php echo htmlentities($bannerInfo['thumb_img']); ?>" class="banner_img3">
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">
                            <span class="x-red">*</span>是否显示</label>
                        <div class="layui-input-block">
                            <input type="radio"  name="show_index" value="0" title="否" <?php if($bannerInfo['show_index'] == 0): ?>checked<?php endif; ?>>
                            <input type="radio"  name="show_index" value="1" title="是" <?php if($bannerInfo['show_index'] == 1): ?>checked<?php endif; ?>>
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">
                            <span class="x-red">*</span>是否推荐</label>
                        <div class="layui-input-block">
                            <input type="radio"  name="is_recommend" value="0" title="否" <?php if($bannerInfo['is_recommend'] == 0): ?>checked<?php endif; ?>>
                            <input type="radio"  name="is_recommend" value="1" title="是" <?php if($bannerInfo['is_recommend'] == 1): ?>checked<?php endif; ?>>
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label for="username" class="layui-form-label">
                            权重</label>
                        <div class="layui-input-inline">
                            <input type="number" id="weight" name="weight" value="<?php echo htmlentities($bannerInfo['weight']); ?>" autocomplete="off" class="layui-input">
                            <p style="color: red">请输入0-100000 之间的数值，设置越大排序越靠前</p>
                        </div>
                    </div>

                    <?php if($bannerInfo['type'] == 5): ?>
                    <div class="expression-video-div">
                        <div class="layui-form-item layui-form-text">
                            <label for="desc" class="layui-form-label">
                                表情包原视频</label>
                            <div class="layui-input-block">
                                <button type="button" class="layui-btn" id="test4">
                                    <i class="layui-icon">&#xe67c;</i>上传视频
                                </button>
                                <button type="button" class="layui-btn layui-btn-danger del_video">
                                    删除视频
                                </button>
                                <div class="banner-show" style="width: 200px;margin-top: 5px">
                                    <video controls autoplay="autoplay" style="width: auto;max-width: 100%;max-height: 100%;<?php if($bannerInfo['expression_video_url'] == ''): ?>display: none<?php endif; ?>">
                                        <source src="<?php echo htmlentities($bannerInfo['expression_video_url']); ?>">
                                    </video>
                                </div>
                                <input type="hidden" name="expression_video_url" value="<?php echo htmlentities($bannerInfo['expression_video_url']); ?>" class="banner_img">
                                <p style="color: red">若是要上传原视频，只能是单个表情包上传，否则视频会关联多个表情包素材，只能上传mp4文件</p>
                            </div>
                        </div>
<!--                        <div class="layui-form-item">-->
<!--                            <label class="layui-form-label">-->
<!--                                是否显示原视频</label>-->
<!--                            <div class="layui-input-block">-->
<!--                                <input type="radio"  name="expression_show_video" value="0" title="否" <?php if($bannerInfo['expression_show_video'] == 0): ?>checked<?php endif; ?>>-->
<!--                                <input type="radio"  name="expression_show_video" value="1" title="是" <?php if($bannerInfo['expression_show_video'] == 1): ?>checked<?php endif; ?>>-->
<!--                            </div>-->
<!--                        </div>-->
                    </div>
                    <?php endif; ?>

                    <div class="layui-form-item">
                        <input type="hidden" name="id" value="<?php echo htmlentities($bannerInfo['id']); ?>">
                        <label for="L_repass" class="layui-form-label"></label>
                        <button class="layui-btn" lay-filter="add" lay-submit="">更新素材</button></div>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
<script>
    var _type = parseInt('<?php echo htmlentities($bannerInfo['type']); ?>'),_accept='images';
    if(_type == 2){_accept='video'}

    layui.use(['form', 'layer'],
        function() {
            $ = layui.jquery;
            var form = layui.form,
                layer = layui.layer;
            //监听提交
            form.on('submit(add)',
                function(data) {
                    var index = layer.load(1); //添加laoding,0-2两种方式
                    $.post("/admin/wallpaper/deal",$('.topic-form').serialize(),function (res) {
                        layer.close(index)
                        if(res.error_code != 0){
                            layer.msg(res.msg,{icon:5});
                        }else{
                            //发异步，把数据提交给php
                            layer.msg("修改成功", {
                                    icon: 6
                                },
                                function() {
                                    window.parent.location.reload();
                                    // 获得frame索引
                                    var index = parent.layer.getFrameIndex(window.name);
                                    //关闭当前frame
                                    parent.layer.close(index);
                                });
                        }
                    },'json')
                    return false;
                });


            $('.del_video').click(function (){
                $(this).parents('.layui-form-item').find('input[name="video_url"]').val('')
                $(this).parents('.layui-form-item').find('video').attr('src','')
                $(this).parents('.layui-form-item').find('video').css('display','none')
            })
        })

    /**
     * 红包封面banner上传
     * */
    layui.use('upload', function(){
        var upload = layui.upload;

        //执行实例
        upload.render({
            elem: '#test1' //绑定元素
            ,url: '/api/fileUpload' //上传接口
            ,size: 512*2*10//10m
            ,data:{fileType:_type,fileExt:_accept}
            ,accept:"file"
            // ,acceptMime:"image/*"
            ,exts:"jpg|jpeg|gif|png|mp4|mov"
            ,before: function(obj){ //obj参数包含的信息，跟 choose回调完全一致，可参见上文。
                layer.load(); //上传loading
            }
            ,done: function(res){
                layer.closeAll('loading'); //关闭loading
                layer.msg('请求完毕')
                //上传完毕回调
                if(res.code == 1){
                    $('#test1').parents('.layui-input-block').find('.banner-show').find('img').attr('src',res.photo)
                    $('#test1').parents('.layui-input-block').find('.banner_img').val(res.photo)
                    $('#test1').parents('.layui-input-block').find('.banner_img2').val(res.video_url)
                    $('#test1').parents('.layui-input-block').find('.banner_img3').val(res.thumb_img)
                }
            }
            ,error: function(){
                layer.closeAll('loading'); //关闭loading
                //请求异常回调
                layer.msg('上传失败')
            }
        });
    });

    layui.use('upload', function(){
        var upload = layui.upload;

        //执行实例
        upload.render({
            elem: '#test4' //绑定元素
            ,url: '/api/fileUpload' //上传接口
            ,size: 512*2*10//10m
            ,data:{fileType:-1,fileExt:'video'}
            ,accept:"file"
            // ,acceptMime:"image/*"
            ,exts:"mp4|mov"
            ,before: function(obj){ //obj参数包含的信息，跟 choose回调完全一致，可参见上文。
                layer.load(); //上传loading
            }
            ,done: function(res){
                layer.closeAll('loading'); //关闭loading
                layer.msg('请求完毕')
                //上传完毕回调
                if(res.code == 1){
                    $('#test4').parents('.layui-input-block').find('.banner-show').find('source').attr('src',res.photo)
                    $('#test4').parents('.layui-input-block').find('.banner-show').find('video').css('display','')
                    $('#test4').parents('.layui-input-block').find('.banner_img').val(res.photo)
                }
            }
            ,error: function(){
                layer.closeAll('loading'); //关闭loading
                //请求异常回调
                layer.msg('上传失败')
            }
        });
    });
</script>

</html>
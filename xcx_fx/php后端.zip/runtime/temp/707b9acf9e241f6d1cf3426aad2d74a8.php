<?php /*a:2:{s:76:"/www/wwwroot/img.qutubao.com/php/application/backend/view/wallpaper/add.html";i:1647571631;s:81:"/www/wwwroot/img.qutubao.com/php/application/backend/view/base/common_header.html";i:1647852764;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">

<head>
    <meta charset="UTF-8">
<title>壁纸小程序后台管理</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" href="/static/css/font.css">
<link rel="stylesheet" href="/static/css/xadmin.css">
<!-- <link rel="stylesheet" href="./css/theme5.css"> -->
<script src="/static/lib/layui/layui.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/xadmin.js"></script>
<!--<script type="text/javascript" src="/static/js/jquery.min.js"></script>-->
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="/static/js/html5.min.js"></script>
<script src="/static/js/respond.min.js"></script>
<![endif]-->
<script>
    // 是否开启刷新记忆tab功能
    var is_remember = false;
</script>
    <style>
        .layui-table td, .layui-table th { min-width: auto; }
    </style>
    <style type="text/css">
        .view-img-thumb
        {display: inline-block;
            width: 100px; height: 100px;
            position: relative;
            margin: 0 20px 20px 0;}
        .view-img-thumb img {width: 100%; height: 100%;}
        .view-img-thumb em {display: block; width: 20px; height: 20px;
            background-color: rgba(0,0,0,.8); color: #fff; font-size: 12px;
            border-radius: 50%;position: absolute;top: -10px;
            right: -10px;text-align: center; line-height: 20px;
            cursor: pointer;}

        .attr-note{
            margin-top: 5px;
            color: red;
            display: block;
        }

        #upload_img_list {
            margin: 10px 0 0 0
        }
        #upload_img_list dd {
            position: relative;
            margin: 0 10px 10px 0;
            float: left;
        }
        #upload_img_list .operate {
            position: absolute;
            top: 0;
            right: 0;
            z-index: 1
        }
        #upload_img_list .operate i {
            cursor: pointer;
            background: #2F4056;
            padding: 2px;
            line-height: 15px;
            text-align: center;
            color: #fff;
            margin-left: 1px;
            float: left;
            filter: alpha(opacity=80);
            -moz-opacity: .8;
            -khtml-opacity: .8;
            opacity: .8
        }
        #upload_img_list dd .img {
            height: 100px;
            width: 100px
        }
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <form class="layui-form topic-form layui-col-space10">
                    <div class="layui-form-item">
                        <label class="layui-form-label">
                            <span class="x-red">*</span>素材类型</label>
                        <div class="layui-input-block">
                            <input lay-filter="result_type" type="radio"  name="type" value="1" title="手机壁纸" checked>
                            <input lay-filter="result_type" type="radio"  name="type" value="2" title="动态壁纸" >
                            <input lay-filter="result_type" type="radio"  name="type" value="3" title="背景图" >
                            <input lay-filter="result_type" type="radio"  name="type" value="4" title="头像" >
                            <input lay-filter="result_type" type="radio"  name="type" value="5" title="表情包" >
                            <p style="color: red">注意：动态壁纸只能上传mp4文件，每次新增只能处理一种类型，切勿上传错误素材，出问题请删除</p>
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label for="username" class="layui-form-label">
                            素材名称</label>
                        <div class="layui-input-inline">
                            <input type="text" id="self_name" name="self_name"  autocomplete="off" class="layui-input">
                        </div>
                    </div>
                    <div class="layui-form-item layui-form-text">
                        <label for="desc" class="layui-form-label">
                            <span class="x-red">*</span>素材</label>
                        <div class="layui-input-block">
                            <button type="button" class="layui-btn" id="test2">
                                <i class="layui-icon">&#xe67c;</i>上传素材
                            </button>
                            <button type="button" class="layui-btn layui-btn-danger del-photo" id="test3" style="margin-left: 5px">
                                <i class="layui-icon">&#xe67c;</i>删除全部素材
                            </button>
                            <div class="banner-show" id="upload_img_list" style="margin-top: 20px">
                            </div>
                            <span class="uploading-img" style="display: block;clear: both;">正在上传的图片，总数：<span class="total-ing">0</span>，成功：<span class="success-ing">0</span>，失败：<span class="error-ing">0</span></span>
                        </div>
                    </div>


                    <div class="layui-form-item">
                        <label class="layui-form-label">
                            <span class="x-red">*</span>是否显示</label>
                        <div class="layui-input-block">
                            <input type="radio"  name="show_index" value="0" title="否" >
                            <input type="radio"  name="show_index" value="1" title="是" checked>
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">
                            <span class="x-red">*</span>是否推荐</label>
                        <div class="layui-input-block">
                            <input type="radio"  name="is_recommend" value="0" title="否" checked>
                            <input type="radio"  name="is_recommend" value="1" title="是" >
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label for="username" class="layui-form-label">
                            权重</label>
                        <div class="layui-input-inline">
                            <input type="number" value="0" id="weight" name="weight"  autocomplete="off" class="layui-input">
                            <p style="color: red">请输入0-100000 之间的数值，设置越大排序越靠前</p>
                        </div>
                    </div>

                    <div class="expression-video-div" style="display: none">
                        <div class="layui-form-item layui-form-text">
                            <label for="desc" class="layui-form-label">
                                表情包原视频</label>
                            <div class="layui-input-block">
                                <button type="button" class="layui-btn" id="test4">
                                    <i class="layui-icon">&#xe67c;</i>上传视频
                                </button>
                                <button type="button" class="layui-btn layui-btn-danger del_video">
                                    删除视频
                                </button>
                                <div class="banner-show" style="width: 200px;margin-top: 5px">
                                    <video controls autoplay="autoplay" style="width: auto;max-width: 100%;max-height: 100%;display: none">
                                        <source src="">
                                    </video>
                                </div>
                                <input type="hidden" name="expression_video_url" class="banner_img">
                                <p style="color: red">若是要上传原视频，只能是单个表情包上传，否则视频会关联多个表情包素材，只能上传mp4文件</p>
                            </div>
                        </div>
<!--                        <div class="layui-form-item">-->
<!--                            <label class="layui-form-label">-->
<!--                                是否显示原视频</label>-->
<!--                            <div class="layui-input-block">-->
<!--                                <input type="radio"  name="expression_show_video" value="0" title="否" checked>-->
<!--                                <input type="radio"  name="expression_show_video" value="1" title="是" >-->
<!--                            </div>-->
<!--                        </div>-->
                    </div>

                    <div class="layui-form-item">
                        <label for="L_repass" class="layui-form-label"></label>
                        <button class="layui-btn" lay-filter="add" lay-submit="">新增素材</button></div>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
<script>
    var _type = 1,_accept='images';
    let _totaling , _successing , _erroring
    layui.use(['form', 'layer'],
        function() {

            var form = layui.form,
                layer = layui.layer,$ = layui.jquery;
            //监听提交
            form.on('submit(add)',
                function(data) {
                    var index = layer.load(1); //添加laoding,0-2两种方式
                    $.post("/admin/wallpaper/deal",$('.topic-form').serialize(),function (res) {
                        layer.close(index)
                        if(res.error_code != 0){
                            layer.msg(res.msg,{icon:5});
                        }else{
                            //发异步，把数据提交给php
                            layer.msg("新增成功", {
                                    icon: 6
                                },
                                function() {
                                    window.parent.location.reload();
                                    // 获得frame索引
                                    var index = parent.layer.getFrameIndex(window.name);
                                    //关闭当前frame
                                    parent.layer.close(index);
                                });
                        }
                    },'json')
                    return false;
                });

            $('.del-photo').click(function () {
                // $('#upload_img_list').html('')
                let _sucai = $(document).find('.close')
                $(_sucai).each(function (k,v){
                    deleteImg(this)
                })
            })

            form.on("radio(result_type)", function (data) {
                _type = data.value
                 _accept = _type == 2?'video':'images'
                if(_type == 5){
                    $('.expression-video-div').css('display','')
                }else{
                    $('.expression-video-div').css('display','none')
                }
            })

            $('.del_video').click(function (){
                $(this).parents('.layui-form-item').find('input[name="video_url"]').val('')
                $(this).parents('.layui-form-item').find('source').attr('src','')
                $(this).parents('.layui-form-item').find('video').css('display','none')
            })

        })

    //删除素材
    function deleteImg(data) {
        let _img = $(data).data('img'),
            _video = $(data).data('video'),
            _thumb = $(data).data('thumb'),
            _type = $(data).data('type');
        $(data).parents('.item_img').remove()

        $.post('/admin/wallpaper/delFile',{img:_img,video:_video,thumb:_thumb,type:_type},function (r){
            console.log(r);},'json')
    }

    function getJsonLength(jsonData){
        var jsonLength = 0;
        for(var item in jsonData){
            jsonLength++;
        }
        return jsonLength;
    }

    layui.use('upload', function(){
        var upload = layui.upload;
        //执行实例
        upload.render({
            elem: '#test2' //绑定元素
            ,url: '/api/fileUpload' //上传接口
            ,size:512*2*10//5m
            ,multiple: true
            ,data:{fileType:_type,fileExt:_accept}
            ,accept:"file"
            // ,acceptMime:"image/*"
            ,exts:"jpg|jpeg|gif|png|mp4|mov"
            ,before: function(obj){ //obj参数包含的信息，跟 choose回调完全一致，可参见上文。
                layer.load(); //上传loading
                this.data={fileType:_type,fileExt:_accept};
                //将每次选择的文件追加到文件队列
                var files = this.files = obj.pushFile();

                var len = getJsonLength(files);
                _totaling = len
                _successing = 0;_erroring = 0;
                $('.total-ing').text(_totaling)
                $('.success-ing').text(_successing)
                $('.error-ing').text(_erroring)
            }
            ,done: function(res ,index, upload){
                //删除数组文件中上传成功的素材，防止重复上传
                delete this.files[index]
                var html = '<dd class="item_img">\n' +
                    '                            <div class="operate">\n' +
                    '                                <i onclick="deleteImg(this)" class="close layui-icon" data-type="'+_type+'" data-img="'+res.photo+'" data-video="'+res.video_url+'" data-thumb="'+res.thumb_img+'"></i>\n' +
                    '                            </div>\n' +
                    '                            <img src="'+res.photo+'" class="img" >\n' +
                    '                            <input type="hidden" name="main_pictures[]" value="'+res.photo+'" />\n' +
                    '                            <input type="hidden" name="video_url[]" value="'+res.video_url+'" />\n' +
                    '                            <input type="hidden" name="thumb_img[]" value="'+res.thumb_img+'" />\n' +
                    '                        </dd>'

                if(res.code == 1){
                    $('#test2').parents('.layui-input-block').find('.banner-show').append(html)
                    _successing++
                    $('.success-ing').text(_successing)
                }
                else{
                    layer.msg('上传失败了')
                    _erroring++
                    $('.error-ing').text(_erroring)
                }
                layer.closeAll('loading'); //关闭loading
            }
            ,error: function(index, upload){
                layer.msg('上传失败')
                layer.closeAll('loading'); //关闭loading
                _erroring++
                $('.error-ing').text(_erroring)
            }
        });
    });

    layui.use('upload', function(){
        var upload = layui.upload;

        //执行实例
        upload.render({
            elem: '#test4' //绑定元素
            ,url: '/api/fileUpload' //上传接口
            ,size: 512*2*10//10m
            ,data:{fileType:-1,fileExt:'video'}
            ,accept:"file"
            // ,acceptMime:"image/*"
            ,exts:"mp4|mov"
            ,before: function(obj){ //obj参数包含的信息，跟 choose回调完全一致，可参见上文。
                layer.load(); //上传loading
            }
            ,done: function(res){
                layer.closeAll('loading'); //关闭loading
                layer.msg('请求完毕')
                //上传完毕回调
                if(res.code == 1){
                    $('#test4').parents('.layui-input-block').find('.banner-show').find('video').attr('src',res.photo)
                    $('#test4').parents('.layui-input-block').find('.banner-show').find('video').css('display','')
                    $('#test4').parents('.layui-input-block').find('.banner_img').val(res.photo)
                }
            }
            ,error: function(){
                layer.closeAll('loading'); //关闭loading
                //请求异常回调
                layer.msg('上传失败')
            }
        });
    });
</script>

</html>
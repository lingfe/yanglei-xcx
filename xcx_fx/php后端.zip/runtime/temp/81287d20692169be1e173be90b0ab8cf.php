<?php /*a:2:{s:74:"/www/wwwroot/img.qutubao.com/php/application/backend/view/admin/index.html";i:1646556084;s:81:"/www/wwwroot/img.qutubao.com/php/application/backend/view/base/common_header.html";i:1647852764;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">

<head>
    <meta charset="UTF-8">
<title>壁纸小程序后台管理</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" href="/static/css/font.css">
<link rel="stylesheet" href="/static/css/xadmin.css">
<!-- <link rel="stylesheet" href="./css/theme5.css"> -->
<script src="/static/lib/layui/layui.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/xadmin.js"></script>
<!--<script type="text/javascript" src="/static/js/jquery.min.js"></script>-->
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="/static/js/html5.min.js"></script>
<script src="/static/js/respond.min.js"></script>
<![endif]-->
<script>
    // 是否开启刷新记忆tab功能
    var is_remember = false;
</script>
    <style>
        .layui-table td, .layui-table th { min-width: auto; }
    </style>
</head>

<body>
<div class="x-nav">
            <span class="layui-breadcrumb">
                <a href="/admin">首页</a>
                <a href="/admin/admin/list">管理员列表</a>
            </span>
    <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" onclick="location.reload()" title="刷新">
        <i class="layui-icon layui-icon-refresh" style="line-height:30px"></i>
    </a>
</div>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-body ">
                    <form class="layui-form layui-col-space5">
                        <div class="layui-input-inline layui-show-xs-block">
                            <button type="button" class="layui-btn" onclick="xadmin.open('添加','/admin/admin/add','','',true)">
                                <i class="layui-icon"></i>添加</button>
                        </div>
                    </form>
                </div>
                <div class="layui-card-body ">
                    <table class="layui-table layui-form">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>管理员名称</th>
                            <th>角色</th>
                            <th>操作</th></tr>
                        </thead>
                        <tbody>
                        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$type): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <td><?php echo htmlentities($type['id']); ?></td>
                            <td><?php echo htmlentities($type['username']); ?></td>
                            <td>
                                <?php if(!empty($type['roles'])): ?>
                                <?php echo htmlentities($type['roles']['role_name']); else: ?>超级管理员<?php endif; ?>
                            </td>

                            <td class="td-manage">
                                <a title="编辑" class="layui-btn layui-btn-xs layui-btn-success" onclick="xadmin.open('编辑','/admin/admin/<?php echo htmlentities($type['id']); ?>/edit','','',true)" href="javascript:;">
                                    编辑</a>
                                <?php if($type['is_super'] != 1): ?>
                                <a title="删除" class="layui-btn layui-btn-xs layui-btn-danger" onclick="news_del(this,'<?php echo htmlentities($type['id']); ?>')" href="javascript:;">
                                    删除</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="layui-card-body ">
                    <?php echo $page; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<script>
    function news_del(obj, id) {
        layer.confirm('确认要删除吗？',
            function(index) {
                //发异步删除数据
                var index = layer.load(1); //添加laoding,0-2两种方式
                $.post('/admin/admin/'+id+'/delete',{},function (data) {
                    layer.close(index)
                    if(data.error_code == 0){
                        layer.msg('操作成功!', {
                            icon: 1,
                            time: 1000
                        },function () {
                            window.location.reload()
                        });
                    }else{
                        layer.msg('操作失败!', {
                            icon: 1,
                            time: 1000
                        });
                    }
                },"json")

            });
    }


</script>

</html>
<?php /*a:2:{s:71:"/www/wwwroot/img.qutubao.com/php/application/backend/view/cate/add.html";i:1646556156;s:81:"/www/wwwroot/img.qutubao.com/php/application/backend/view/base/common_header.html";i:1647852764;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">

<head>
    <meta charset="UTF-8">
<title>壁纸小程序后台管理</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" href="/static/css/font.css">
<link rel="stylesheet" href="/static/css/xadmin.css">
<!-- <link rel="stylesheet" href="./css/theme5.css"> -->
<script src="/static/lib/layui/layui.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/xadmin.js"></script>
<!--<script type="text/javascript" src="/static/js/jquery.min.js"></script>-->
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="/static/js/html5.min.js"></script>
<script src="/static/js/respond.min.js"></script>
<![endif]-->
<script>
    // 是否开启刷新记忆tab功能
    var is_remember = false;
</script>
    <style>
        .layui-table td, .layui-table th { min-width: auto; }
    </style>
    <script type="text/javascript" charset="utf-8" src="/static/ueditor/ueditor.config.js?v=1"></script>
    <script type="text/javascript" charset="utf-8" src="/static/ueditor/ueditor.all.js?v=1"> </script>
    <!--建议手动加在语言，避免在ie下有时因为加载语言失败导致编辑器加载失败-->
    <!--这里加载的语言文件会覆盖你在配置项目里添加的语言类型，比如你在配置项目里配置的是英文，这里加载的中文，那最后就是中文-->
    <script type="text/javascript" charset="utf-8" src="/static/ueditor/lang/zh-cn/zh-cn.js"></script>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <form class="layui-form topic-form layui-col-space10">
                    <div class="layui-form-item">
                        <label class="layui-form-label">
                            平台</label>
                        <div class="layui-input-block">
                            <input type="radio"  name="platform" value="1" title="全网" checked>
                            <input type="radio"  name="platform" value="2" title="抖音" >
                            <input type="radio"  name="platform" value="3" title="快手" >
                            <input type="radio"  name="platform" value="4" title="微信" >
                            <input type="radio"  name="platform" value="5" title="QQ" >
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label for="username" class="layui-form-label">
                            <span class="x-red">*</span>banner名称</label>
                        <div class="layui-input-inline">
                            <input type="text" id="name" name="name" required="" lay-verify="required" autocomplete="off" class="layui-input">
                        </div>
                    </div>

                    <div class="layui-form-item">
                        <label for="username" class="layui-form-label">
                            <span class="x-red">*</span>权重</label>
                        <div class="layui-input-inline">
                            <input type="text" id="weight" name="weight" value="0" required="" lay-verify="required" autocomplete="off" class="layui-input">
                            <p style="color: red">输入数字，越小排越前</p>
                        </div>
                    </div>

                    <div class="layui-form-item layui-form-text">
                        <label for="desc" class="layui-form-label">
                            <span class="x-red">*</span>导航图片</label>
                        <div class="layui-input-block">
                            <button type="button" class="layui-btn" id="test2">
                                <i class="layui-icon">&#xe67c;</i>上传图片
                            </button>
                            <p style="color: red">导航banner图片尺寸为：447x171像素</p>
                            <div class="banner-show" style="width: 200px;margin-top: 5px"><img src="" style="width: auto;max-width: 100%;max-height: 100%"></div>
                            <input type="hidden" name="banner_img" class="banner_img">
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">
                            导航是否显示</label>
                        <div class="layui-input-block">
                            <input type="radio"  name="banner_index" value="0" title="否" checked>
                            <input type="radio"  name="banner_index" value="1" title="是" >
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">
                            内容类型</label>
                        <div class="layui-input-block">
                            <input type="radio" lay-filter="ttShare" name="redirect_type" value="1" title="跳小程序页面" checked>
                            <input type="radio" lay-filter="ttShare" name="redirect_type" value="2" title="跳外链" >
                            <input type="radio" lay-filter="ttShare" name="redirect_type" value="3" title="富文本内容" >
                            <input type="radio" lay-filter="ttShare" name="redirect_type" value="4" title="跳转抖音号">
                            <p style="color: red">注意：跳转抖音号需要先在小程序设置中绑定抖音号</p>
                            <p style="color: red">近 7 日日均 DAU >= 1w（仅抖音 APP）的小程序可以通过平台设置页完成关注抖音号绑定</p>
                        </div>
                    </div>
                    <div class="layui-form-item redirect_type_show redirect_type1">
                        <label for="username" class="layui-form-label">
                            小程序页面</label>
                        <div class="layui-input-inline">
                            <input type="text" id="mini_url" name="mini_url"  autocomplete="off" class="layui-input">
                            <p style="color: red">填写小程序页面路径及参数，如/pages/index/index?id=11</p>
                        </div>
                    </div>
                    <div class="layui-form-item redirect_type_show redirect_type2" style="display: none">
                        <label for="username" class="layui-form-label">
                            外链url</label>
                        <div class="layui-input-inline">
                            <input type="text" id="webview_url" name="webview_url"  autocomplete="off" class="layui-input">
                            <p style="color: red">填写完整的url链接，且要配置在小程序的业务域名内</p>
                        </div>
                    </div>
                    <div class="layui-form-item layui-form-text redirect_type_show redirect_type3" style="display: none">
                        <label for="desc" class="layui-form-label">
                            富文本内容</label>
                        <div class="layui-input-block">
                            <script id="editor-it" type="text/plain" style="width:800px;height:450px;"></script>
                            <textarea id="content-show" name="editor_content" style="display: none"></textarea>
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label for="L_repass" class="layui-form-label"></label>
                        <button class="layui-btn" lay-filter="add" lay-submit="">新增banner</button></div>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
<script>
    var editorIt = UE.getEditor('editor-it',{
        //focus时自动清空初始化时的内容
        autoClearinitialContent:false,
        //关闭字数统计
        elementPathEnabled:false,
        wordCount:true,
        enableAutoSave:false,
        catchRemoteImageEnable:false,
        //默认的编辑区域高度
        initialFrameHeight:700,
        imagePopup:true,
        allowDivTransToP: false,
        autoHeightEnabled:false
        //更多其他参数，请参考ueditor.config.js中的配置项
    });
    UE.Editor.prototype._bkGetActionUrl = UE.Editor.prototype.getActionUrl;
    UE.Editor.prototype.getActionUrl = function(action) {
        if (action == 'uploadimage') {
            return "/api/editorUpload"; // 使用自己的上传图片接口
        } else {
            return this._bkGetActionUrl.call(this, action);
        }
    }

    layui.use(['form', 'layer'],
        function() {
            $ = layui.jquery;
            var form = layui.form,
                layer = layui.layer;
            //监听提交
            form.on('submit(add)',
                function(data) {
                    var index = layer.load(1); //添加laoding,0-2两种方式
                    $('#content-show').html(editorIt.getContent());
                    $.post("/admin/cate/deal",$('.topic-form').serialize(),function (res) {
                        layer.close(index)
                        if(res.error_code != 0){
                            layer.msg(res.msg,{icon:5});
                        }else{
                            //发异步，把数据提交给php
                            layer.msg("新增成功", {
                                    icon: 6
                                },
                                function() {
                                    window.parent.location.reload();
                                    // 获得frame索引
                                    var index = parent.layer.getFrameIndex(window.name);
                                    //关闭当前frame
                                    parent.layer.close(index);
                                });
                        }
                    },'json')
                    return false;
                });

            form.on("radio(ttShare)", function (data) {

                $('.redirect_type_show').css('display','none')
                $('.redirect_type'+data.value).css('display','')
            })
        })

    /**
     * 红包封面banner上传
     * */
    layui.use('upload', function(){
        var upload = layui.upload;

        //执行实例
        upload.render({
            elem: '#test1' //绑定元素
            ,url: '/api/fileUpload' //上传接口
            ,size: 512*2//5m
            ,data:{useOrigin:1}
            ,done: function(res){
                //上传完毕回调
                if(res.code == 1){
                    $('#test1').parents('.layui-input-block').find('.banner-show').find('img').attr('src',res.photo)
                    $('#test1').parents('.layui-input-block').find('.banner_img').val(res.photo)
                }
            }
            ,error: function(){
                //请求异常回调
                layer.msg('上传失败')
            }
        });
    });
    layui.use('upload', function(){
        var upload = layui.upload;

        //执行实例
        upload.render({
            elem: '#test2' //绑定元素
            ,url: '/api/fileUpload' //上传接口
            ,size: 512*2*5//5m
            ,data:{useOrigin:1}
            ,done: function(res){
                //上传完毕回调
                if(res.code == 1){
                    $('#test2').parents('.layui-input-block').find('.banner-show').find('img').attr('src',res.photo)
                    $('#test2').parents('.layui-input-block').find('.banner_img').val(res.photo)
                }
            }
            ,error: function(){
                //请求异常回调
                layer.msg('上传失败')
            }
        });
    });
</script>

</html>
<?php /*a:2:{s:76:"/www/wwwroot/cs.dyhot.cn/php-retail/application/backend/view/cate/index.html";i:1641470006;s:84:"/www/wwwroot/cs.dyhot.cn/php-retail/application/backend/view/base/common_header.html";i:1635745947;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">

<head>
    <meta charset="UTF-8">
<title>壁纸小程序后台管理</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" href="/static/css/font.css">
<link rel="stylesheet" href="/static/css/xadmin.css">
<!-- <link rel="stylesheet" href="./css/theme5.css"> -->
<script src="/static/lib/layui/layui.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/js/xadmin.js"></script>
<!--<script type="text/javascript" src="/static/js/jquery.min.js"></script>-->
<!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
<!--[if lt IE 9]>
<script src="/static/js/html5.min.js"></script>
<script src="/static/js/respond.min.js"></script>
<![endif]-->
<script>
    // 是否开启刷新记忆tab功能
    // var is_remember = false;
</script>
    <style>
        .layui-table td, .layui-table th { min-width: auto; }
    </style>
</head>

<body>
<div class="x-nav">
            <span class="layui-breadcrumb">
                <a href="/admin">首页</a>
                <a href="/admin/cate">banner管理</a>
            </span>
    <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" onclick="location.reload()" title="刷新">
        <i class="layui-icon layui-icon-refresh" style="line-height:30px"></i>
    </a>
</div>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-body ">
                    <form class="layui-form layui-col-space5">
                        <div class="layui-input-inline layui-show-xs-block">
                            <button type="button" class="layui-btn" onclick="xadmin.open('添加banner','/admin/cate/add','','',true)">
                                <i class="layui-icon"></i>添加banner</button>
                        </div>
                    </form>
                </div>
                <div class="layui-card-body ">
                    <table class="layui-table layui-form">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>平台</th>
                            <th>banner名称</th>
                            <th>bannerICON</th>
                            <th>内容类型</th>
                            <th>权重</th>
                            <th>是否显示</th>
                            <th>操作</th></tr>
                        </thead>
                        <tbody>
                        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$topic): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <td><?php echo htmlentities($topic['id']); ?></td>
                            <td>
                                <?php if($topic['platform'] == 5): ?>QQ<?php endif; if($topic['platform'] == 4): ?>微信<?php endif; if($topic['platform'] == 3): ?>快手<?php endif; if($topic['platform'] == 2): ?>抖音<?php endif; if($topic['platform'] == 1): ?>全网<?php endif; ?>
                            </td>
                            <td><?php echo htmlentities($topic['name']); ?></td>
                            <td><?php if($topic['banner_img']): ?><a href="<?php echo htmlentities($topic['banner_img']); ?>" target="_blank" title="点击查看原图"><img src="<?php echo htmlentities($topic['banner_img']); ?>" width="60px" height="60px"></a><?php endif; ?></td>
                            <td>
                                <?php if($topic['redirect_type'] == 1): ?>小程序页面跳转<?php endif; if($topic['redirect_type'] == 2): ?>外链跳转<?php endif; if($topic['redirect_type'] == 3): ?>富文本内容<?php endif; ?>
                            </td>
                            <td><?php echo htmlentities($topic['weight']); ?></td>
                            <td><?php if($topic['banner_index'] == 0): ?>否<?php else: ?>是<?php endif; ?></td>
                            <td class="td-manage">
                                <a title="编辑" class="layui-btn layui-btn-sm " onclick="xadmin.open('编辑','/admin/cate/edit/<?php echo htmlentities($topic['id']); ?>','','',true)" href="javascript:;">
                                    编辑</a>
                                <a title="删除" class="layui-btn layui-btn-sm layui-btn-danger" onclick="topic_del(this,'<?php echo htmlentities($topic['id']); ?>')" href="javascript:;">
                                    删除</a>
                            </td>
                        </tr>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<script>
function topic_del(obj, id) {
    layer.confirm('确认要删除吗？',
        function(index) {
            //发异步删除数据
            $.post('/admin/cate/del',{id:id},function (data) {
                console.log(data)
                if(data.error_code == 0){
                    layer.msg('操作成功!', {
                        icon: 1,
                        time: 1000
                    },function () {
                        window.location.reload()
                    });
                }else{
                    layer.msg('操作失败!', {
                        icon: 1,
                        time: 1000
                    });
                }
            },"json")

        });
}


</script>

</html>
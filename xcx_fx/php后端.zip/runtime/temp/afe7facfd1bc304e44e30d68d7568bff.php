<?php /*a:4:{s:79:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/new_index/index.html";i:1639126057;s:74:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/base/title.html";i:1638609045;s:74:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/base/h5_v2.html";i:1641441303;s:82:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/base/expert_review.html";i:1638155221;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,target-densitydpi=high-dpi,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <title><?php echo htmlentities($platform_name); ?></title>
<link rel="stylesheet" href="/static/h5/dist/css/index.min.css?v=1.2.10">
<?php if(empty($isMobile)): ?>
<style>
    body {
        max-width: 420px !important;
        margin: 0 auto !important;
    }
    @media screen and (min-width: 420px) {
        .material-btns,
        .footer-tab {
            max-width: 420px !important;
            left: auto !important;
            right: auto !important;
        }
        .float-home {
            left: 50% !important;
            margin-left: 150px !important;
            width: 50px;
        }
    }
</style>
<?php endif; ?>

<!--<script type="text/javascript" src="/static/h5/new_dist/scripts/form.min.js"></script>-->
<!--<script src="https://cdn.bootcss.com/vConsole/3.3.4/vconsole.min.js"></script>-->

<!--<script>-->



<!--    var vConsole =new VConsole();-->

<!--    console.log(1230);-->

<!--</script>-->
    <link rel="stylesheet" href="/static/h5/dist/scripts/libs/swiper-bundle.min.css">
    <link rel="stylesheet" href="/static/h5/dist/scripts/libs/need/layer.css">

    <link rel="stylesheet" href="/static/h5/dist/scripts/libs/weui/weui.min.css">
    <script src="/static/lib/layui/layui.js" charset="utf-8"></script>

    <link rel="stylesheet" href="/static/h5_v2/css/v2.css?v=1.1.38" type="text/css">
    <style>
        body{
            background: #F4F4F4;
        }
        .sucai{
            width: 100%;
        }
        .btn-img{
            padding: 1.5rem;
            display: flex;
            align-items: center;
        }
        .btn-img img{
            width: 90%;
            /*float: left;*/
            display: block;
            margin: 0 auto;
        }

        /**/
        .sucai-data{
            padding: 1.5rem;
        }
        .sucai-data .list {
            overflow: hidden;
        }
        .sucai-data .list li {
            float: left;
            width: 33.33%;
            height: 100px;
            border-right: 1px solid #ddd;
            box-sizing: border-box;
            background-color: #F4F4F4;
            margin-top: 0;
        }
        .sucai-data .list li:nth-child(n+4) {
            border-top: 1px solid #ddd;
        }
        .sucai-data .list li:nth-child(3n) {
            border-right: 0;
        }
        .list-li-title{
            padding: 1rem;
            display: block;
            font-size: 14px;
            font-family: Source Han Sans CN;
            font-weight: 400;
            color: #888888;
        }
        .list-li-value{
            display: block;
            padding: 1rem;
        }
    </style>
</head>
<body>
<section class="index">
    <div class="index-banner">
        <div class="index-bannerc">
            <?php if($index_config['index_poster']): ?><img src="<?php echo htmlentities($index_config['index_poster']); ?>" alt=""><?php endif; ?>
            <div class="index-banner-text">
                <img src="/static/h5/dist/images/label-platform.jpg" alt="">
                <div>
                    <p id="loop-text">
                        <span><a href="/news/details?id=<?php echo htmlentities($news['id']); ?>"><?php echo htmlentities($news['title']); ?></a></span>
                    </p>
                </div>
                <img class="index-banner-arrow" src="/static/h5/dist/images/icon-arrow-right.png" alt="">
            </div>
        </div>
    </div>
    <div class="index-category">
        <p>
            <a href="/newHand">
                <img src="/static/h5/dist/images/icon_index_c6.png" alt="">
                新手教程
            </a>
        </p>
        <p>
            <a href="/news/list">
                <img src="/static/h5/dist/images/icon_index_c2.png" alt="">
                平台公告
            </a>
        </p>
        <p>
            <a href="javascript:;" onclick="redirectRank(this)" data-show="<?php echo htmlentities($rankShow); ?>">
                <img src="/static/h5/dist/images/icon_index_c1.png" alt="">
                达人排行
            </a>
        </p>
        <p>
            <a href="/user/invite">
                <img src="/static/h5/dist/images/icon_index_c3.png" alt="">
                邀请好友
            </a>
        </p>
        <p>
            <a href="/user/team">
                <img src="/static/h5/dist/images/icon_index_c5.png" alt="">
                我的团队
            </a>
        </p>
    </div>

</section>
<section>
    <div class="sucai">
        <div class="btn-img">
            <a href="/wallpaper/list"><img src="/static/h5/sucai_btn.png"></a>
            <a href="/wallpaper/create"><img src="/static/h5/upload_btn.png"></a>
        </div>
        <div class="sucai-data">
            <ul class="list">
                <li>
                    <span class="list-li-title">手机壁纸</span>
                    <span class="list-li-value"><?php if($sucai_data['sucai1']): ?><?php echo htmlentities($sucai_data['sucai1']); else: ?>0<?php endif; ?>张</span>
                </li>
                <li>
                    <span class="list-li-title">动态壁纸</span>
                    <span class="list-li-value"><?php if($sucai_data['sucai2']): ?><?php echo htmlentities($sucai_data['sucai2']); else: ?>0<?php endif; ?>张</span>
                </li>
                <li>
                    <span class="list-li-title">背景图</span>
                    <span class="list-li-value"><?php if($sucai_data['sucai3']): ?><?php echo htmlentities($sucai_data['sucai3']); else: ?>0<?php endif; ?>张</span>
                </li>
                <li>
                    <span class="list-li-title">头像</span>
                    <span class="list-li-value"><?php if($sucai_data['sucai4']): ?><?php echo htmlentities($sucai_data['sucai4']); else: ?>0<?php endif; ?>张</span>
                </li>
                <li>
                    <span class="list-li-title">表情包</span>
                    <span class="list-li-value"><?php if($sucai_data['sucai5']): ?><?php echo htmlentities($sucai_data['sucai5']); else: ?>0<?php endif; ?>张</span>
                </li>
                <li></li>
            </ul>
        </div>
    </div>
</section>

<p class="footer-padding"></p>
<footer class="footer-tab">
    <a href="/" class="footer-home active">
        <i></i>
        首页
    </a>
    <a href="/profit" class="footer-profit">
        <i></i>
        数据
    </a>
    <a href="/user" class="footer-user">
        <i></i>
        我的
    </a>
</footer>





<script type="text/javascript" src="/static/h5/dist/scripts/libs/zepto.min.js"></script>
<script type="text/javascript" src="/static/h5/dist/scripts/libs/swiper-bundle.min.js"></script>
<script type="text/javascript">
    layui.use('layer', function() {
        var form = layui.form,
            layer = layui.layer


    })

    function redirectRank(r){
        let _d = parseInt($(r).data('show'))
            if(_d == 1){window.location.href='/agent/rank'}
            else{layer.msg('功能正在开发中')}
    }
</script>


<div class="ewm platform-notify " id="platform-notify">
  <div class="ewm-container">
    <h5>平台公告<br/>【达人入驻<?php echo htmlentities($platform_name); ?>注意事项】</h5>
    <p>1、通过手机号码注册或登录进入平台，需完善自己的账号信息</p>
    <p>2、达人可以通过电脑、手机浏览器上传素材</p>
    <p>3、每日可以在数据页面中查看自己当日的推广明细以及佣金收益</p>
    <p>4、每日需等待平台工作人员结算昨日佣金</p>
    <p>5、若有疑问，请到我的页面中联系客服</p>
    <div class="platform-btns">
      <button>我已阅读并知悉，去完善信息</button>
    </div>
  </div>
</div>

<script type="text/javascript">
  $('.platform-btns').click(function (){
    window.location.href = '/user/improve/init'
  })
  <?php if(empty($expertInfoBase['wechat_num'])): ?>
    $('#platform-notify').addClass('active')
  <?php endif; ?>
</script>


</body>
</html>

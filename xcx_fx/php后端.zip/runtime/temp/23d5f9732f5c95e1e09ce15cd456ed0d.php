<?php /*a:4:{s:75:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/index/index.html";i:1642560188;s:74:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/base/title.html";i:1638609045;s:74:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/base/h5_v2.html";i:1641441303;s:82:"/www/wwwroot/cs.dyhot.cn/php-retail/application/index/view/base/expert_review.html";i:1638155221;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,target-densitydpi=high-dpi,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo htmlentities($platform_name); ?></title>
<link rel="stylesheet" href="/static/h5/dist/css/index.min.css?v=1.2.10">
<?php if(empty($isMobile)): ?>
<style>
    body {
        max-width: 420px !important;
        margin: 0 auto !important;
    }
    @media screen and (min-width: 420px) {
        .material-btns,
        .footer-tab {
            max-width: 420px !important;
            left: auto !important;
            right: auto !important;
        }
        .float-home {
            left: 50% !important;
            margin-left: 150px !important;
            width: 50px;
        }
    }
</style>
<?php endif; ?>

<!--<script type="text/javascript" src="/static/h5/new_dist/scripts/form.min.js"></script>-->
<!--<script src="https://cdn.bootcss.com/vConsole/3.3.4/vconsole.min.js"></script>-->

<!--<script>-->



<!--    var vConsole =new VConsole();-->

<!--    console.log(1230);-->

<!--</script>-->
    <link rel="stylesheet" href="/static/h5/dist/scripts/libs/swiper-bundle.min.css">
    <link rel="stylesheet" href="/static/h5/dist/scripts/libs/need/layer.css">

    <link rel="stylesheet" href="/static/h5/dist/scripts/libs/weui/weui.min.css">
    <link rel="stylesheet" href="/static/h5_v2/css/v2.css?v=1.1.38" type="text/css">
    <script src="/static/lib/layui/layui.js" charset="utf-8"></script>
    <link id="layuicss-layer" rel="stylesheet" href="/static/lib/layui/css/modules/layer/default/layer.css?v=3.1.1" media="all"></head>
<body>
<?php if(!empty($config_list['open_wechat']) && empty($user_info['openid'])): ?>
<a href="/doWechat/aouth?uid=<?php echo htmlentities($user_info['user_id']); ?>" class="attention-tips">
    <img src="/static/h5_v2/images/star.png" />
    点击微信公众号授权
    <img src="/static/h5_v2/images/star.png" />
</a>
<?php endif; ?>
<section class="user">
    <div class="user-info-v2">
        <img class="user-headicon-v2" src="<?php echo htmlentities($user_info['user_headimg']); ?>"/>
        <div class="user-info-v2-text">
            <p>达人口令（邀请码）：<?php echo htmlentities($user_info['user_code']); ?></p>
            <div class="user-iv2t">
                <a class="user-iv2t-btn" href="/user/improve/init">
                    <img class="user-iv2t-bicon" src="/static/h5_v2/images/icon-people-v2.png" />
                    账户信息
                    <img class="user-iv2t-sicon" src="/static/h5_v2/images/icon-share-v2.png" />
                </a>
                <span style="color: #fff">
                    <?php if($user_info['is_reviewed'] == 1 && $user_info['is_freeze'] == 0): ?>账号正常<?php endif; if($user_info['is_freeze'] == 1): ?>账号冻结<?php endif; if($user_info['is_reviewed'] == 0): ?>账号审核中<?php endif; if($user_info['is_reviewed'] == 2): ?>账号信息被拒绝<?php endif; ?>
                </span>
<!--                <a class="user-iv2t-btn" href="#">-->
<!--                    <img class="user-iv2t-bicon" src="/static/h5_v2/images/icon-money-v2.png" />-->
<!--                    首款-->
<!--                    <img class="user-iv2t-sicon" src="/static/h5_v2/images/icon-share-v2.png" />-->
<!--                </a>-->
            </div>
        </div>
<!--        <a class="user-douyin-v2" href="#">-->
<!--            <img src="/static/h5_v2/images/icon-douyin-v2.png" />-->
<!--            抖音变现-->
<!--        </a>-->
    </div>
    <div class="user-money-v2">
        <div class="user-money-v2t">
            <div class="user-money-v2tl">
                <p>可提现金额</p>
                <strong><?php if($user_info['withdraw_money']): ?><?php echo htmlentities($user_info['withdraw_money']); else: ?>0.000<?php endif; ?><span>(元)</span></strong>
            </div>
            <a class="user-money-v2tr apply-check" href="javascript:;"  data-wechat="<?php echo htmlentities($user_info['wechat_num']); ?>" data-status="<?php echo htmlentities($applyStatus['config_value']); ?>" data-href="/tx/apply">提现</a>
        </div>
        <ul class="user-money-v2b">
            <li>
                <strong><?php echo htmlentities($user_info['total_money']); ?></strong>
                <p>总收益(元)</p>
            </li>
            <li>
                <strong><?php if($dayPrice['predict_price']): ?><?php echo htmlentities($dayPrice['predict_price']); else: ?>0.000<?php endif; ?></strong>
                <p>今日预估收益(元)</p>
            </li>
            <li>
                <strong><?php if($yesterdayPrice['price_deal_staus'] != 1): if($yesterdayPrice['predict_price']): ?><?php echo htmlentities($yesterdayPrice['predict_price']); else: ?>0.000<?php endif; else: if($yesterdayPrice['true_price']): ?><?php echo htmlentities($yesterdayPrice['true_price']); else: ?>0.000<?php endif; ?>
                    <?php endif; ?>
                </strong>
                <p><?php if($yesterdayPrice['price_deal_staus'] != 1): ?>昨日预估收益<?php else: ?>昨日收益<?php endif; ?>(元)</p>
            </li>
        </ul>
    </div>
    <div class="user-level-v2">
        <div class="user-lv2l">
            我的上级：<?php if($user_info['fir_distribution'] != 0): ?><?php echo htmlentities(urldecode($user_info['parent_info']['user_nickname'])); else: ?><?php echo htmlentities($config_list['default_fir_name']); ?><?php endif; ?>
        </div>
        <a  class="user-lv2r user-btn-wxh" href="javascript:;" data-wechat="<?php if($user_info['fir_distribution'] != 0): ?><?php echo htmlentities($user_info['parent_info']['wechat_num']); else: ?><?php echo htmlentities($config_list['default_fir_wechat']); ?><?php endif; ?>">
            联系他
        </a>
    </div>
    <?php if($config_list['index_poster']): ?>
    <a class="user-poster-v2" href="#">
        <img src="<?php echo htmlentities($config_list['index_poster']); ?>" />
    </a>
    <?php endif; ?>

    <div class="user-grid-list">
        <a href="/user/team">
            <img src="/static/h5_v2/images/icon-user-i1.png" />
            <span>我的团队</span>
        </a>
        <a href="/newHand">
            <img src="/static/h5_v2/images/icon-user-i2.png" />
            <span>新手教程</span>
        </a>
        <?php if($wechat_img['config_value']): ?>
        <a href="javascript:;" id="ewm-active" data-url="<?php echo htmlentities($php_server); ?><?php echo htmlentities($wechat_img['config_value']); ?>">
            <img src="/static/h5_v2/images/icon-user-i3.png" />
            <span>咨询客服</span>
        </a>
        <?php endif; ?>

<!--        <a href="#">-->
<!--            <img src="/static/h5_v2/images/icon-user-i4.png" />-->
<!--            <span>商务合作</span>-->
<!--        </a>-->
        <a href="/tx/log">
            <img src="/static/h5_v2/images/icon-user-i5.png" />
            <span>提现记录</span>
        </a>
        <a href="javascript:;" onclick="redirectRank(this)" data-show="<?php echo htmlentities($config_list['ranking_show']); ?>">
            <img src="/static/h5_v2/images/icon-user-i6.png" />
            <span>达人排行</span>
        </a>
        <a href="/news/list">
            <img src="/static/h5_v2/images/icon-user-i7.png" />
            <span>公告</span>
        </a>
    </div>
    <a class="user-apply-btn" >退出登录</a>
</section>
<p class="footer-padding"></p>
<footer class="footer-tab">
    <a href="/" class="footer-home">
        <i></i>
        首页
    </a>
    <a href="/profit" class="footer-profit">
        <i></i>
        数据
    </a>
    <a href="/user" class="footer-user active">
        <i></i>
        我的
    </a>
</footer>


<?php if(!empty($wechat_img['config_value'])): ?>
<div class="ewm" id="ewm">
    <div class="ewm-container">
        <div class="ewm-ctop">
            <p>长按下方图片，识别二维码</p>
            <img class="ewm-img" alt="">
        </div>
        <div class="ewm-cbottom">
            <img class="ewm-close" id="ewm-close" src="/static/h5/dist/images/icon_close.png" alt="">
        </div>
    </div>
</div>
<?php endif; if(!empty($platform_code['config_value'])): ?>
<div class="ewm" id="user-poster">
    <div class="ewm-container">
        <div class="user-poster-img"><img src="<?php echo htmlentities($php_server); ?><?php echo htmlentities($wechat_img['config_value']); ?>" class="platform-img" alt=""></div>
        <div class="ewm-cbottom">
            <img class="ewm-close" id="user-poster-close" src="/static/h5/dist/images/icon_close.png" alt="">
        </div>
    </div>
</div>
<?php endif; ?>




<div class="ewm ewm-dy " id="code-dy">
    <div class="ewm-container">
        <h5>绑定抖音专用</h5>
        <div class="dy-decorate"></div>
        <div class="dy-ewm-code">
            <img  class="dy-ewm-img" alt="">
        </div>
        <p class="dy-ewm-text">
            <span>长按保存，打开抖音扫一扫</span><br/>
            此码不可在电脑发布视频
        </p>
    </div>
</div>


<!-- 安卓机子复制链接处理 -->
<input readOnly="true" style="outline: none;border: 0px; color: rgba(0,0,0,0.0);position: absolute;left:-200px; background-color: transparent" id="biao1" value=""/>

<script type="text/javascript" src="/static/h5/dist/scripts/libs/zepto.min.js"></script>
<script type="text/javascript" src="/static/h5/dist/scripts/libs/swiper-bundle.min.js"></script>
<script type="text/javascript" src="/static/h5/dist/scripts/index.min.js"></script>
<script type="text/javascript">
    layui.use('layer', function() {
        var form = layui.form,
            layer = layui.layer



    })

    function redirectRank(r) {
        let _d = parseInt($(r).data('show'))
        if (_d == 1) {
            window.location.href = '/agent/rank'
        } else {
            layer.msg('功能正在开发中')
        }
    }

    $('.user-apply-btn').click(function () {
        $.post('/logout',{},function (r){
            console.log(r);
            window.location.reload()},'json')
    })

    $('#ewm-close').on('click', function () {
        $('#ewm').removeClass('active');
    });
    $('#ewm-active').on('click', function () {
        $('.ewm-img').attr('src', $(this).data('url'))
        $('#ewm').addClass('active');
    });


    $('#platform-active').on('click', function () {
        $('.platform-img').attr('src', $(this).data('url'))
        $('#user-poster').addClass('active');
    });
    $('#user-poster-close').on('click', function () {
        $('#user-poster').removeClass('active');
    });

    $('.user-btn-wxh').click(function () {
        var _val = $(this).data('wechat')
        if (_val == '' || _val == undefined) {
            layer.msg('您的上级暂无微信号，请耐心等待'), {icon: 2}
        } else {
            newCopy(_val)
        }
    })

    function newCopy(txt) {
        $("#biao1").val(txt);//安卓
        console.log(txt)
        if (navigator.userAgent.match(/(iPhone|iPod|iPad);?/i)) {
            var el = document.createElement('input');
            el.value = txt;//要复制的内容
            el.style.opacity = '0';
            document.body.appendChild(el);
            var editable = el.contentEditable;
            var readOnly = el.readOnly;
            el.contentEditable = true;
            el.readOnly = false;
            const range = document.createRange();
            range.selectNodeContents(el);
            var sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
            el.setSelectionRange(0, 999999);
            el.contentEditable = editable;
            el.readOnly = readOnly;
            var ret = document.execCommand('copy');
            el.blur();
            if (ret) {
                layer.msg('复制成功，快去联系你的上级吧', {icon: 1})
            } else {
                layer.msg('复制失败', {icon: 2})
            }
        } else {
            var Url2 = document.getElementById("biao1");
            Url2.select(); // 选择对象
            $("#biao1").blur();
            if (document.execCommand('copy', false, null)) {
                var successful = document.execCommand('copy');
                layer.msg('复制成功，快去联系你的上级吧', {icon: 1})
            } else {
                layer.msg('复制失败', {icon: 2})
            }
            ;
        }
    }

    //////////////////////////
    $('.open-topic-ewm').on('click', function () {
        var _img = $('.dy-ewm-img').attr('src')
        if (_img == undefined || _img == '') {
            $.post('/project/create', {project_id: 10001}, function (r) {
                console.log(r);
                if (r.error_code == 0) {
                    $('.dy-ewm-img').attr('src', r.data.qrcode)
                    $('.ewm-dy').addClass('active')
                } else {
                    layer.msg(r.msg, {icon: 2})
                }
            }, 'json')
        } else {
            $('.ewm-dy').addClass('active')
        }
    })
    $('#platform-notify').on('click', function () {
        if ($(event.target).hasClass('platform-notify')) {
            $(this).removeClass('active');
        }
    });

    $('.platform-btns button').on('click', function () {
        $('#platform-notify').removeClass('active');
    });

    $('#code-dy').on('click', function () {
        if ($(event.target).hasClass('ewm-dy')) {
            $(this).removeClass('active');
        }
    });


    $('.apply-check').click(function () {
        var _w = $(this).data('wechat')
        var _status = parseInt($(this).data('status'))
        var _href = $(this).data('href')
        if (_w == '') {
            layer.msg('请先完善达人信息', {icon: 6});
            return false;
        } else {
            if (_status == 0) {
                layer.msg('暂未到时间开放提现，请耐心等待哦~~', {icon: 6});
            } else {
                window.location.href = _href
            }
        }

    })
</script>


<div class="ewm platform-notify " id="platform-notify">
  <div class="ewm-container">
    <h5>平台公告<br/>【达人入驻<?php echo htmlentities($platform_name); ?>注意事项】</h5>
    <p>1、通过手机号码注册或登录进入平台，需完善自己的账号信息</p>
    <p>2、达人可以通过电脑、手机浏览器上传素材</p>
    <p>3、每日可以在数据页面中查看自己当日的推广明细以及佣金收益</p>
    <p>4、每日需等待平台工作人员结算昨日佣金</p>
    <p>5、若有疑问，请到我的页面中联系客服</p>
    <div class="platform-btns">
      <button>我已阅读并知悉，去完善信息</button>
    </div>
  </div>
</div>

<script type="text/javascript">
  $('.platform-btns').click(function (){
    window.location.href = '/user/improve/init'
  })
  <?php if(empty($expertInfoBase['wechat_num'])): ?>
    $('#platform-notify').addClass('active')
  <?php endif; ?>
</script>


</body>
</html>

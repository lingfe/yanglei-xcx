<?php
//000002592000
 exit();?>
{"mini_domain":"https:\/\/meitu.ilanchong.cn","save_way":"1","aliyun_buckey":"qutubao","aliyun_keyid":"LTAI5tF2xP8HJysheDyaM","aliyun_keysecret":"rfQIAgeJdJ7TL8Vamyzt9yt","aliyun_endpoint":"oss-cn-nanjing.aliyuncs.com","aliyun_old_domain":"http:\/\/qutubao.oss-cn-nanjing.aliyuncs.com","aliyun_new_domain":"https:\/\/qutubao.oss-cn-nanjing.aliyuncs.com"}
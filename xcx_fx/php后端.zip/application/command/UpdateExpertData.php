<?php

namespace app\command;

use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;

/**
 * Class UpdateExpertData
 * @package app\command
 * 定时更新达人的点赞数 收藏数
 */
class UpdateExpertData extends Command
{
    protected function configure()
    {
        // 指令配置
        $this->setName('updateexpertdata');
        // 设置参数
        
    }

    protected function execute(Input $input, Output $output)
    {
    	// 指令输出
    	$output->writeln('app\command\updateexpertdata');
    	$sql = 'update qqxcx_expert a , (select author_id,count(author_id) as c_num from qqxcx_wallpaper_collection group by author_id) b set a.user_collection = b.c_num where a.user_id = b.author_id;';
    	Db::execute($sql);
    	$sql2 = 'update qqxcx_expert a , (select author_id,count(author_id) as c_num from qqxcx_wallpaper_zan group by author_id) b set a.user_zan = b.c_num where a.user_id = b.author_id;';
    	Db::execute($sql2);
    }
}

<?php

namespace app\command;

use app\common\model\Accesstoken;
use app\common\model\Config;
use app\common\services\WechatService;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Exception;

/**
 * Class UpdateAccesstoken
 * @package app\command
 * 每小时更新一次公众号token
 */
class UpdateAccesstoken extends Command
{
    protected function configure()
    {
        // 指令配置
        $this->setName('updateaccesstoken');
        // 设置参数
        
    }

    protected function execute(Input $input, Output $output)
    {
    	// 指令输出
    	$output->writeln('app\command\updateaccesstoken');

    	$wechat = new WechatService();
    	try{
            $config = Config::getAllConfig();
            //有开启微信授权才需要更新token
            if($config['open_wechat'] == 1){
                $token = $wechat->getNowAccesstoken();
                //更新到token表里
                Accesstoken::update(['token'=>$token],['id'=>1]);
            }

        }catch (Exception $e){

        }
    }
}

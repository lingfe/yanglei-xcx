<?php

namespace app\command;

use app\common\model\Accesstoken;
use app\common\services\WechatService;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\facade\Config;

class TemplatePush extends Command
{
    protected function configure()
    {
        // 指令配置
        $this->setName('templatepush');
        // 设置参数
        
    }

    protected function execute(Input $input, Output $output)
    {
    	// 指令输出
    	$output->writeln('app\command\templatepush');
        $wechat = new WechatService();
        //每次拿30条订单数据做推送
        $OrderPush = new \app\common\model\TemplatePush();
        $data= $OrderPush::with(['userInfo'])->where(['is_push'=>0])
            ->limit(30)->select()->toArray();
        if($data){
            $config = \app\common\model\Config::getAllConfig();

            $dealId = array();//记录请求接口失败的数据id
            $project = \app\common\model\User::$platform;

            $accessToken = Accesstoken::find(1);
            $accessToken = $accessToken['token'];
            foreach ($data as $v){
                $template_msg = json_decode($v['template'],true);
                if(!empty($v['user_info']['openid'])){
                    //根据类型组装内容
                    if($v['type'] == 1){
                        $selfProject = $project[$template_msg['project_id']];
                        //结算推送
                        $data = [
                            'first'=>['value'=>"【{$config['mini_name']}】收益更新通知！", 'color'=>'#173177'],
                            'keyword1'=>['value'=>date('Y-m-d',$template_msg['time']), 'color'=>'#173177'],
                            'keyword2'=>['value'=>"{$selfProject}广告单价【{$template_msg['single_price']}】元/次.昨日{$selfProject}收益【".floatval($template_msg['money'])."】！", 'color'=>'#173177'],
                            'remark'=>['value'=>"昨日{$selfProject}广告收益已经更新，邀请达人入驻享受永久广告收益分成", 'color'=>'#173177'],
                        ];
                    }else{
                        //提现推送
                        $data = [
                            'first'=>['value'=>"提现成功！", 'color'=>'#173177'],
                            'keyword1'=>['value'=>"{$template_msg['money']}元", 'color'=>'#173177'],
                            'keyword2'=>['value'=>date('Y-m-d H:i:s',$template_msg['time']), 'color'=>'#173177'],
                            'remark'=>['value'=>"感谢您的使用。", 'color'=>'#173177'],
                        ];
                    }
//                    print_r($data);

                    $r = $wechat->sendTemplateMsg($v['user_info']['openid'],$v['template_id'],$data,$accessToken);
                    $dealId[] = [
                        'is_push'=>1,'id'=>$v['id'],'push_err'=>json_encode($r)
                    ];
                }else{
                    $dealId[] = [
                        'is_push'=>1,'id'=>$v['id'],'push_err'=>'用户没有授权，无openid'
                    ];
                }

            }
            $OrderPush->saveAll($dealId);
        }
    }
}

<?php

namespace app\command;

use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;

class DelRedata extends Command
{
    protected function configure()
    {
        // 指令配置
        $this->setName('del_redata')->setDescription('Del Redata ');
        // 设置参数
        
    }

    protected function execute(Input $input, Output $output)
    {
    	// 指令输出
    	$output->writeln('app\command\delredata');

        //人为删除某段时间内的直推数据
    	$sql = "delete from qqxcx_user_distribution where id in (select id from (select id from qqxcx_user_distribution where id not in (select id from (select id,CONCAT(created_at,ip) as dtime from qqxcx_user_distribution where created_at BETWEEN ? and ? and type =1 group by dtime) d) and created_at BETWEEN ? and ? and type =1) dd)";
    	Db::execute($sql,[time()-3600,time(),time()-3600,time()]);
    }
}

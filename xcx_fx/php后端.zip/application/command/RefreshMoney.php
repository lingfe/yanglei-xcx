<?php


namespace app\command;


use app\common\model\Expert;
use think\console\Command;
use think\console\Input;
use think\console\Output;

/**
 * Class RefreshMoney
 * @package app\command
 * 每天清空昨日佣金
 */
class RefreshMoney extends Command
{
    protected function configure()
    {
        $this->setName('refreshmoney')->setDescription('Here is the refresh_money ');
    }

    protected function execute(Input $input, Output $output)
    {
        $output->writeln("TestCommand:");

        //每天0点定时清除用户昨天佣金
        Expert::update(['yesterday_money'=>0]," 1=1 ");
    }
}
<?php

namespace app\command;

use app\common\model\Expert;
use think\console\Command;
use think\console\Input;
use think\console\Output;

/**
 * Class RevertUploadNum
 * @package app\command
 * kyleeee
 * 每天恢复可上传次数
 */
class RevertUploadNum extends Command
{
    protected function configure()
    {
        // 指令配置
        $this->setName('revertuploadnum');
        // 设置参数
        
    }

    protected function execute(Input $input, Output $output)
    {
    	Expert::update(['day_upload_num'=>0],'1=1');
    }
}

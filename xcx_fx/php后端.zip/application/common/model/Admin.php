<?php
/**
 * Created by PhpStorm.
 * User: Kyle
 * Date: 2019/7/17
 * Time: 15:17
 */

namespace app\common\model;


use think\Model;

class Admin extends Model
{
    protected $pk = 'id';

    public function roles(){
        return $this->hasOne('Roles','id','roles_id');
    }

    public function deal($data){
        $news = new self();

        if(empty($data['id'])){
            //新增
            $data['salt'] = GetRandStr(4);
            $data['password'] = md5($data['password'].'.+!.'.$data['salt']);
            $save = $news->allowField(true)->save($data);
        }else{
            $user = Admin::where('id',$data['id'])->find();
            $user->username = $data['username'];
            if(!empty($data['roles_id'])){
                $user->roles_id = $data['roles_id'];
            }
//            $user->belong_to = $data['belong_to'];
//            $user->aim_user_id = $data['aim_user_id'];
            //编辑
            if($data['password']){
                $user->salt = GetRandStr(4);
                $user->password = md5($data['password'].'.+!.'.$user->salt);
            }
            $save = $user->save();
        }
        $save ? wapAjaxReturn(0,'操作成功',[],'/admin/user/list') :
            wapAjaxReturn(400,'操作失败');
    }
}
<?php
/**
 * Created by PhpStorm.
 * User: Kyle
 * Date: 2019/7/17
 * Time: 15:17
 */

namespace app\common\model;


use think\Db;
use think\Exception;
use think\Model;

class UserDistribution extends Model
{
    protected $pk = 'id';

//    protected $autoWriteTimestamp = true;

//    protected $createTime = 'created_at';
//    protected $updateTime = 'updated_at';



    public function user(){
        return $this->hasOne('Expert','user_id','user_id');
    }

    public function userFrom(){
        return $this->hasOne('Expert','user_id','origin_user_id');
    }

    public function secondUser(){
        return $this->hasOne('Expert','user_id','user_subordinate_id');
    }

    public function projectInfo(){
        return $this->belongsTo('Project','project_id','id');
    }

    public function wallpaperInfo(){
        return $this->hasOne('Wallpaper','id','wallpaper_id')
            ->field(['name','img','type','id']);
    }


    /**
     * 获取用户某一天的收益和预估收益
     * @param $day 如 2020-09-09
     * @param $user_id
     * @param bool $onlySelf 是否只查询自推数据， false-否
     * @return array|\PDOStatement|string|Model|null
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function getPriceByDay($day,$user_id,$onlySelf = false){
        $where = ['user_id'=>$user_id];
        if($onlySelf){$where['type'] = 1;}
        return self::where($where)
            ->whereBetweenTime('created_at',$day)
            ->field(['count(id) as count','sum(true_price) as true_price','sum(predict_price) as predict_price','price_deal_staus'])
            ->find();
    }

    /**
     * 获取用户当月实际收益
     * @param $user_id
     * @return array|\PDOStatement|string|Model|null
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function getPriceByMonth($user_id,$m=''){
        $time = mFristAndLast('',$m);
        return self::where(['user_id'=>$user_id,'price_deal_staus'=>[1,2]])
            ->whereBetweenTime('created_at',$time['firstday'],$time['lastday'])
            ->field(['count(id) as count','sum(true_price) as true_price','sum(predict_price) as predict_price','price_deal_staus'])
            ->find();
    }

    /**
     * 获取团队佣金明细
     * @param $userId
     * @return array
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function getTeamMoney($userId){
        return self::where(['user_id'=>$userId,'type'=>array(2,3)])
            ->group('next_user_id')
            ->field(['sum(true_price) as price','next_user_id'])
            ->select()->toArray();
    }

    /**
     * 获取用户佣金总计
     * @param $userId
     * @return array
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function getUserTeamMoney($userId){
        return self::where(['user_id'=>$userId,'type'=>array(1,2,3)])
            ->sum('true_price');
    }


    public function dealAdDistributionTopic($userInfo,$wallpaperInfo,$params){
        $userDistribution = new UserDistribution();
        $insertArray = $userArr = array();
        $predictConfig = Config::getAllConfig();
        $time = time();

        //处理自推分销
        $distribution['user_id'] = $userInfo['user_id'];
        $distribution['type'] = 1;
        $distribution['price_deal_staus'] = 0;
        $distribution['origin_user_id'] = $userInfo['user_id'];
        $distribution['next_user_id'] = 0;
        $distribution['predict_price'] = !empty($predictConfig['money_fir_'.$params['platform']])?$predictConfig['money_fir_'.$params['platform']]:0;
        $distribution['created_at'] = $time;
        $distribution['updated_at'] = $time;
        $distribution['platform'] = $params['platform'];
        $distribution['wallpaper_id'] = $params['id'];
        $distribution['openid'] = !empty($params['openid'])?$params['openid']:'';
        $distribution['ip'] = !empty($_SERVER['REMOTE_ADDR'])?$_SERVER['REMOTE_ADDR']:'';
        $distribution['nickname'] = !empty($params['nickname'])?urlencode($params['nickname']):'';
        $distribution['avatar_url'] = !empty($params['avatar_url'])?$params['avatar_url']:'';
        $insertArray[] = $distribution;

        //处理上级分销
        if( !empty($userInfo['fir_distribution'])){
            $distribution['user_id'] = $userInfo['fir_distribution'];
            $distribution['type'] = 2;
            $distribution['price_deal_staus'] = 0;
            $distribution['origin_user_id'] = $userInfo['user_id'];
            $distribution['next_user_id'] = $userInfo['user_id'];
            $distribution['predict_price'] = !empty($predictConfig['money_sec_'.$params['platform']])?$predictConfig['money_sec_'.$params['platform']]:0;
            $distribution['created_at'] = $time;
            $distribution['updated_at'] = $time;
            $distribution['platform'] = $params['platform'];
            $distribution['wallpaper_id'] = $params['id'];
            $distribution['openid'] = !empty($params['openid'])?$params['openid']:'';
            $distribution['ip'] = '';
            $distribution['nickname'] = !empty($params['nickname'])?urlencode($params['nickname']):'';
            $distribution['avatar_url'] = !empty($params['avatar_url'])?$params['avatar_url']:'';
            $insertArray[] = $distribution;
        }

        if($insertArray){
            Db::startTrans();
            try{
                //执行之前走一遍数据查询
                if(!empty($_SERVER['REMOTE_ADDR'])){
                    $count = $this->hasDataInSpecialTime($userInfo['user_id'],$params['platform'],20,$_SERVER['REMOTE_ADDR']);
                    if($count){throw  new Exception('20秒内已经有数据了');}
                }

                //更新分销信息明细表
                $save = $userDistribution->saveAll($insertArray);
                if(!$save){throw  new Exception('下单存储数据存储失败');}


                Db::commit();
                return true;
            }catch (Exception $e){
                Db::rollback();
                return false;
            }
        }
        return false;
    }


    /**
     * 判断某个项目中，某个推广者的小程序用户使用情况
     * @param $userId
     * @param $platform
     * @param int $time
     * @param $ip
     * @return float|string
     */
    public function hasDataInSpecialTime($userId,$platform,$time=20,$ip){
        //判断当前推广数据中，小程序用户信息是否在时间间隔内已经存在数据，若存在则不做处理
        $data = self::where(['user_id'=>$userId,'platform'=>$platform,'ip'=>$ip])
            ->whereBetweenTime('created_at',time(),time()+$time)->count();
        return $data;
    }


}
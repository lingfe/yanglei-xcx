<?php
/**
 * Created by PhpStorm.
 * User: Kyle
 * Date: 2019/12/24
 * Time: 16:30
 */

namespace app\common\model;


use think\Exception;
use think\facade\Request;
use think\facade\Session;
use think\Model;

class Questions extends Model
{
    protected $pk = 'id';
    protected $autoWriteTimestamp = true;

    protected $createTime = 'created_at';
    protected $updateTime = 'updated_at';

    public function validate($data){
        if(empty($data['question'])){wapAjaxReturn(400,'请输入问题');}
        if(empty($data['answer'])){wapAjaxReturn(400,'请输入答案');}
        if(mb_strlen($data['question']) > 100){wapAjaxReturn(400,'标题不能超过50个字');}

        if(!empty($data['id'])){
            if(!is_int($data['id']+0)){wapAjaxReturn(400,'数据提供异常');}
        }
    }

    public function deal($data){
        $news = new self();

        if(empty($data['id'])){
            //新增
            $data['author'] = Session::get('username');
            $save = $news->allowField(true)->save($data);
        }else{
            //编辑
            $save = $news->allowField(true)->save($data,['id'=>$data['id']]);
        }
        $save ? wapAjaxReturn(0,'操作成功',[],'/admin/questions') :
            wapAjaxReturn(400,'操作失败');
    }
}
<?php
/**
 * Created by PhpStorm.
 * User: Kyle
 * Date: 2019/7/17
 * Time: 15:17
 */

namespace app\common\model;


use think\facade\Cache;
use think\Model;

class Config extends Model
{
    protected $pk = 'id';


    /**
     * 获取微信公众号所需配置
     * @return array
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function getWechatConfig(){
        $data = self::where(['config_key'=>array(
            'wechat_token','wechat_appid','wechat_secret','wechat_thumb_media_id','wechat_img_url'
        )])->select()->toArray();
        if($data){
            $data = array_column($data,null,'config_key');
        }
        $new = array();
        if($data){
            foreach ($data as $k=>$v){
                $new[$k] = $v['config_value'];
            }
        }
        return $new;
    }


    /**
     * 根据键查询信息
     * @param $configKey
     * @return array|\PDOStatement|string|Model|null
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function getInfoByKey($configKey){
        return self::where(['config_key'=>$configKey])->find();
    }


    /**
     * 获取扣量信息
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function getDelDistributionInfo(){
        $data = Cache::get('del_distribution');
        if(empty($data)){

            $info = self::where(['config_key'=>'del_distribution'])->find();
            Cache::set('del_distribution',$info->config_value,365*24*3600);//保存一年
            $data = $info->config_value;
        }
        return $data;
    }


    /**
     * 根据模块查询配置信息
     * @param $module
     * @return array|\PDOStatement|string|\think\Collection
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public static function getInfoByModule($module){
        return self::where(['module'=>$module])->column('config_value','config_key');
    }

    /**
     * 根据键查询，返回键值对
     * @param $configKey
     * @return array
     */
    public static function getInfoToColumn($configKey){
        return self::where(['config_key'=>$configKey])->column('config_value','config_key');
    }






    /**
     * 获取资源存储配置信息
     * @return array|mixed|\PDOStatement|string|\think\Collection
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public static function getSourceConfig(){
        $cache = Cache::get('source-content');
        if(empty($cache)){
            $data = self::getInfoByModule(['source_module','win_module']);
            Cache::set('source-content',json_encode($data),30*24*3600);//保存一个月
        }else{
            $data = json_decode($cache,true);
        }
        return $data;
    }

    //获取预估佣金配置
    public  function getPredictConfig(){
        $cache = Cache::get('predict');
        if(empty($cache)){
            $data = self::getInfoByModule(['predict_module']);
            Cache::set('predict',json_encode($data),60*24*3600);//保存一个月
        }else{
            $data = json_decode($cache,true);
        }
        return $data;
    }



    public static  function getAllConfig()
    {
        $cache = Cache::get('all_config');
        if (empty($cache)) {
            $data = self::column('config_value', 'config_key');
            Cache::set('all_config', json_encode($data), 60 * 24 * 3600);//保存2个月
        } else {
            $data = json_decode($cache, true);
        }
        return $data;
    }
}
<?php


namespace app\common\model;


use think\Model;

class Permission extends Model
{
    protected $pk = 'id';


    public function deal($data){
        $news = new self();

        if(empty($data['id'])){
            //新增
            $save = $news->allowField(true)->save($data);
        }else{
            //编辑
            $save = $news->allowField(true)->save($data,['id'=>$data['id']]);
        }
        $save ? wapAjaxReturn(0,'操作成功',[],'/admin/permission/list') :
            wapAjaxReturn(400,'操作失败');
    }

    public function getList(){
        return self::where('menu_action','<>','Permission')->select()->toArray()
            ;
    }
}
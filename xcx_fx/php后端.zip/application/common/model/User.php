<?php
/**
 * Created by PhpStorm.
 * User: Kyle
 * Date: 2019/7/17
 * Time: 15:17
 */

namespace app\common\model;


use think\Model;

class User extends Model
{
    protected $pk = 'user_id';

    protected $autoWriteTimestamp = true;

    protected $createTime = 'created_at';
    protected $updateTime = 'updated_at';

    //小程序用户来源平台
    public static $platform = [
        'qq'=>'QQ','wx'=>'微信','dy'=>'抖音','ks'=>'快手'
    ];

    public static $platform2 = [
        [
            'id'=>'qq',
            'name'=>'QQ'
        ],
        [
            'id'=>'wx',
            'name'=>'微信'
        ],
        [
            'id'=>'dy',
            'name'=>'抖音'
        ],
        [
            'id'=>'ks',
            'name'=>'快手'
        ],
    ];

    /**
     * 获取用户信息
     * @param $id
     * @return mixed
     */
    public function getUserInfo($id){
        return self::get($id);
    }



}
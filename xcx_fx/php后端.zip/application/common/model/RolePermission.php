<?php


namespace app\common\model;


use think\Model;

class RolePermission extends Model
{
    protected $pk = 'id';

    public function getPermissionByRoleId($roleId){
        return self::where(['role_id'=>$roleId])->field("permission_action")->select()->toArray()
            ;
    }
}
<?php
/**
 * Created by PhpStorm.
 * User: Kyle
 * Date: 2019/7/17
 * Time: 15:17
 */

namespace app\common\model;


use think\Model;

class UserPrice extends Model
{
    protected $pk = 'id';

    protected $autoWriteTimestamp = true;

    protected $createTime = 'created_at';
    protected $updateTime = 'updated_at';

    public static $_type =[
        0=>'支付宝账号打款',
        1=>'微信付款到零钱',
        2=>'微信收款码打款',
        3=>'支付宝收款码打款',
    ];

    public function user(){
        return $this->hasOne('Expert','user_id','user_id');
    }

    public function getPaginateList($user_id,$field='*'){
        return self::where(['user_id'=>$user_id])->field($field)->order('id','desc')->paginate(10,false)
            ->toArray();
    }
}
<?php
/**
 * Created by PhpStorm.
 * User: eeddWDs
 * Date: 2030/1/1
 * Time: 88:88
 */

namespace app\common\model;


use think\Model;

class DayPrice extends Model
{
    protected $pk = 'id';

    protected $autoWriteTimestamp = true;

    protected $createTime = 'created_at';
    protected $updateTime = 'updated_at';

    public function savePrice($time,$platform,$price){
        //查看该时间是否有数据，有的话走更新，没有走新增
        $data = self::where(['day'=>$time])->find();
        if($data == null){
            $data = new self();
        }
        $data->day = $time;
        $data->$platform = $price;
        $data->save();
    }
}
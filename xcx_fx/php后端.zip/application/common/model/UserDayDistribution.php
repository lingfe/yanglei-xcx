<?php
/**
 * Created by PhpStorm.
 * User: Kyle
 * Date: 2019/7/17
 * Time: 15:17
 */

namespace app\common\model;


use think\Db;
use think\Exception;
use think\Model;

class UserDayDistribution extends Model
{
    protected $pk = 'id';

//    protected $autoWriteTimestamp = true;

//    protected $createTime = 'created_at';
//    protected $updateTime = 'updated_at';

    //真实佣金发放状态
    public static $trueStatus = [
        1=>'待发放',2=>'已发放',3=>'发放中',4=>'违规冻结'
    ];

    public function user(){
        return $this->hasOne('Expert','user_id','user_id');
    }

    public function projectInfo(){
        return $this->belongsTo('Project','project_id','id');
    }




}
<?php
/**
 * Created by PhpStorm.
 * User: Kyle
 * Date: 2019/7/17
 * Time: 15:17
 */

namespace app\common\model;


use think\Db;
use think\Model;

class Wallpaper extends Model
{
    protected $pk = 'id';

    protected $autoWriteTimestamp = true;

    protected $createTime = 'created_at';
    protected $updateTime = 'updated_at';

    public static $_type = [
        1=>'壁纸',
        2=>'动态壁纸',
        3=>'背景图',
        4=>'头像',
        5=>'表情包',
    ];

    public function cate(){
        return $this->hasOne('Cate','id','cate_id')->where(['is_deleted'=>0]);
    }

    public function author(){
        return $this->hasOne('Admin','id','author_id');
    }

    public function expert(){
        return $this->hasOne('Expert','user_id','author_id');
    }

    //返回某个达人下未删除的素材类型各自总数
    public static function sucaiData($userId){
        return self::where(['author_id'=>$userId,'source'=>2,'is_deleted'=>0])
           ->field([
                'SUM(case when type=1 then 1 else 0 end) sucai1',
                'SUM(case when type=2 then 1 else 0 end) sucai2',
                'SUM(case when type=3 then 1 else 0 end) sucai3',
                'SUM(case when type=4 then 1 else 0 end) sucai4',
                'SUM(case when type=5 then 1 else 0 end) sucai5',
                ])->find()->toArray();
    }

    //返回达人前三个素材
    public function getImgThree($authorIds){
        //查询当前数据的每个达人前三个壁纸
        $sql = "
            SELECT 
                img,type,author_id,id,thumb_img,video_url,expression_video_url,expression_show_video
            FROM
                qqxcx_wallpaper AS p,
                (SELECT 
                    GROUP_CONCAT(id order by field(type,4,5,1,2,3),id desc) AS ids
                FROM
                    qqxcx_wallpaper
                WHERE is_deleted = 0 and status=1 and author_id in ({$authorIds})
                GROUP BY author_id) AS b
            WHERE
                FIND_IN_SET(p.id, b.ids) BETWEEN 1 AND 3 order by field(type,4,5,1,2,3),id desc;";
        $data = Db::query($sql);
        return $data;
    }

    //根据id数组返回数据
    public function getListBySearchId($wid){
        return self::where(['is_deleted'=>0,'status'=>1,
            'id'=>$wid])
            ->field('img,type,author_id,id,thumb_img,video_url,expression_video_url,expression_show_video')->select()->toArray();
    }
}
<?php
/**
 * Created by PhpStorm.
 * User: Kyle
 * Date: 2019/7/17
 * Time: 15:17
 */

namespace app\common\model;


use think\Model;

class WallpaperZan extends Model
{
    protected $pk = 'id';

    protected $autoWriteTimestamp = true;

    protected $createTime = 'created_at';
    protected $updateTime = 'updated_at';

    public function getList($userId,$platform){
        return self::where(['user_id'=>$userId,'platform'=>$platform])->select()->toArray();
    }
}
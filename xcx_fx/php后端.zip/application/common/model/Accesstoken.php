<?php
/**
 * Created by PhpStorm.
 * User: eeddWDs
 * Date: 2030/1/1
 * Time: 88:88
 */

namespace app\common\model;


use think\Model;

class Accesstoken extends Model
{
    protected $pk = 'id';

    protected $autoWriteTimestamp = false;



}
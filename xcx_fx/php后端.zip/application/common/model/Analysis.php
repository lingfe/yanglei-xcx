<?php
/**
 * Created by PhpStorm.
 * User: eeddWDs
 * Date: 2030/1/1
 * Time: 88:88
 */

namespace app\common\model;


use think\Model;

class Analysis extends Model
{
    protected $pk = 'id';

    protected $autoWriteTimestamp = false;


    public function getTimeDay($platform,$code='7d',$sort='asc'){
        $where[] = ['platform','=',$platform];

        switch($code){
            case $code == '7d':
                $where[] = ['created_at','>',strtotime(date('Ymd',strtotime('-6 day')))];
                break;
            case $code == '30d':
                $where[] = ['created_at','>',strtotime(date('Ymd',strtotime('-29 day')))];
                break;
            case $code == '60d':
                $where[] = ['created_at','>',strtotime(date('Ymd',strtotime('-59 day')))];
                break;
            default:
                $where[] = ['created_at','>',strtotime(date('Ymd',strtotime('-6 day')))];
        }

        $r =  self::where($where)->field([
            'sum(enter_num) as enter_num','sum(wallpaper_num) as wallpaper_num',
            'sum(ad_num) as ad_num','sum(normal_num) as normal_num',
            'sum(ad_end) as ad_end','sum(ad_stop) as ad_stop',
            'sum(ad_error) as ad_error'
            ,'sum(total_download) as total_download'
            ,'sum(ad_end_platform) as ad_end_platform'
            ,'created_at','from_unixtime(created_at,"%m-%d") as created_format'
        ])->order(['created_at'=>$sort])->group('created_at')->select()->toArray();

        return $r;


    }

    public function dealData($r,$code='7d'){
        $time = array_column($r,'created_at');
        $oldR = array_column($r,null,'created_at');
        switch($code){
            case $code == '7d':
                $forInt = 6;
                break;
            case $code == '30d':$forInt=29;
                break;
            case $code == '60d':$forInt=59;
                break;
            default:
                $forInt=6;
        }

        $newR = array();
        for ($i=$forInt;$i>=0;$i--){
            $timeInt = strtotime(date('Ymd',strtotime("-{$i} day")));
            if(!in_array($timeInt,$time)){
                $newR[] = [
                    'enter_num'=>0,
                    'wallpaper_num'=>0,
                    'ad_num'=>0,
                    'normal_num'=>0,
                    'ad_end'=>0,
                    'ad_stop'=>0,
                    'ad_error'=>0,
                    'total_download'=>0,
                    'ad_end_platform'=>0,
                    'created_at'=>$timeInt,
                    'created_format'=>date('m-d',$timeInt)
                ];
            }else{
                $newR[] = $oldR[$timeInt];
            }
        }
        return $newR;
    }
}
<?php
/**
 * Created by PhpStorm.
 * User: 666999
 * Date: 2019/7/17
 * Time: 15:17
 */

namespace app\common\model;


use think\Exception;
use think\Model;

class Expert extends Model
{
    protected $pk = 'user_id';

    protected $autoWriteTimestamp = true;

    protected $createTime = 'created_at';
    protected $updateTime = 'updated_at';

    /**
     * 获取用户信息
     * @param $id
     * @return mixed
     */
    public function getUserInfo($id){
        return self::get($id);
    }

    public function parentInfo(){
        return $this->belongsTo('Expert','fir_distribution','user_id');
    }

    public function imgCount(){
        return $this->hasOne('Wallpaper','author_id','user_id')
            ->where(['is_deleted'=>0,'status'=>1])
            ->field(['count(*) as img_count','author_id'])->group('author_id');
    }

    public function imgThree(){
        return $this->hasMany('Wallpaper','author_id','user_id')
            ->where(['is_deleted'=>0,'status'=>1])
            ->field(['img','author_id','type','id'])
            ->order(['field(type,4,5,1,2,3)'=>true])
            ->limit(3);
    }




    /**
     * 按佣金排序
     * @return array
     * @throws \think\exception\DbException
     */
    public function getPaginateList($field='*'){

        $config = (new Config())->getInfoByKey('ranking_num');

        $createNum = ($config != null && is_numeric($config['config_value']))?$config['config_value']:10;
        if(empty($createNum)){return ['current_page'=>0,'last_page'=>0,'data'=>[]];}

        return self::field($field)
            ->where("yesterday_money <> 0")->order('total_money','desc')->paginate($createNum,false)
            ->toArray();
    }

    /**
     * 获取汇总信息
     * @return array|\PDOStatement|string|Model|null
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function getStatistics($user=0){
        if(!$user){

            return self::field(['sum(yesterday_money) as total_money','count(*) as total_person'])
                ->find();
        }
        return self::field(['sum(yesterday_money) as total_money','count(*) as total_person'])
            ->where(['fir_distribution'=>$user])
            ->find();
    }

    /**
     * 获取团队下级列表分页信息
     * @param $userId
     * @param string $field
     * @return array
     * @throws \think\exception\DbException
     */
    public function getTeamList($userId){
        return self::where(['fir_distribution'=>$userId])
            ->order('created_at','desc')->paginate(10,false)
            ->toArray();
    }


    /**
     * 获取下级总人数
     * @return float|string
     */
    public function getNextTeam($userID){
        return $this->where(['fir_distribution'=>$userID])
            ->field(['count(*) as num','fir_distribution'])
            ->group('fir_distribution')
            ->select()->toArray();
    }


    public function doExpertMd5($pwd,$pwdSalt){
        return md5($pwd.'.2+r!0.M'.$pwdSalt);
    }

    /**
     * @param $user_id
     * @param $fir_distribution
     * @return bool|string
     * kyyle
     * 变更新上级和合伙人
     */
    public static function changeTeam($user_id,$fir_distribution){
        //查询新上级的合伙人id
        $partnerInfo = self::find($fir_distribution);
        if($partnerInfo == null){return '查询不到上级信息';}

        try {
            //先处理当前用户的上级，再变更其下的合伙人
            self::update(['fir_distribution'=>$fir_distribution]
                ,['user_id'=>$user_id]);

//            self::changePartnerId($user_id,$partnerInfo->partner_id);

            return true;
        }catch (Exception $e){
            return $e->getMessage();
        }
    }
}
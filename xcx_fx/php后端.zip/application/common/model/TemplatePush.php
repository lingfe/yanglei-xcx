<?php
/**
 * Created by PhpStorm.
 * User: eeddWDs
 * Date: 2030/1/1
 * Time: 88:88
 */

namespace app\common\model;


use think\Model;

class TemplatePush extends Model
{
    protected $pk = 'id';

    protected $autoWriteTimestamp = true;

    protected $createTime = 'created_at';
    protected $updateTime = 'updated_at';

    public function userInfo(){
        return $this->belongsTo('Expert','user_id','user_id');
    }
}
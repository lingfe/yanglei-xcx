<?php


namespace app\common\services;


use app\common\model\Config;
use OSS\OssClient;
use Qiniu\Auth;
use Qiniu\Storage\BucketManager;
use think\Exception;

class WallpaperService
{
    public static function delFile($data){
        try{
            //查询存储设置缓存，没有的话需要重新数据库并存储到缓存中
            $config = Config::getAllConfig();
            if($config['aliyun_keyid']){
                $ossClient = new OssClient($config['aliyun_keyid'],
                    $config['aliyun_keysecret'], $config['aliyun_endpoint']);
            }else{
                $ossClient = null;
            }
            if($config['qiniu_keyid']){
                // 构建鉴权对象
                $auth = new Auth($config['qiniu_keyid'],$config['qiuniu_keysecret']);
                // 管理资源
                $bucketManager = new BucketManager($auth);
            }else{
                $bucketManager = null;
            }
            foreach ($data as $v){
                if($v){
                    if(!strstr($v,'http')){
                        //本地删除
                        @unlink($_SERVER['DOCUMENT_ROOT'] . $v);
                    }else{
                        //需要根据域名判断是本地富文本存储，还是阿里云存储，还是七牛云存储
                        if(!empty($config['aliyun_new_domain']) && is_int(strpos($v,$config['aliyun_new_domain']))){
                            //阿里云删除
                            $path_file=str_replace($config['aliyun_new_domain'].'/','',$v);//去掉域名
                            @$ossClient->deleteObject($config['aliyun_buckey'],$path_file);
                        }

                        if(!empty($config['qiniu_new_domain']) && is_int(strpos($v,$config['qiniu_new_domain']))){
                            //七牛云删除
                            $path_file=str_replace($config['qiniu_new_domain'].'/','',$v);//去掉域名
                            @$bucketManager->delete($config['qiniu_bucket'], $path_file);
                        }

                        if(!empty($config['mini_domain']) && is_int(strpos($v,$config['mini_domain']))){
                            //本地带域名的删除
                            $path_file=str_replace($config['mini_domain'],'',$v);//去掉域名
                            @unlink($_SERVER['DOCUMENT_ROOT'] . $path_file);
                        }
                    }
                }
            }
        }catch (Exception $e){}
    }
}
<?php


namespace app\common\services;


use app\common\model\Config;
use think\Exception;

/**
 * Class WechatService
 * @package app\common\services
 * 微信开发功能
 * llkkeeyy
 */
class WechatService
{

    //获取新的access_token
     public function getNowAccesstoken(){
         $config = Config::getAllConfig();
        $url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='
            . $config['g_appid']
            . '&secret=' . $config['g_appsecret'];
        $accesstxt = curl_file_get_contents($url);
        $tempArr = json_decode ($accesstxt, true);
        if (isset($tempArr['access_token'])) {
            return $tempArr['access_token'];
        }else{
            throw new Exception('公众号拿不到最新的token');
        }
    }

    //模板消息推送
    public function sendTemplateMsg($openid,$templateId,$data,$accessToken){
        try{
            $content = [
                'touser'=>$openid,
                'template_id'=>$templateId,
                'data'=>$data
            ];
            $url = 'https://api.weixin.qq.com/cgi-bin/message/template/send?access_token='.$accessToken;
            $msg = httpByPost($url,$content,true);
        }catch (Exception $e){
            $msg = $e->getMessage();
        }

         return $msg;


    }

}
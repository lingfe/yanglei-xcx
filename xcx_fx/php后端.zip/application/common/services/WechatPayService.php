<?php


namespace app\common\services;


use think\Exception;
use think\facade\Config;

class WechatPayService
{
    function transfer($data){
        //支付信息
        $wxchat['appid'] = Config::get('params.wechat_pay.appid');
        $wxchat['mchid'] = Config::get('params.wechat_pay.mchid');
        $webdata = array(
            'mch_appid' => $wxchat['appid'],//商户账号appid
            'mchid'     => $wxchat['mchid'],//商户号
            'nonce_str' => md5(time()),//随机字符串
            'partner_trade_no'=> $data['order_sn'], //商户订单号，需要唯一
            'openid' => $data['openid'],//转账用户的openid
            'check_name'=> 'NO_CHECK', //OPTION_CHECK不强制校验真实姓名, FORCE_CHECK：强制 NO_CHECK：
            'amount' => $data['money']*100, //付款金额单位为分
            'desc'   => '佣金提现',//企业付款描述信息
            'spbill_create_ip' => request()->ip(),//获取IP
        );
        foreach ($webdata as $k => $v) {
            $tarr[] =$k.'='.$v;
        }
        sort($tarr);
        $sign = implode($tarr, '&');
        $sign .= '&key='.Config::get('params.wechat_pay.key');
        $webdata['sign']=strtoupper(md5($sign));
        $wget = $this->ArrToXml($webdata);//数组转XML
        $pay_url = 'https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers';//api地址
        $res = $this->postData($pay_url,$wget);//发送数据
        if(!$res){
            return array('status'=>1, 'msg'=>"Can't connect the server" );
        }
        $content = simplexml_load_string($res, 'SimpleXMLElement', LIBXML_NOCDATA);
        if(strval($content->return_code) == 'FAIL'){
            return array('status'=>1, 'msg'=>strval($content->return_msg));
        }
        if(strval($content->result_code) == 'FAIL'){
            return array('status'=>1, 'msg'=>strval($content->err_code),':'.strval($content->err_code_des));
        }
        $rdata = array(
            'mch_appid'        => strval($content->mch_appid),
            'mchid'            => strval($content->mchid),
            'device_info'      => strval($content->device_info),
            'nonce_str'        => strval($content->nonce_str),
            'result_code'      => strval($content->result_code),
            'partner_trade_no' => strval($content->partner_trade_no),
            'payment_no'       => strval($content->payment_no),
            'payment_time'     => strval($content->payment_time),
        );
        return $rdata;
    }

    //数组转XML
    function ArrToXml($arr)
    {
        if(!is_array($arr) || count($arr) == 0) return '';
        $xml = "<xml>";
        foreach ($arr as $key=>$val)
        {
            if (is_numeric($val)){
                $xml.="<".$key.">".$val."</".$key.">";
            }else{
                $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
            }
        }
        $xml.="</xml>";
        return $xml;
    }


    //发送数据
    function postData($url,$postfields,$second=30,$aHeader=array()){
        $isdir = env('root_path')."cert/";
        $ch = curl_init();//初始化curl

        curl_setopt($ch, CURLOPT_TIMEOUT, $second);//设置执行最长秒数

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//要求结果为字符串且输出到屏幕上

        curl_setopt($ch, CURLOPT_URL, $url);//抓取指定网页

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);// 终止从服务端进行验证

        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);//

        curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM');//证书类型

        curl_setopt($ch, CURLOPT_SSLCERT, $isdir . 'apiclient_cert.pem');//证书位置

        curl_setopt($ch, CURLOPT_SSLKEYTYPE, 'PEM');//CURLOPT_SSLKEY中规定的私钥的加密类型

        curl_setopt($ch, CURLOPT_SSLKEY, $isdir . 'apiclient_key.pem');//证书位置

        if (count($aHeader) >= 1) {

            curl_setopt($ch, CURLOPT_HTTPHEADER, $aHeader);//设置头部

        }

        curl_setopt($ch, CURLOPT_POST, 1);//post提交方式

        curl_setopt($ch, CURLOPT_POSTFIELDS, $postfields);//全部数据使用HTTP协议中的"POST"操作来发送


        $data = curl_exec($ch);//执行回话

        if ($data) {

            curl_close($ch);

            return $data;

        } else {

            $error = curl_errno($ch);


            curl_close($ch);

            throw new Exception("call faild, errorCode:$error");

        }


    }


    /**
     *生成订单号
     * uniqid - 官方是这样说的：
     * Gets a prefixed unique identifier based on the current time in microseconds.
     */
    function build_order_no()
    {
        return 'yongjin'.date('Ymd').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
    }
}
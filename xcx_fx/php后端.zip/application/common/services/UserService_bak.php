<?php


namespace app\common\services;



use app\common\model\Config;
use app\common\model\Expert;
use app\common\model\UserDistribution;
use think\Exception;
use think\facade\Request;
use think\Model;

class UserService2
{
    /**
     * @param $userId 推广达人id
     * @return mixed
     */
    public function getUserInfo($userId){
        return Expert::find($userId);
    }

    /**
     * 看广告，广告分销处理佣金数据
     */
    public function addMoneyFromAd($wallpaperInfo){
        sleep(rand(1,2));//给每个进来的请求产生随机的停留时间
        writeLog(date('Y-m-d H:i:s',time()),'分销处理');
        writeLog('进入分销方法','分销处理');
        $params = Request::post();
        writeLog($params,'分销处理');
        try{
            //扣减基数
            $baseNum = 100;//每100条为一个基数点
            //增加扣量处理
            //todo 需要针对每个达人计算，而不是总的计算
            $fp = fopen(__DIR__.'/../../del.txt','r');
            if(flock($fp,LOCK_EX)){
                //获取当前需要扣量的数据
                $localData = file_get_contents(__DIR__.'/../../del.txt');
                $config = Config::getAllConfig();;
                $delDistribution = $config['del_distribution'];
                if(!empty($delDistribution)){
                    //需要扣量，获取当前进入del文件的数量，判断是否超过101了，超过恢复0
                    if($localData+1 > $baseNum){
                        file_put_contents(__DIR__.'/../../del.txt',0);
                        throw new \think\Exception('成功啦');
                    }
                    //判断当前del的数量，是否在可入库范围内
                    $canEnterNum = $baseNum - $delDistribution;
                    if($localData > $canEnterNum){
                        //已经超过可入库数量
                        file_put_contents(__DIR__.'/../../del.txt',$localData+1);
                        //继续+1，超过100恢复正常入库处理
                        throw new \think\Exception('成功啦');
                    }
                    //可入库需增量
                    file_put_contents(__DIR__.'/../../del.txt',$localData+1);
                }

                flock($fp,LOCK_UN);
            }else{
                echo "LOCKing.........";
            }
            fclose($fp);


            $userInfo = $this->getUserInfo($wallpaperInfo['author_id']);
            if($userInfo == null){wapAjaxReturn(400,'当前用户没有成为推广达人');}

            writeLog('参数校验正确','分销处理');
            $deal = (new UserDistribution())->dealAdDistributionTopic($userInfo,$wallpaperInfo,$params);
            if($deal){
                //单纯递增,素材下载量
                db('wallpaper')->where('id='.$wallpaperInfo['id'])->setInc('download_count',1); // 原数值加1
            }
            wapAjaxReturn(0,'处理成功');
        }catch(Exception $exception){
            wapAjaxReturn(400,'处理失败',$exception->getMessage());
        }
    }
}
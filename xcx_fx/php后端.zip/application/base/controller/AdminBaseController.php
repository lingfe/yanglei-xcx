<?php
namespace app\base\controller;
use app\common\model\Permission;
use app\common\model\RolePermission;
use think\facade\Cache;
use think\facade\Config;
use think\facade\Request;
use think\facade\Session;

/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 2018/5/23
 * Time: 17:29
 */
class AdminBaseController extends \think\Controller
{

    protected $_auto_session_time = 4*3600;

    protected $beforeActionList = [
        'before'
    ];

    protected function before(){
        //根据当前的用户角色获取权限菜单
        if(Session::get('is_super') == 1){
            //超级管理员
            $permission = Permission::where('menu_action','<>','Permission')->select()->toArray();
        }else{
            //查询当前的权限
            $rolePermission = RolePermission::where(['role_id'=>Session::get('roles_id')])
                ->select()->toArray();
            if($rolePermission){
                $permission = Permission::where(['menu_action'=>array_column($rolePermission,'permission_action')])
                    ->order('id','asc')->select()->toArray();
            }else{$permission = [];}
        }
        if($permission){
            $new = array();
            foreach ($permission as $v){
                $new[$v['ul_name']]['name'] = $v['ul_name'];
                $new[$v['ul_name']]['icon'] = $v['icon'];
                $new[$v['ul_name']]['value'][] = $v;
            }
            $permission  = array_values($new);
            unset($new,$v);
        }
        $this->assign([
            'actionM' => Request::controller()
            ,'admin_name'=>Session::get('username')
            ,'permissions'=>$permission
            ,'is_super'=>Session::get('is_super')
        ]);

    }
}
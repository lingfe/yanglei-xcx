<?php
namespace app\base\controller;
use think\facade\Request;
use think\facade\Session;

/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 2018/5/23
 * Time: 17:29
 */
/*
 * //    ekly团队开发
//微信：hong920399
//唯一标记，客气了兄弟
 */
class ApiBaseController extends \think\Controller
{

    protected $_auto_session_time = 30*24*3600; //不同控制器自定义session生存时间

    protected $_login_validate;  //需要校验登录的数组

    protected $_ip_validate; //需要ip校验数组

    protected $_sign_validate;     //签名校验接口

    protected $beforeActionList = [
        'before'
    ];

    protected function before(){
        crossdomain();
    }


}
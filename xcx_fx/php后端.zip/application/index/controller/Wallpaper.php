<?php


namespace app\index\controller;


use app\common\model\Config;
use app\common\model\Expert;
use app\common\model\Instruction;
use app\services\AliyunOssServices;
use app\services\WallpaperService;
use OSS\OssClient;
use think\Exception;
use think\facade\Request;
use think\facade\Session;
use think\facade\View;
use think\Model;

class Wallpaper extends CommonBase
{
    /**
     * 团发卡对
     * kely
     * 新首页入口
     */
    public function enterInit(){
        //查看当前达人有无自定义封面
        $data = Expert::find(Session::get('wechatUserId'));

        $w = array();
        if($data['self_cover']){
            $wid = explode(",",$data['self_cover']);
            $wData = \app\common\model\Wallpaper::where(['is_deleted'=>0,'status'=>1,
            'id'=>$wid])
                ->field('img,type,author_id,id,thumb_img,video_url')->select()->toArray();
            if($wData){
                $config = \app\common\model\Config::getAllConfig();
                foreach ($wData as &$v){
                    $v['is_gif'] = checkIsGif($v['img'])?1:0;
                    //类型为头像、表情包走缩略图展现，壁纸、动态壁纸、背景图走裁剪图展现
                    $size = isset($thumbSize[$v['type']])?$thumbSize[$v['type']][0]:'';
                    if(in_array($v['type'],[1,2,3])){
                        $v['img'] = getThumbImg($v['thumb_img'],$config['mini_domain']);
                    }else{
                        //判断是否为gif图，是的话根据配置判断是否要展示动图或静态图
                        if(checkIsGif($v['img']) && $config['open_gif'] != 1){
                            $v['img'] = getThumbImg($v['video_url'],$config['mini_domain']);
                        }else{
                            $v['img'] = getThumbImg($v['img'],$config['mini_domain'],$size);
                        }
                    }
                }
                unset($v);$wData = array_column($wData,null,'id');
                foreach ($wid as $witem){
                    if(!empty($wData[$witem])){$w[] = $wData[$witem];}
                }
            }
        }
        View::assign('w',$w);
        return View::fetch();
    }

    public function index(){
        $status = Request::param('status',1);//默认审核通过
        $type = Request::param('type',1);//默认手机壁纸

        $where = [];
        $pageSize = 18;
        if(!empty($status)){$where[] = ['status','=',$status];}
        $data = \app\common\model\Wallpaper::where(['author_id'=>Session::get('wechatUserId'),'is_deleted'=>0,
            'type'=>$type,'source'=>2])
            ->where($where)->order(['is_recommend'=>'desc','weight'=>'desc','id'=>'desc'])->paginate($pageSize,false)
            ->toArray();

        if($data['data']){
            $config = \app\common\model\Config::getAllConfig();
            $thumbSize = \think\facade\Config::get('params.thumb_size');
            foreach ($data['data'] as &$v){
                if($v['type'] != 2){
                    $size = isset($thumbSize[$v['type']])?$thumbSize[$v['type']][0]:'';
                    $v['img'] = getThumbImg($v['img'],$config['mini_domain'],$size);
                }else{
                    $v['img'] = getThumbImg($v['img'],$config['mini_domain']);//视频封面图不做调整
                }
            }
            unset($v);
        }
        if(Request::isAjax()){
            wapAjaxReturn(0,'success',$data['data']);
        }

        View::assign('currentPage',$data['current_page']);
        View::assign('total',$data['last_page']);
        View::assign('list',$data['data']);
        View::assign('status',$status);
        View::assign('type',$type);
        View::assign('pageSize',$pageSize);

        //查询当前达人用户信息
        $userInfo = Expert::find(Session::get('wechatUserId'));
        if(!empty($userInfo['base_setting'])){$userInfo['base_setting'] = json_decode($userInfo['base_setting'],true);}
        else{$userInfo['base_setting'] = ['show'=>0,'type'=>0];}
        View::assign('user_info',$userInfo);

        $type_list2 = [];
        $type = \app\common\model\Wallpaper::where(['status'=>1,'is_deleted'=>0,'author_id'=>Session::get('wechatUserId')])
            ->field(['type'])->order(['type'=>'asc'])->group('type')->select()->toArray();
        if($type){
            $type_list = array_column($type,'type');
            foreach ($type_list as $v){
                $type_list2[] = [
                    'id'=>$v,'name'=>\app\common\model\Wallpaper::$_type[$v]
                ];
            }
        }
        View::assign('type_list2',$type_list2);
        return View::fetch();
    }

    public function createNew(){
        $userObj = new Expert();
        $userInfo = $userObj->getUserInfo(Session::get('wechatUserId'));
        if($userInfo == null){
            throw new Exception('你不是我们系统的用户哦');
        }
        View::assign('userInfo',$userInfo);

        $config = Config::getAllConfig();
        View::assign('day_upload_num',$config['day_upload_num']);
        View::assign('tags',\think\facade\Config::get('params.wallpaper_tags'));
        View::assign('ruleInfo',Instruction::find(3));
        return View::fetch();
    }

    public function createDeal(){
        $post = Request::param();
        if(empty($post['file_img'])){wapAjaxReturn(400,'请上传素材');}

        (new WallpaperService())->saveWallpaper($post);
    }

    public function detail(){

        $id = Request::param('id',0);
        $data = \app\common\model\Wallpaper::find($id);
        if($data == null){throw new Exception('神经病');}
        $tagList = [];
        if($data['tag_ids']){
            $wallpaper_tags=\think\facade\Config::get('params.wallpaper_tags');
            $data['tag_ids'] = array_filter(explode(",",$data['tag_ids']));
            foreach ($data['tag_ids'] as $k=>$v){
                foreach ($wallpaper_tags as $k2=>$v2){
                    if($v == $k2){$tagList[] = $v2;break;}
                }
            }
        }
        View::assign('tagList',$tagList);
        View::assign('data',$data);
        return View::fetch();
    }

    public function delWallpaper(){
        $id = Request::param('id',0);
        if(empty($id)){wapAjaxReturn(400);}

        $id = explode(",",$id);

        //查询并删除
        $data = \app\common\model\Wallpaper::where(['id'=>$id])
            ->field(['img','thumb_img','video_url','type'])->select()->toArray();
        if($data){
            //查询存储设置缓存，没有的话需要重新数据库并存储到缓存中
            $thumbSize = \think\facade\Config::get('params.thumb_size');
            $new = array();
            foreach ($data as $v){
                $new[] = $v['img'];$new[]=$v['video_url'];$new[]=$v['thumb_img'];
                if(!empty($thumbSize[$v['type']])){
                    foreach ($thumbSize[$v['type']] as $v2){
                        $fileNameStr = explode(".",$v['img']);
                        $imageExt = end($fileNameStr); unset($fileNameStr[count($fileNameStr)-1]);
                        $imgThumb = implode(".",$fileNameStr) . '@' . $v2 . '.' . $imageExt;
                        $new[] = $imgThumb;
                    }
                }
            }

            \app\common\services\WallpaperService::delFile($new);
        }

       $deal = \app\common\model\Wallpaper::update(['is_deleted'=>1],['id'=>$id,'author_id'=>Session::get('wechatUserId')]);

        $deal ? wapAjaxReturn(0):wapAjaxReturn(400);
    }

    //置顶素材
    public function topWallpaper(){
        $id = Request::param('id',0);
        if(empty($id)){wapAjaxReturn(400);}
        $status = Request::param('status',0);
        if(!in_array($status,[1,0])){$status = 0;}

        $id = explode(",",$id);

        $deal = \app\common\model\Wallpaper::update(['is_recommend'=>$status],['id'=>$id,'author_id'=>Session::get('wechatUserId')]);

        $deal ? wapAjaxReturn(0):wapAjaxReturn(400);
    }

    //上传素材
    public function uploadFile(){
        $type = Request::param('fileType',0);
        if(empty($type)){wapAjaxReturn(400,'请选择素材类型');}
        //查询存储设置缓存，没有的话需要重新数据库并存储到缓存中
        $config = Config::getAllConfig();
        if($config['save_way'] == 0){
            //本地存储
            //非富文本上传，本地存储不需要加域名前缀
            $config['is_editor'] = false;
            $res=   (new AliyunOssServices())->localStorageSave($config);
        }
        if($config['save_way'] == 1){//阿里云上传
            $res= (new AliyunOssServices())->uploadFile($config);
        }
        if($config['save_way'] == 2){//七牛云上传
            $res= (new AliyunOssServices())->uploadFileQiniu($config);
        }

        return $res;
    }

    //删除素材
    public function delFile(){
        $img = Request::param('img','');
        $video = Request::param('video','');
        $thumbImg = Request::param('thumb','');
        $type = Request::param('type',0);

        //查询存储设置缓存，没有的话需要重新数据库并存储到缓存中
        //判断是否有缩略图产生
        $delFile = [$img,$video,$thumbImg];
        $thumbSize = \think\facade\Config::get('params.thumb_size');
        if(!empty($thumbSize[$type])){
            foreach ($thumbSize[$type] as $v){
                $fileNameStr = explode(".",$img);
                $imageExt = end($fileNameStr); unset($fileNameStr[count($fileNameStr)-1]);
                $imgThumb = implode(".",$fileNameStr) . '@' . $v . '.' . $imageExt;
                $delFile[] = $imgThumb;
            }
        }

        \app\common\services\WallpaperService::delFile($delFile);


        wapAjaxReturn(0,'success');


    }

    //达人基础设置
    public function settingSave(){
        $show = Request::param('show',0);
        $type = Request::param('type',1);

        if(!in_array($show,array_keys(\app\common\model\Wallpaper::$_type))){wapAjaxReturn(400);}
        if(!in_array($type,[1,2])){wapAjaxReturn(400);}

        $expert = new Expert();
        $expert->allowField(true)->save([
            'base_setting'=> json_encode([
                'show'=>$show,'type'=>$type
            ])
        ],['user_id'=>Session::get('wechatUserId')]);
        wapAjaxReturn(0);
    }

    //素材编辑权重
    public function weightWallpaper(){
        $id = Request::param('id',0);
        if(empty($id)){wapAjaxReturn(400);}
        $weight = Request::param('weight',0);
        if(!intval($weight)){$weight=0;}
//        $selfName = Request::param('self_name','');
//        if($selfName){
//            if(mb_strlen($selfName) > 10 ){wapAjaxReturn(400,'名称不能超过10个字');}
//            //todo 增加敏感词校验
//        }


        $deal = \app\common\model\Wallpaper::update(['weight'=>$weight],['id'=>$id,'author_id'=>Session::get('wechatUserId')]);

        $deal ? wapAjaxReturn(0):wapAjaxReturn(400);
    }

    //设置封面入口
    public function allList(){
        $data = \app\common\model\Wallpaper::where(['author_id'=>Session::get('wechatUserId'),'is_deleted'=>0,
            'source'=>2,'status'=>1])
            ->order(['is_recommend'=>'desc','weight'=>'desc','id'=>'desc'])
            ->select()->toArray();

        View::assign('list',$data);
        View::assign('type',1);//默认显示手机壁纸
        return View::fetch();
    }

    //保存自定义封面
    public function coverSave(){
        $id = Request::param('id',0);
        if(empty($id)){wapAjaxReturn(400);}

        Expert::update(['self_cover'=>$id],['user_id'=>Session::get('wechatUserId')]);


        wapAjaxReturn(0);
    }

    public function utest(){
        return View::fetch();
    }
}
<?php


namespace app\index\controller;


use think\facade\Request;
use think\facade\View;

class News extends CommonBase
{
    public function __construct()
    {
        parent::__construct();

    }
    public function index(){
        $newsList = \app\common\model\News::where(['is_deleted'=>0])
            ->field(['id','title','created_at'])
            ->order(['created_at'=>'desc'])->paginate(10,false)->toArray();
        if(Request::isAjax()){
            wapAjaxReturn(0,'success',$newsList['data']);
        }
        View::assign('currentPage',$newsList['current_page']);
        View::assign('total',$newsList['last_page']);
        View::assign('list',$newsList['data']);
        return View::fetch();
    }

    public function details(){
        $id = Request::param('id',0);
        if(empty($id)|| !is_numeric($id)){return redirect('/');}
        $details = \app\common\model\News::where(['is_deleted'=>0,'id'=>$id])
            ->find();

        if($details == null){return redirect('/');}


        View::assign('details',$details);
        return View::fetch();
    }
}
<?php


namespace app\index\controller;


use app\common\model\Config;
use app\common\model\Expert;
use app\services\SmsService;
use think\facade\Request;
use think\facade\Session;
use think\facade\View;

class Login extends CommonBase
{

    public function index(){
        $id = Request::param('id',0);
        View::assign('id',$id);
        return View::fetch();
    }

    public function userLoginPwd(){
        $id = Request::param('id',0);
        View::assign('id',$id);
        return View::fetch();
    }

    public function userRegister(){
        $id = Request::param('id',0);

        $user = null;
        if(!empty($id) && is_numeric($id)){
            $user = Expert::find($id);
        }
        $config = Config::getAllConfig();
        View::assign('user',$user);
        View::assign('id',$id);
        View::assign('must_code',intval($config['register_code']));
        return View::fetch();
    }

    public function dealLogin(){
        $type = Request::param('type',0);
        switch (intval($type)){
            case 1:
                //手机登陆
                $phone = Request::param('phone','');
                $code = Request::param('code','');
                if (empty($phone)){wapAjaxReturn(400,'error');}
                if(!preg_match('/^1[3456789]{1}\d{9}$/',$phone)){wapAjaxReturn(400,'errors');}
                if(!(new SmsService())->check($code,'loginCode')){wapAjaxReturn(400,'验证码错误');}

                //查询当前手机号码是否存在
                $expert = new Expert();
                $data = $expert->where(['user_phone'=>$phone])->find();
                if($data == null){wapAjaxReturn(400,'当前手机号码未注册');}
                Session::set('wechatUserId',$data->user_id);
                wapAjaxReturn(0,'success');
                break;
            case 2:
                //密码登陆
                $phone = Request::param('phone','');
                $pwd = Request::param('pwd','');
                if (empty($phone)){wapAjaxReturn(400,'error');}
                if (empty($pwd)){wapAjaxReturn(400,'error');}
                if(!preg_match('/^1[3456789]{1}\d{9}$/',$phone)){wapAjaxReturn(400,'errors');}

                //查询当前手机号码是否存在
                $expert = new Expert();
                $data = $expert->where(['user_phone'=>$phone])->find();
                if($data == null){wapAjaxReturn(400,'当前手机号码未注册');}
                if($expert->doExpertMd5($pwd,$data->pwd_salt) != $data->password){
                    wapAjaxReturn(400,'密码错误');
                }
                Session::set('wechatUserId',$data->user_id);
                wapAjaxReturn(0,'success');
                break;
            case 3:
                //注册账号
                $phone = Request::param('phone','');
                $code = Request::param('code','');
                $pwd = Request::param('pwd','');
                $parentUserCode = Request::param('user_code','');//邀请人的邀请码
                if (empty($phone)){wapAjaxReturn(400,'error');}
                if (empty($pwd)){wapAjaxReturn(400,'error');}
                if(!preg_match('/^1[3456789]{1}\d{9}$/',$phone)){wapAjaxReturn(400,'errors');}
                if(!(new SmsService())->check($code,'registerCode')){wapAjaxReturn(400,'验证码错误');}

                //根据配置判断是否要强制填写邀请码
                $config = Config::getAllConfig();
                if($config['register_code'] == 1 && empty($parentUserCode)){wapAjaxReturn(400,'请输入邀请码');}

                //查询当前手机号码是否存在
                $expert = new Expert();
                $data = $expert->where(['user_phone'=>$phone])->find();
                if($data != null){wapAjaxReturn(400,'当前手机号码已被注册');}

                $fir_distribution = 0;
                if(!empty($parentUserCode)){
                    //有邀请码，查询邀请码对应的达人是否存在
                    $parentInfo = Expert::where(['user_code'=>$parentUserCode])->find();
                    if($config['register_code'] == 1 && $parentInfo == null){wapAjaxReturn(400,'邀请码错误，请联系平台客服');}
                    if($parentInfo!=null){$fir_distribution = $parentInfo->user_id;}
                }

                $userCode = create_invite_code();
                $pwdSalt = GetRandStr(4);
                $data = $expert->allowField(true)->save([
                    'user_phone'=>$phone,
                    'nickname'=>$phone,
                    'user_code'=>$userCode,
                    'user_nickname'=>$userCode,
                    'user_headimg'=>'/static/images/2.png',
                    'avatar_url'=>'/static/images/2.png',
                    'password'=>$expert->doExpertMd5($pwd,$pwdSalt),
                    'pwd_salt'=>$pwdSalt,
                    'fir_distribution'=>$fir_distribution,
                ]);
                $userid = $expert->user_id;
                if($userid){
                    Session::set('wechatUserId',$userid);
                    wapAjaxReturn(0,'success');
                }else{wapAjaxReturn(400,'系统异常');}
                break;
        }
        wapAjaxReturn(400,'要干嘛');
    }

    public function logout(){
        Session::destroy();
        wapAjaxReturn(0,'success',Session::get('wechatUserId'));
    }
}
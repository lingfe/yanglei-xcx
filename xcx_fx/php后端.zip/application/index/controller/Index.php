<?php
namespace app\index\controller;

use app\common\model\Config;
use app\common\model\Expert;
use app\common\model\UserDayDistribution;
use app\common\model\UserDistribution;
use think\Exception;
use think\facade\Request;
use think\facade\Session;
use think\facade\View;
use think\Model;

class Index extends CommonBase
{
    public function __construct()
    {
        parent::__construct();

    }


    /**
     * 首页
     * @return string
     * @throws Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function index()
    {
        $userObj = new Expert();
        $userInfo = $this->userInfo;
        if($userInfo != null && !empty($userInfo['fir_distribution'])){
            $userInfo['parent_info'] = $userObj->getUserInfo($userInfo['fir_distribution']);
        }

        View::assign('user_info',$userInfo);

        $wechatImg = (new Config())->getInfoByKey('wechat_img');
        $configAll = \app\common\model\Config::getAllConfig();
//        echo $configAll['mini_domain'];exit;
        View::assign('wechat_img',getThumbImg($wechatImg['config_value'],$configAll['mini_domain']));

        $day = date('Y-m-d',time());
        $yesterday = date('Y-m-d',strtotime("-1 day"));
        $userDistribution = new UserDistribution();

        //获取今天、昨天收益累计
        $dayPrice =  $userDistribution->getPriceByDay($day,Session::get('wechatUserId'));
        $yesterdayPrice =  $userDistribution->getPriceByDay($yesterday,Session::get('wechatUserId'));
//        print_r($yesterdayPrice);exit;
        View::assign('dayPrice',$dayPrice);
        View::assign('yesterdayPrice',$yesterdayPrice);
        $daySelfPrice =  $userDistribution->getPriceByDay($day,Session::get('wechatUserId'),true);
        View::assign('daySelfPrice',$daySelfPrice);

        //判断是否开放提现申请
        $config = (new Config())->getInfoByKey('apply_status');
        View::assign('applyStatus',$config);

        View::assign('freeze_money',UserDayDistribution::where(['user_id'=>Session::get('wechatUserId'),'price_deal_staus'=>[1,3]])->sum('true_price'));
        return View::fetch();
    }

    /**
     * 我的团队
     * @return string
     */
    public function team(){
        $userObj = new Expert();
        $userDistribution = new UserDistribution();
        $data = $userObj->getTeamList(Session::get('wechatUserId'));
        if($data['data']){
            $nextTeam = $userObj->getNextTeam(array_column($data['data'],'user_id'));
            if($nextTeam){
                $nextTeam = array_column($nextTeam,null,'fir_distribution');
            }

            $teamMoney = $userDistribution->getTeamMoney(Session::get('wechatUserId'));
            if($teamMoney){
                $teamMoney = array_column($teamMoney,null,'next_user_id');
            }
            foreach ($data['data'] as $k=>$v){
                $data['data'][$k]['nickname'] = $v['user_nickname'];
                $data['data'][$k]['person'] = !empty($nextTeam[$v['user_id']])?$nextTeam[$v['user_id']]['num']:0;
                $data['data'][$k]['money'] = !empty($teamMoney[$v['user_id']])?$teamMoney[$v['user_id']]['price']:0;
            }
        }

        //获取总数据内容
        $statisticsData = $userObj->getStatistics(Session::get('wechatUserId'));
        $money = $userDistribution->getUserTeamMoney(Session::get('wechatUserId'));



        if(Request::isAjax()){
            wapAjaxReturn(0,'success',$data['data']);
        }
        View::assign('total_person',$statisticsData['total_person']);
        View::assign('total_money',$statisticsData['total_money']);
        View::assign('currentPage',$data['current_page']);
        View::assign('total',$data['last_page']);
        View::assign('list',$data['data']);
        View::assign('money',$money);
        return View::fetch();
    }

    //创建团队入口
    public function inviteTeam(){

        $config = Config::where(['config_key'=>array('money_fir','money_sec','money_thr')])
            ->select()->toArray();
        if($config){
            $config = array_column($config,null,'config_key');
        }

        View::assign('config',$config);
        View::assign('wechatUserId',Session::get('wechatUserId'));
        return View::fetch();
    }

    //绑定分销关系
    public function joinTeam(){
        $userId = Session::get('wechatUserId');
        $id = Request::param('id',0);
        if(is_numeric($id) && $userId != $id){ //自己扫码进入不做处理
            $userObj = new Expert();
            //判断当前用户是否已经有上级，有的话就不做关系绑定
            $localUserInfo = $userObj->getUserInfo($userId);
            if($localUserInfo != null && empty($localUserInfo['fir_distribution'])){
                $parentInfo = $userObj->getUserInfo($id);
                if($parentInfo != null){
                    //给当前登录的用户绑定他的用户关系
                    $userObj->allowField(true)
                        ->save(['fir_distribution'=>$id
                        ],
                            ['user_id'=>$userId]);
                }
            }
        }
        return redirect('/');
    }

    /**
     * 达人排行
     */
    public function agent(){
        $userObj = new Expert();
        $data = $userObj->getPaginateList(array('nickname','user_nickname','yesterday_money as total_money','user_headimg as avatar_url'));
        //获取总数据内容
        $statisticsData = $userObj->getStatistics();

        if(Request::isAjax()){
            wapAjaxReturn(0,'success',$data['data']);
        }
        View::assign('total_person',$statisticsData['total_person']);
        View::assign('total_money',$statisticsData['total_money']);
        View::assign('currentPage',$data['current_page']);
        View::assign('total',$data['last_page']);
        View::assign('list',$data['data']);

        $config = (new Config())->getInfoByKey('ranking_show');
        View::assign('rankShow',$config['config_value']);

        return View::fetch();
    }


    /**
     * 完善信息入口
     */
    public function improveInit(){
        View::assign('userInfo',$this->userInfo);
        return View::fetch();
    }

    /**
     * 完善信息操作
     */
    public function improve(){

        $post = Request::post();
        if(empty($post['user_nickname'])){wapAjaxReturn(400,'请填写达人昵称');}
        if(empty($post['user_code'])){wapAjaxReturn(400,'请填写达人口令');}
        if(empty($post['wechat_num'])){wapAjaxReturn(400,'请填写微信号');}
        if(strlen($post['wechat_num']) > 50){wapAjaxReturn(400,'请填写正确的微信号');}
        if(empty($post['user_headimg'])){wapAjaxReturn(400,'请上传达人头像');}
//        if(empty($post['password'])){wapAjaxReturn(400,'密码不能为空');}

//        if(empty($post['phone'])){wapAjaxReturn(400,'请填写手机号码');}
//        if(strlen($post['phone']) != 11){wapAjaxReturn(400,'请填写正确的手机号码');}
//        if(!preg_match('/^1\d{10}$/',$post['phone'])){
//            wapAjaxReturn(400,'请填写正确的手机号码');
//        }

        if(!preg_match('/^[a-z0-9A-Z_]+$/',$post['user_code'])){wapAjaxReturn(400,'达人口令只能是数字、字母、下划线组成');}

        $expert = new Expert();
        $exist = $expert->where(['user_code'=>$post['user_code']])
            ->where('user_id','<>',Session::get('wechatUserId'))->count();
        if($exist){wapAjaxReturn(400,'达人口令已经存在，请重新替换');}
        $userInfo = $expert->find(Session::get('wechatUserId'));
        if($userInfo){
            $userInfo->user_nickname = urlencode($post['user_nickname']);
            $userInfo->user_code = $post['user_code'];
            $userInfo->user_headimg = $post['user_headimg'];
            $userInfo->avatar_url = $post['user_headimg'];
            $userInfo->wechat_num = $post['wechat_num'];
            if(!empty($post['phone'])){
                $userInfo->user_phone = $post['phone'];
            }
            if($userInfo->is_reviewed != 1){
                $userInfo->is_reviewed = 0;//未通过的情况下修改都会变成待审核
            }
            if(!empty($post['password'])){
                $pwdSalt = GetRandStr(4);
                $userInfo->password = $expert->doExpertMd5($post['password'],$pwdSalt);
                $userInfo->pwd_salt = $pwdSalt;
            }
            $userInfo->save();
        }
        wapAjaxReturn(0,'success');
    }

}

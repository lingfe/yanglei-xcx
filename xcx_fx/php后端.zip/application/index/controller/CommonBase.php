<?php


namespace app\index\controller;


use app\common\model\Config;
use app\common\model\Expert;
use Qiniu\Auth;
use Qiniu\Storage\BucketManager;
use think\Exception;
use think\facade\Request;
use think\facade\Session;
use think\facade\View;

class CommonBase
{
    public $userInfo;
    public function __construct()
    {
        if(!Request::isAjax()){
            $m = Request::controller();
            if($m != 'Login'){
                $userObj = new Expert();
                $userInfo = $userObj->getUserInfo(Session::get('wechatUserId'));
                if( $userInfo == null){
                    throw new Exception('你不是我们系统的用户哦');
                }
                $this->userInfo = $userInfo;
            }

            //获取推广平台
            $platform = Config::getAllConfig();
            View::assign('platform_name',$platform['platform_name']);
            View::assign('php_server',$platform['mini_domain']);
            View::assign('config_list',$platform);
            View::assign('expertInfoBase',$this->userInfo);
            View::assign('isMobile',isMobile());
        }
    }
}
<?php


namespace app\index\controller;


use app\common\model\Expert;
use http\Exception;
use think\facade\Config;
use think\facade\Request;
use think\facade\Session;
use think\facade\Url;

class Wechat
{
    public function callback(){
        try{
            $callbackUrl = Request::get('callbackUrl');
            $code = Request::get('code');
            $callbackUrl = urldecode($callbackUrl);
            if(Session::get('wechatUserId')){
                header('Location:'.$callbackUrl);
                exit;
            }
            if(empty($callbackUrl)){echo '系统维护中~';exit;}
            if(empty($code)){echo '系统维护中...';exit;}

            $allConfig = \app\common\model\Config::getAllConfig();
            $wechatInfo['appid'] = $allConfig['g_appid'];
            $wechatInfo['appsecret'] = $allConfig['g_appsecret'];

            //通过code获取临时token跟用户的openid
            $url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$wechatInfo['appid']."&secret=".$wechatInfo['appsecret']."&code=".$code."&grant_type=authorization_code";
            $codeBackRes = json_decode(curl_file_get_contents($url),true);
            if(!empty($codeBackRes['access_token'])){
                //获取微信用户信息，存储数据库
                $infoUrl='https://api.weixin.qq.com/sns/userinfo?access_token='.$codeBackRes['access_token'].'&openid='.$codeBackRes['openid'].'&lang=zh_CN';
                $wxInfo = json_decode(curl_file_get_contents($infoUrl),true);
                if(!empty($wxInfo['openid'])){

                    //存储到数据库，并写入缓存中
                    $wxUser = Expert::where(['openid'=>$wxInfo['openid']])->find();
                    if(!$wxUser){
                        $wxUser = new Expert();
                        $wxUser->user_code = create_invite_code();
                        $wxUser->user_nickname = urlencode($wxInfo['nickname']);
                        $wxUser->user_headimg = $wxInfo['headimgurl'];
                    }
                    $wxUser->openid = $wxInfo['openid'];
                    $wxUser->nickname = urlencode($wxInfo['nickname']);
                    $wxUser->avatar_url = $wxInfo['headimgurl'];
                    $wxUser->sex = $wxInfo['sex'];
                    $wxUser->country = $wxInfo['country'];
                    $wxUser->province = $wxInfo['province'];
                    $wxUser->city = $wxInfo['city'];



                    $res  = $wxUser->save();
                    if($res){
                        Session::set('wechatUserId',$wxUser->user_id);
                        Session::set('wechatOpenid',$wxInfo['openid']);
                        header('Location:'.$callbackUrl);
                        exit;
                    }else{
                        echo '系统已经奔溃';exit;
                    }

                }else{
                    echo '系统已经奔溃啦';exit;
                }
            }
            echo '系统维护中!';exit;
        }catch (Exception $e){
//            print_r($e->getMessage());
            echo '系统维护中';
        }
    }



    public function callbackNew(){
        try{
            $uid = Request::get('uid');
            $code = Request::get('code');

            if(empty($uid)){return redirect('/');}
            if(empty($code)){return redirect('/');}


            $allConfig = \app\common\model\Config::getAllConfig();
            $wechatInfo['appid'] = $allConfig['g_appid'];
            $wechatInfo['appsecret'] = $allConfig['g_appsecret'];

            //通过code获取临时token跟用户的openid
            $url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$wechatInfo['appid']."&secret=".$wechatInfo['appsecret']."&code=".$code."&grant_type=authorization_code";
            $codeBackRes = json_decode(curl_file_get_contents($url),true);
            if(!empty($codeBackRes['access_token'])){
                //获取微信用户信息，存储数据库
                $infoUrl='https://api.weixin.qq.com/sns/userinfo?access_token='.$codeBackRes['access_token'].'&openid='.$codeBackRes['openid'].'&lang=zh_CN';
                $wxInfo = json_decode(curl_file_get_contents($infoUrl),true);
                if(!empty($wxInfo['openid'])){

                    //存储到数据库，并写入缓存中
                    $wxUser = Expert::where(['user_id'=>$uid])->find();
                    if(!$wxUser){
                        return redirect('/');
                    }
                    $wxUser->openid = $wxInfo['openid'];
//                    $wxUser->nickname = urlencode($wxInfo['nickname']);
//                    $wxUser->avatar_url = $wxInfo['headimgurl'];
                    $wxUser->sex = $wxInfo['sex'];
                    $wxUser->country = $wxInfo['country'];
                    $wxUser->province = $wxInfo['province'];
                    $wxUser->city = $wxInfo['city'];
                    $res  = $wxUser->save();
                    if($res){
                        return redirect('/user');
                    }else{
                        return redirect('/');
                    }

                }else{
                    return redirect('/');
                }
            }
            return redirect('/');

        }catch (Exception $e){
            return redirect('/');
        }
    }


    public function aouthDeal(){
        $uid = Request::param('uid',0);

        //微信授权处理逻辑
        $allConfig = \app\common\model\Config::getAllConfig();
        $wechatInfo['appid'] = $allConfig['g_appid'];
        $wechatInfo['appsecret'] = $allConfig['g_appsecret'];
        //跳转微信授权接口
        //-------生成唯一随机串防CSRF攻击
        $state  = md5(uniqid(rand(), TRUE));
        $callbackUrl = urlencode(Url::build('wecaht/callbackNew',"",'',true)."?uid={$uid}");
        $wxurl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=".$wechatInfo['appid']."&redirect_uri=".$callbackUrl."&response_type=code&scope=snsapi_userinfo&state=".$state."#wechat_redirect";
        header('Location:'.$wxurl);
        exit;
    }
}
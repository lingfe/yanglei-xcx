<?php


namespace app\index\controller;


use app\common\model\Config;
use app\common\model\DayPrice;
use app\common\model\Expert;
use app\common\model\News;
use app\common\model\Questions;
use app\common\model\UserDayDistribution;
use app\common\model\UserDistribution;
use think\Exception;
use think\facade\Request;
use think\facade\Session;
use think\facade\View;
use think\Model;

class NewIndex extends CommonBase
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index(){

        //获取最新一条公告
        View::assign('news',\app\common\model\News::where(['is_deleted'=>0])->order(['id'=>'desc'])->find());
        View::assign('index_config',Config::where(['config_key'=>['index_poster','index_play']])->column('config_value','config_key'));
        View::assign('index_config',Config::where(['config_key'=>['index_poster','index_play']])->column('config_value','config_key'));
        View::assign('sucai_data',\app\common\model\Wallpaper::sucaiData(Session::get('wechatUserId')));
        $config = (new Config())->getInfoByKey('ranking_show');
        View::assign('rankShow',$config['config_value']);
        return View::fetch();
    }

    //新版收益明细页面
    public function money(){
        $time = Request::param('time','');
        $type = Request::param('type',1);
        $platform = Request::param('platform','dy');
        if(!in_array($type,[1,2])){throw new Exception('error');}

        if(!$time){$time = date('Y-m-d');}

        if($type == 1){
            //查看自推明细
            $list = UserDistribution
                ::where(['user_id'=>Session::get('wechatUserId'),'type'=>1,'platform'=>$platform])
                ->whereBetweenTime('created_at',$time)
                ->field(['count(wallpaper_id) as download_count','price_deal_staus','sum(predict_price) as predict_price','sum(true_price) as true_price',"wallpaper_id"])
                ->group("wallpaper_id")
                ->order(['created_at'=>'desc'])->paginate(10,false)->toArray();

            if($list['data']){
                $wallpaperInfo = \app\common\model\Wallpaper::where(['id'=>array_column($list['data'],'wallpaper_id')])
                    ->field(['id','img','name','type'])->select()->toArray();
                $wallpaperInfo = array_column($wallpaperInfo,null,'id');
                $config = \app\common\model\Config::getAllConfig();
                $thumbSize = \think\facade\Config::get('params.thumb_size');

                $wallpaperType = \app\common\model\Wallpaper::$_type;

                //通过查询当前选择的日期里的真实佣金结算来判断是否入账
                $trueList = UserDayDistribution::where(['platform'=>$platform])->whereBetweenTime('created_at',$time)->field(['from_unixtime(created_at,"%Y%m%d") as ctime','true_price','price_deal_staus'])
                    ->find();
                foreach ($list['data'] as &$v){
                    $v['true_price'] = $v['price_deal_staus'] == 1?'收益'.$v['true_price']:'预估'.$v['predict_price'];
                    $v['status'] = '待入账';
                    $v['w_name'] = '';
                    $v['img'] = '';
                    $v['type'] = '未知';
                    if (!empty($wallpaperInfo[$v['wallpaper_id']])){
                        $v['w_name'] = $wallpaperInfo[$v['wallpaper_id']]['name'];
                        if($wallpaperInfo[$v['wallpaper_id']]['type'] != 2){
                            $size = isset($thumbSize[$wallpaperInfo[$v['wallpaper_id']]['type']])?$thumbSize[$wallpaperInfo[$v['wallpaper_id']]['type']][0]:'';
                            $v['img'] = getThumbImg($wallpaperInfo[$v['wallpaper_id']]['img'],$config['mini_domain'],$size);
                        }else{
                            $v['img'] = getThumbImg($wallpaperInfo[$v['wallpaper_id']]['img'],$config['mini_domain']);//视频封面图不做调整
                        }
                        $v['type'] = $wallpaperType[$wallpaperInfo[$v['wallpaper_id']]['type']];
                    }

                    if($trueList && $trueList['price_deal_staus'] == 2){
                        $v['status'] = '已入账';
                    }

                }
                unset($v);
            }
        }else{
            //查看团队收益
            $list = UserDistribution
                ::where(['user_id'=>Session::get('wechatUserId'),'type'=>2])
                ->whereBetweenTime('created_at',$time)
                ->field(['count(origin_user_id) as download_count','price_deal_staus','sum(predict_price) as predict_price','sum(true_price) as true_price',"origin_user_id"])
                ->group("origin_user_id")
                ->order(['created_at'=>'desc'])->paginate(10,false)->toArray();
            if($list['data']){
                $userInfo = Expert::where(['user_id'=>array_column($list['data'],'origin_user_id')])
                    ->field(['avatar_url','user_nickname as nickname','user_id'])->select()->toArray();
                $userInfo = array_column($userInfo,null,'user_id');
                foreach ($list['data'] as &$v){

                    if (empty($userInfo[$v['origin_user_id']])){unset($v);continue;}
                    $v['true_price'] = $v['price_deal_staus'] == 1?$v['true_price']:$v['predict_price'];
                    $v['avatar_url'] = $userInfo[$v['origin_user_id']]['avatar_url'];
                    $v['nickname'] = urldecode($userInfo[$v['origin_user_id']]['nickname']);
                }
                unset($v);
            }
        }


        if(Request::isAjax()){
            wapAjaxReturn(0,'success',$list['data']);
        }
        View::assign('currentPage',$list['current_page']);
        View::assign('total',$list['last_page']);
        View::assign('list',$list['data']);
        View::assign('time',$time);
        View::assign('type',$type);
        View::assign('platform',$platform);

        //获取今天、昨天收益累计
        $userDistribution = new UserDistribution();
        $day = date('Y-m-d',time());
        $yesterday = date('Y-m-d',strtotime("-1 day"));
        $dayPrice =  $userDistribution->getPriceByDay($day,Session::get('wechatUserId'));
        $daySelfPrice =  $userDistribution->getPriceByDay($day,Session::get('wechatUserId'),true);
        $yesterdayPrice =  $userDistribution->getPriceByDay($yesterday,Session::get('wechatUserId'));
        $yesterdaySelfPrice =  $userDistribution->getPriceByDay($yesterday,Session::get('wechatUserId'),true);
        $localMonth = $userDistribution->getPriceByMonth(Session::get('wechatUserId'));
        $lastMonth = $userDistribution->getPriceByMonth(Session::get('wechatUserId'),date('m',strtotime('-1 month')));
        View::assign('dayPrice',$dayPrice);
        View::assign('yesterdayPrice',$yesterdayPrice);
        View::assign('localMonth',$localMonth);
        View::assign('lastMonth',$lastMonth);
        View::assign('daySelfPrice',$daySelfPrice);
        View::assign('yesterdaySelfPrice',$yesterdaySelfPrice);


        return View::fetch('money_v1_9');
    }

    //旧版收益明细页面
    public function money2(){
        $list = UserDistribution::where(['user_id'=>Session::get('wechatUserId')])
            ->field(['count(id) as download_count','price_deal_staus','sum(predict_price) as predict_price','sum(true_price) as true_price',"from_unixtime(created_at,'%Y%m%d') as created_at"])
            ->group("from_unixtime(created_at,'%Y%m%d')")
            ->order(['created_at'=>'desc'])->paginate(10,false)->toArray();
        if($list['data']){
            //查询当前数据中是否有在真实佣金列表中，增加一个真实佣金发放状态
            $sTime = min(array_column($list['data'],'created_at'));
            $eTime = max(array_column($list['data'],'created_at'));

            $trueList = UserDayDistribution::where(['user_id'=>Session::get('wechatUserId')])
                ->whereBetweenTime('created_at',$sTime,$eTime)->field(['from_unixtime(created_at,"%Y%m%d") as ctime','true_price','price_deal_staus'])
                ->select()->toArray();
            $trueList = array_column($trueList,null,'ctime');
            foreach ($list['data'] as &$v){
                $v['true_price'] = $v['price_deal_staus'] == 1?'实际得'.$v['true_price']:'预估得'.$v['predict_price'];

                //通过真实佣金列表来判断当天数据是已发放还是待发放
                $v['true_price_status'] = 0;//待发放
                if(isset($trueList[$v['created_at']])){
                    if($trueList[$v['created_at']]['price_deal_staus'] == 2){$v['true_price_status'] = 1;}//已发放
                }
                $v['created_at'] = date('Y-m-d',strtotime($v['created_at']));
            }
            unset($v);
        }
        if(Request::isAjax()){
            wapAjaxReturn(0,'success',$list['data']);
        }
        View::assign('currentPage',$list['current_page']);
        View::assign('total',$list['last_page']);
        View::assign('list',$list['data']);


        $userDistribution = new UserDistribution();
        $day = date('Y-m-d',time());
        $yesterday = date('Y-m-d',strtotime("-1 day"));


        //获取今天、昨天收益累计
        $dayPrice =  $userDistribution->getPriceByDay($day,Session::get('wechatUserId'));
        $daySelfPrice =  $userDistribution->getPriceByDay($day,Session::get('wechatUserId'),true);
        $yesterdayPrice =  $userDistribution->getPriceByDay($yesterday,Session::get('wechatUserId'));
        $yesterdaySelfPrice =  $userDistribution->getPriceByDay($yesterday,Session::get('wechatUserId'),true);
        $localMonth = $userDistribution->getPriceByMonth(Session::get('wechatUserId'));
        View::assign('dayPrice',$dayPrice);
        View::assign('yesterdayPrice',$yesterdayPrice);
        View::assign('localMonth',$localMonth);
        View::assign('daySelfPrice',$daySelfPrice);
        View::assign('yesterdaySelfPrice',$yesterdaySelfPrice);
        return View::fetch();
    }


    //新手教程
    public function newHand(){
        //获取推广平台
        $platform = Config::where(['config_key'=>'user_teach'])->column('config_value','config_key');
        View::assign('user_teach',$platform['user_teach']);

        //获取问题
        $data = Questions::order(['weight'=>'asc','created_at'=>'desc'])->select()->toArray();
        foreach ($data as &$v){
            $v['answer'] = str_replace("\r\n",'<br>',$v['answer']);
        }
        View::assign('data',$data);

        return View::fetch();
    }

    public function moneyDetail(){
        $time = Request::param('time','');
        $type = Request::param('type',1);
        $platform = Request::param('platform','dy');
        if(empty($time)||!in_array($type,[1,2])||empty($platform)
        ||!in_array($platform,['dy','wx','ks','qq'])){throw new Exception('error');}

        if($type == 1){
            //查看自推明细
            $list = UserDistribution
                ::where(['user_id'=>Session::get('wechatUserId'),'type'=>1,'platform'=>$platform])
                ->whereBetweenTime('created_at',$time)
                ->field(['count(wallpaper_id) as download_count','price_deal_staus','sum(predict_price) as predict_price','sum(true_price) as true_price',"wallpaper_id"])
                ->group("wallpaper_id")
                ->order(['download_count'=>'desc'])->paginate(20,false)->toArray();

            if($list['data']){
                $wallpaperInfo = \app\common\model\Wallpaper::where(['id'=>array_column($list['data'],'wallpaper_id')])
                    ->field(['id','img','name','type'])->select()->toArray();
                $wallpaperInfo = array_column($wallpaperInfo,null,'id');
                $config = \app\common\model\Config::getAllConfig();
                $thumbSize = \think\facade\Config::get('params.thumb_size');
                foreach ($list['data'] as &$v){
                    $v['true_price'] = $v['price_deal_staus'] == 1?'收益'.$v['true_price']:'预估'.$v['predict_price'];
                    $v['status'] = '待结算';
                    $v['w_name'] = '';
                    $v['img'] = '';
                    if (!empty($wallpaperInfo[$v['wallpaper_id']])){
                        $v['status'] = $v['price_deal_staus'] == 1?'已结算':'待结算';
                        $v['w_name'] = $wallpaperInfo[$v['wallpaper_id']]['name'];
                        if($wallpaperInfo[$v['wallpaper_id']]['type'] != 2){
                            $size = isset($thumbSize[$wallpaperInfo[$v['wallpaper_id']]['type']])?$thumbSize[$wallpaperInfo[$v['wallpaper_id']]['type']][0]:'';
                            $v['img'] = getThumbImg($wallpaperInfo[$v['wallpaper_id']]['img'],$config['mini_domain'],$size);
                        }else{
                            $v['img'] = getThumbImg($wallpaperInfo[$v['wallpaper_id']]['img'],$config['mini_domain']);//视频封面图不做调整
                        }
                    }

                }
                unset($v);
            }
        }else{
            //查看团队收益
            $list = UserDistribution
                ::where(['user_id'=>Session::get('wechatUserId'),'type'=>2,'platform'=>$platform])
                ->whereBetweenTime('created_at',$time)
                ->field(['count(origin_user_id) as download_count','price_deal_staus','sum(predict_price) as predict_price','sum(true_price) as true_price',"origin_user_id"])
                ->group("origin_user_id")
                ->order(['created_at'=>'desc'])->paginate(10,false)->toArray();
            if($list['data']){
                $userInfo = Expert::where(['user_id'=>array_column($list['data'],'origin_user_id')])
                    ->field(['avatar_url','user_nickname as nickname','user_id'])->select()->toArray();
                $userInfo = array_column($userInfo,null,'user_id');
                foreach ($list['data'] as &$v){

                    if (empty($userInfo[$v['origin_user_id']])){unset($v);continue;}
                    $v['true_price'] = $v['price_deal_staus'] == 1?$v['true_price']:$v['predict_price'];
                    $v['avatar_url'] = $userInfo[$v['origin_user_id']]['avatar_url'];
                    $v['nickname'] = urldecode($userInfo[$v['origin_user_id']]['nickname']);
                }
                unset($v);
            }
        }


        if(Request::isAjax()){
            wapAjaxReturn(0,'success',$list['data']);
        }
        View::assign('currentPage',$list['current_page']);
        View::assign('total',$list['last_page']);
        View::assign('list',$list['data']);
        View::assign('time',$time);
        View::assign('type',$type);
        View::assign('platform',$platform);




        return View::fetch();
    }

    //查看每日真实单价数据
    public function singlePrice(){
        $list = DayPrice::order(['day'=>'desc'])->paginate(14,false)->toArray();

        if($list){
            foreach ($list['data'] as &$v){
                $v['day'] = date('Y-m-d',$v['day']);
            }
        }

        if(Request::isAjax()){
            wapAjaxReturn(0,'success',$list['data']);
        }
        View::assign('currentPage',$list['current_page']);
        View::assign('total',$list['last_page']);
        View::assign('list',$list['data']);

        return View::fetch();
    }


}
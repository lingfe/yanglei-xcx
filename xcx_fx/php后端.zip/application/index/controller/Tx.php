<?php


namespace app\index\controller;


use app\common\model\Config;
use app\common\model\Expert;
use app\common\model\UserPrice;
use app\common\services\WechatPayService;
use think\Db;
use think\Exception;
use think\facade\Request;
use think\facade\Session;
use think\facade\View;
use think\Model;

class Tx extends CommonBase
{
    public function  __construct()
    {
        parent::__construct();
    }

    public function apply(){

        $userObj = new Expert();
        $userInfo = $userObj->getUserInfo(Session::get('wechatUserId'));
        if($userInfo == null){
            throw new Exception('你不是我们系统的用户哦');
        }
        $userInfo = $userInfo->toArray();
//        $userInfo['can_withdraw_money'] = number_format($userInfo['withdraw_money'],'2');
        $userInfo['can_withdraw_money'] = round_num($userInfo['withdraw_money']);
        View::assign('userInfo',$userInfo);
        $config = Config::getAllConfig();
        View::assign('remark',$config['money_log_date']);
        View::assign('pay_way',$config['pay_way']);
        View::assign('max_money',$config['max_money']);
        View::assign('min_money',$config['apply_money']);

        return View::fetch();
    }

    public function deal(){
        $params = Request::post();
        Db::startTrans();
        try{
            if(!isset($params['money'])||!isset($params['name'])){wapAjaxReturn(400,'参数错误');}
            if (!is_numeric($params['money'])){
                throw new Exception('提现金额错误');
            }
            if($params['money'] <=0){wapAjaxReturn(400,'提现金额不能小于0');}
            if(getPointLen($params['money']) > 2){
                throw new Exception('提现金额小数点最多2位');
            }

            if(strlen($params['name']) > 30){throw  new Exception('真实姓名长度超过限制');}

            //根据不同的提现方式判断
            $config = (new Config())->getInfoToColumn(['pay_way']);
            if($config['pay_way'] == 0){
                if(strlen($params['account']) > 60){throw  new Exception('申请提现账号长度超过限制');}

            }else{
                if($config['pay_way'] != 1){
                    if(empty($params['code_img'])){wapAjaxReturn(400,'请上传收款码');}
                }else{
                    if($params['money'] < 0.3){wapAjaxReturn(400,'没有达到最低提现金额要求');}
                }
            }

            //判断当前提现的金额是否满足可提现最小金额
            $configData = Config::where(['config_key'=>'apply_money'])->find();
            if($configData != null && is_numeric($configData->config_value) && $configData->config_value > 0){
                if($configData->config_value > $params['money']){
                    throw new Exception('提现金额需要大于'.$configData->config_value.'元才可以提现');
                }
            }


            //查出用户信息
            $userInfo = Expert::where(['user_id'=>Session::get('wechatUserId')])->find();
            if($userInfo == null){throw  new Exception('当前用户不存在');}
            if($params['money'] > $userInfo->withdraw_money){throw new Exception('申请提现金额超过可提现金额');}


            //存储数据到用户申请提现表中
            $apply['user_id'] = $userInfo->user_id;;
            $apply['price'] = $params['money'];
            $apply['ceated_at'] = time();
            $apply['apply_account'] = !empty($params['account'])?$params['account']:'';
            $apply['real_name'] = $params['name'];

            $apply['code_img'] = !empty($params['code_img'])?$params['code_img']:"";
            $apply['order_sn'] = (new WechatPayService())->build_order_no();
            $apply['pay_way'] = $config['pay_way'];

            $UserPrice = new UserPrice();
            $save2 = $UserPrice->allowField(true)->save($apply);
            if(!$save2){throw  new Exception('提现存储数据存储失败');}
            //用户表减去申请金额

            $userInfo->withdraw_money = $userInfo->withdraw_money - $params['money'];
            $userInfo->save();

            //更新新的收款码到用户信息中
            if($config['pay_way'] == 0){(new Expert())->save(['alipay_true_name'=>$params['name'],'alipay_account'=>$params['account']],['user_id'=>$userInfo->user_id]);}
            if($config['pay_way'] == 2){(new Expert())->save(['wechat_paycode'=>$params['code_img']],['user_id'=>$userInfo->user_id]);}
            if($config['pay_way'] == 3){(new Expert())->save(['ali_paycode'=>$params['code_img']],['user_id'=>$userInfo->user_id]);}


            Db::commit();
            wapAjaxReturn(0,'成功');
        }catch(Exception $exception){
            Db::rollback();
            wapAjaxReturn(400,$exception->getMessage());
        }
    }

    public function log(){
        $data = (new UserPrice())->getPaginateList(Session::get('wechatUserId'),['pay_way','price','ceated_at','is_get']);
        if($data['data']){
            foreach ($data['data'] as &$v){
                $v['type'] = UserPrice::$_type[$v['pay_way']];
                $v['is_get'] = $v['is_get'] == 0?'待提现':'已提现';
                $v['ceated_at'] = date('Y-m-d H:i:s',$v['ceated_at']);
            }
        }
        if(Request::isAjax()){
            wapAjaxReturn(0,'success',$data['data']);
        }

        View::assign('currentPage',$data['current_page']);
        View::assign('total',$data['last_page']);
        View::assign('list',$data['data']);
        return View::fetch();
    }

}
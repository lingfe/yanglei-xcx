<?php


namespace app\logic;


/**
 * e团k队开y发l
 */
use think\facade\Config;

class QqxcxLogic
{
    /**
     * @param $code
     * @return bool|string
     * 根据code获取用户openid
     */
    public function getCode2Session($code,$appid,$appsecret,$type){
        if($type == 'dy'){
            //获取抖音用户openid
            $url = 'https://developer.toutiao.com/api/apps/jscode2session?appid='.$appid.'&secret='.$appsecret.'&code='.$code;
            return curl_file_get_contents($url);
        }
        if($type == 'qq'){
            //获取qq用户
            $url = 'https://api.q.qq.com/sns/jscode2session?appid='.$appid.'&secret='.$appsecret.'&js_code='.$code.'&grant_type=authorization_code';
            return curl_file_get_contents($url);
        }
        if($type == 'wx'){
            //获取微信用户
            $url = 'https://api.weixin.qq.com/sns/jscode2session?appid='.$appid.'&secret='.$appsecret.'&js_code='.$code.'&grant_type=authorization_code';
            return curl_file_get_contents($url);
        }

        if($type == 'ks'){
            //获取快手小程序openid
            $postUrl = 'https://open.kuaishou.com/oauth2/mp/code2session';
            $postData = array(
                'app_id'=>$appid,
                'app_secret'=>$appsecret,
                'js_code'=>$code
            );
            $postData = http_build_query($postData);
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $postUrl);
            curl_setopt($curl, CURLOPT_USERAGENT,'Opera/9.80 (Windows NT 6.2; Win64; x64) Presto/2.12.388 Version/12.15');
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); // stop verifying certificate
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
            curl_setopt($curl, CURLOPT_POSTFIELDS, $postData);
            curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
            $r = curl_exec($curl);
            curl_close($curl);

            return $r;
        }


    }
}
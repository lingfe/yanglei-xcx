<?php


namespace app\logic;

use app\common\model\Config;

/**
 * Class ImgSecCheck
 * @package app\logic
 * kyle
 * 2022-03-21
 * this a class for miniprogram img sec check
 */
class ImgSecCheck
{
    //HTTP请求（支持HTTP/HTTPS，支持GET/POST）
    private function httpRequest($url, $data = null)
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);

        if (!empty($data)) {
            curl_setopt($curl, CURLOPT_POST, TRUE);
            curl_setopt($curl, CURLOPT_POSTFIELDS,$data);
        }
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }

    //QQ小程序图片敏感检测
    public function qqImgSecCheck($img) {
        $access_token = $this->getQQMiniToken();

        $imgArr = explode('.',$img);
        $imageExt = end($imgArr);

        $obj = new \CURLFile(realpath($img));
        $obj->setMimeType("image/{$imageExt}");
        $file['media'] = $obj;
        $url = "https://api.q.qq.com/api/json/security/ImgSecCheck?access_token=".$access_token;
        $info = $this->httpRequest($url,$file);
        return $info;
    }
    private function getQQMiniToken() {
        $config = Config::getAllConfig();
        $appid = $config['qq_appid'];
        $secret = $config['qq_appsecret'];
        $url = "https://api.q.qq.com/api/getToken?grant_type=client_credential&appid=" . $appid . "&secret=" . $secret;
        $jsonResult = file_get_contents($url);
        $resultArray = json_decode($jsonResult, true);
        $access_token = $resultArray["access_token"];
        return $access_token;
    }
}
<?php


namespace app\logic;


use app\common\model\Player;
use app\common\model\PlayerLog;
use app\common\model\TopicLog;
use app\common\model\User;
use think\Exception;

class UserLogic
{
    public function saveOpenid($openId,$projectId){
        $hasInfo = false; //是否有用户信息存储
        $error = false; //是否更新库正常
        //查询是否已经存在数据库，没有则新增
        $checkInfo = User::where(['openid'=>$openId,'platform'=>$projectId])->find();
        if(empty($checkInfo)){

            $user = new User;
            // 过滤post数组中的非数据表字段数据
            $user->allowField(true)->save(['openid'=>$openId,'platform'=>$projectId]);
            if(empty($user->user_id)){$error = true;}
            $userId = $user->user_id;
        }else{
            $userId = $checkInfo->user_id;
        }
        if(!empty($checkInfo['nickname'])){$hasInfo =true;}
        return ['hasInfo'=>$hasInfo,'error'=>$error,'userId'=>$userId];
    }



    /**
     * 存储用户信息,在授权的时候更新数据
     * @param $params
     * @return bool
     */
    public function saveUserInfo($params,$userInfoExist){
        $user = new User();
        $data['avatar_url'] = !empty($params['avatarUrl'])?$params['avatarUrl']:'';
        $data['nickname'] = !empty($params['nickName'])?urlencode($params['nickName']):'';
        if($userInfoExist){
            $save = $user->allowField(true)->save($data,['openid'=>$params['openid'],'platform'=>$params['platform']]);
        }else{
            $data['openid'] = $params['openid'];
            $data['platform'] = $params['platform'];
            $save = $user->allowField(true)->save($data);

        }
        return $save;
    }
}
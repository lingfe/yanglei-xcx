<?php


namespace app\services;

use app\common\model\Config;
use app\common\model\Expert;
use app\common\model\Wallpaper;
use think\Exception;
use think\facade\Session;

/**
 * 达人端数据处理
 * Class WallpaperService
 * @package app\services
 */
class WallpaperService
{
    //上传素材
    public function saveWallpaper($params){
        try{
            $config = Config::getAllConfig();
            $user = Expert::find(Session::get('wechatUserId'));

            //组装数据
            $insert = [];
            foreach ($params['file_img'] as $k=>$v){
                $insert[] = [
                    'self_name'=>$params['self_name'],
                    'name'=>'sc'.date('Ymd').rand(1000,9999).date('Hi'),
                    'img'=>$v,
                    'author_id'=>Session::get('wechatUserId'),
                    'type'=>$params['file_type'][$k],
                    'source'=>2,
                    'status'=>2,
                    'video_url'=>$params['file_video'][$k],
                    'thumb_img'=>$params['file_thumb'][$k],
//                    'tag_ids'=>','.$params['tag_ids'].',',
                    'expression_video_url'=> ($params['file_type'][$k] == 5)?$params['expression_video_url']:'',//原视频链接，只处理表情包
                ];
            }
            if($user['day_upload_num']+count($insert) > $config['day_upload_num']){
                wapAjaxReturn(400,'今日上传素材次数超额，请删除');
            }
            $i = (new Wallpaper())->allowField(true)->saveAll($insert);

            if($i){
                //给当前用户的上传数增加
            db('expert')->where(['user_id'=>Session::get('wechatUserId')])
                ->setInc('day_upload_num',count($insert));
            }

            $i ?wapAjaxReturn(0,'success'):wapAjaxReturn(400,'系统异常');

        }catch (Exception $e){
            wapAjaxReturn(400,$e->getMessage());
        }
    }
}
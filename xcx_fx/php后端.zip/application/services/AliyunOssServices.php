<?php


namespace app\services;


use FFMpeg\Coordinate\TimeCode;
use FFMpeg\FFMpeg;
use OSS\Core\OssException;
use OSS\Core\OssUtil;
use OSS\OssClient;
use Qiniu\Auth;
use Qiniu\Storage\UploadManager;
use think\Exception;
use think\facade\Config;
use think\facade\Env;
use think\facade\Request;
use think\Image;

class AliyunOssServices
{
    //文件路径
    public $fileDirect = '../public/static/uploads/default/';

    //缩略图尺寸
//    protected $_thumb_size = [];
    protected $_thumb_size = [];

    //文件后缀
    public $fileExt = [
        'images'=>'jpg,png,gif,jpeg',
        'video' =>'avi,wmv,mp4,mov',
    ];

    public function __construct(){
        $this->_thumb_size = Config::get('params.thumb_size');
        if (!is_dir('../public/static/uploads/' )){//是否已有文件夹
            mkdir('../public/static/uploads/' );//没有则新建文件夹
        }
        if (!is_dir($this->fileDirect )){//是否已有文件夹
            mkdir($this->fileDirect );//没有则新建文件夹
        }

        set_time_limit(0);
        ini_set('memory_limit','1024M');
    }

    /////////////////////////////////////////////////////////////////////
    //上传阿里云
    public function uploadFile($config)
    {
        $fileExt = Request::param('fileExt','images');//默认传图片
        $file = request()->file('file');  //获取到上传的文件
        $type = Request::param('fileType',0);//上传素材类型，默认0-不处理缩略图，其他的有缩略图数组才数据elyk
        $originName = $file->getInfo('name');
        $ext = pathinfo($file->getInfo('name'), PATHINFO_EXTENSION);
        // 尝试执行
        try {
            if(!isset($this->fileExt[$fileExt])){throw new Exception('后缀错误啦');}
            if(!in_array(strtolower($ext),explode(",",$this->fileExt[$fileExt]))){throw new Exception($ext.'后缀错误');}
            $fileName = 'wallpaper/img/'.date("Y/m/d") .'/'. uniqid() . '.' . $ext;
            //分片上传
            $result = $this->uploadVideoToOss($config['aliyun_keyid'],
                $config['aliyun_keysecret'], $config['aliyun_endpoint'],$config['aliyun_buckey'],
                $fileName, $file->getInfo()['tmp_name']);

            if ($result['info']['url']) {
                //分片上传会携带参数，需要去掉
                $url = explode('?',$result['info']['url']);
                $result['info']['url'] = $url[0];

                if(!empty($config['aliyun_new_domain'])){
                    $path = str_replace($config['aliyun_old_domain'],$config['aliyun_new_domain'],$result['info']['url']);
                }else{
                    $path = str_replace('http','https',$result['info']['url']);
                }

                //生成缩略图
                if(strtolower($ext) != 'gif'){
                    if(isset($this->_thumb_size[$type])){
                        $this->ossCreateThumbImg($file,$fileName,$config,$this->_thumb_size[$type]);
                    }
                }

                //todo 处理视频封面图
                $videUrl = $path;
                if($type == 2){
                    //ffmpeg只能处理本地文件，所以需要将该文件临时上传到本地后，进行切分然后再删除本地文件
                    $imgUrl= $this->fileDirect .  date("Y/m/d");
                    if(!empty($file)){
                        $originName = $file->getInfo('name');
                        $info = $file->validate(['size'=>10*1024*1024,'ext'=>$this->fileExt[$fileExt]])->rule('uniqid')->move($imgUrl);
                        $error = $file->getError();

                        //验证文件后缀后大小
                        if(!empty($error)){
                            throw new Exception($file->getError());
                        }
                        if($info){
                            // 成功上传后 获取上传信息
                            //获取图片的名字
                            $imgName = $info->getFilename();
                            //获取图片的路径
                            $photo=$imgUrl . "/" . $imgName;

                        }else{
                            // 上传失败获取错误信息
                            throw new Exception($file->getError());
                        }
                    }else{
                        $photo = '';
                    }
                    if($photo == ''){throw new Exception('local img fail');}
                    $videoImg = $this->GetCoveImg($config['save_way'],$photo,$config);
                    $path = $videoImg;

                    //删除旧数据
                    $fileDel = str_replace("../public",'',$photo);
                    @unlink($_SERVER['DOCUMENT_ROOT'] . $fileDel);
                }
                if(strtolower($ext) == 'gif'){
                    //ffmpeg只能处理本地文件，所以需要将该文件临时上传到本地后，进行切分然后再删除本地文件
                    $imgUrl= $this->fileDirect .  date("Y/m/d");
                    if(!empty($file)){
                        $originName = $file->getInfo('name');
                        $info = $file->validate(['size'=>10*1024*1024,'ext'=>$this->fileExt[$fileExt]])->rule('uniqid')->move($imgUrl);
                        $error = $file->getError();

                        //验证文件后缀后大小
                        if(!empty($error)){
                            throw new Exception($file->getError());
                        }
                        if($info){
                            // 成功上传后 获取上传信息
                            //获取图片的名字
                            $imgName = $info->getFilename();
                            //获取图片的路径
                            $photo=$imgUrl . "/" . $imgName;

                        }else{
                            // 上传失败获取错误信息
                            throw new Exception($file->getError());
                        }
                    }else{
                        $photo = '';
                    }
                    if($photo == ''){throw new Exception('local img fail');}
                    $videoImg = $this->GetCoveImg($config['save_way'],$photo,$config);
                    $videUrl = $videoImg;

                    //删除旧数据
                    $fileDel = str_replace("../public",'',$photo);
                    @unlink($_SERVER['DOCUMENT_ROOT'] . $fileDel);
                }

                //todo 生成壁纸、背景图的剪切图
                if(in_array($type,[1,2,3])){
                    $thumb_img = $this->getSpecialThumbImg($config['save_way'],$path,$config);
                }else{
                    $thumb_img = $path;
                }

                return json(array('error'=>0,'code'=>1,'msg'=>'上传成功','path'=>$path,'photo'=>$path,'url'=>$path,'origin_name'=>$originName,'state'=>'SUCCESS','title'=>$path,'video_url'=>$videUrl,'thumb_img'=>$thumb_img));
            }else{
                return json(array('error'=>404,'code'=>400,'msg'=>'上传失败','photo'=>'','url'=>'','state'=>'ERROR','title'=>'','video_url'=>''));
            }
        } catch (Exception $e) {
            return json(array('error'=>404,'code'=>400,'msg'=>$e->getMessage(),'photo'=>'','url'=>'','state'=>'ERROR','title'=>'','e'=>$e->getMessage()));
        }
    }
    //阿里云分片上传
    protected function uploadVideoToOss($accessKeyId, $accessKeySecret, $endpoint, $bucket, $object, $filePath)
    {
        try {
            $ossClient = new OssClient($accessKeyId, $accessKeySecret, $endpoint);
            //返回uploadId。uploadId是分片上传事件的唯一标识，您可以根据uploadId发起相关的操作，如取消分片上传、查询分片上传等。
            $uploadId = $ossClient->initiateMultipartUpload($bucket, $object);
        } catch (OssException $e) {
            return array('code'=>400,'msg'=>$e->getMessage());
        }

        $partSize = 10 * 1024 * 1024;
        $uploadFileSize = filesize($filePath);
        $pieces = $ossClient->generateMultiuploadParts($uploadFileSize, $partSize);
        $responseUploadPart = array();
        $uploadPosition = 0;
        $isCheckMd5 = true;
        foreach ($pieces as $i => $piece) {
            $fromPos = $uploadPosition + (integer)$piece[$ossClient::OSS_SEEK_TO];
            $toPos = (integer)$piece[$ossClient::OSS_LENGTH] + $fromPos - 1;
            $upOptions = array(
                // 上传文件。
                $ossClient::OSS_FILE_UPLOAD => $filePath,
                // 设置分片号。
                $ossClient::OSS_PART_NUM => ($i + 1),
                // 指定分片上传起始位置。
                $ossClient::OSS_SEEK_TO => $fromPos,
                // 指定文件长度。
                $ossClient::OSS_LENGTH => $toPos - $fromPos + 1,
                // 是否开启MD5校验，true为开启。
                $ossClient::OSS_CHECK_MD5 => $isCheckMd5,
            );
            // 开启MD5校验。
            if ($isCheckMd5) {
                $contentMd5 = OssUtil::getMd5SumForFile($filePath, $fromPos, $toPos);
                $upOptions[$ossClient::OSS_CONTENT_MD5] = $contentMd5;
            }
            try {
                // 上传分片。
                $responseUploadPart[] = $ossClient->uploadPart($bucket, $object, $uploadId, $upOptions);
            } catch (OssException $e) {
                return array('code'=>400,'msg'=>$e->getMessage());
            }
        }
        $uploadParts = array();
        foreach ($responseUploadPart as $i => $eTag) {
            $uploadParts[] = array(
                'PartNumber' => ($i + 1),
                'ETag' => $eTag,
            );
        }

        try {
            $result = $ossClient->completeMultipartUpload($bucket, $object, $uploadId, $uploadParts);
            return $result;
        } catch (OssException $e) {
            return array('code'=>400,'msg'=>$e->getMessage());
        }
    }
    //阿里云oss图片生成缩略图
    public function ossCreateThumbImg($file,$fileName,$config,$thumbSize){
        //得到要存储oss那边的原图路径及后缀
        $fileNameStr = explode(".",$fileName);
        $imageExt = end($fileNameStr);
        unset($fileNameStr[count($fileNameStr)-1]);

        //实例化对象 将配置传入
        $ossClient = new OssClient($config['aliyun_keyid'],
            $config['aliyun_keysecret'], $config['aliyun_endpoint']);

        //先在本地裁剪，然后上传oss后再删除本地图片
        //图片存的路径
        $imgUrl= '../public/static/uploads/wallpaper';
        $photo = '';$imgName='';
        if(!empty($file)){
            $info = $file->validate(['size'=>10*1024*1024,'ext'=>'jpg,png,gif,jpeg'])->rule('uniqid')->move($imgUrl);
            if($info){
                // 成功上传后 获取上传信息
                //获取图片的名字
                $imgName = $info->getFilename();
                //获取图片的路径
                $photo=$imgUrl . "/" . $imgName;
            }else{
                // 上传失败获取错误信息
                throw new Exception($file->getError());
            }
        }

        if($photo){
            foreach ($thumbSize as $v){
                //要生成的缩略图路径
                $fileName = implode(".",$fileNameStr) .'@' . $v. '.' . $imageExt;
                if($imageExt == 'gif'){
                    //原图存储一份到oss
                    //执行阿里云上传
                    $ossClient->uploadFile($config['aliyun_buckey'],
                        $fileName, $photo);
                }
                else{
                    $image = Image::open($photo);
                    $thumbName = $imgUrl . "/" .$v.'-'. $imgName;
                    $thumbSize = explode("x",$v);
                    $image->thumb($thumbSize[0],$thumbSize[1])->save($thumbName);
                    $ossClient->uploadFile($config['aliyun_buckey'],
                        $fileName, $thumbName);

                    $fileDel = str_replace("../public",'',$thumbName);
                    @unlink($_SERVER['DOCUMENT_ROOT'] . $fileDel);
                }
            }
            //删除旧数据
            $fileDel = str_replace("../public",'',$photo);
            @unlink($_SERVER['DOCUMENT_ROOT'] . $fileDel);

        }
    }
    /////////////////////////////////////////////////////////////////////

    ///////////////////////////////////////////
    //本地上传
    public function localStorageSave($config){
        try{

            //接收上传的文件
            $fileExt = Request::param('fileExt','images');//默认传图片
            $type = Request::param('fileType',0);//上传素材类型，默认0-不处理缩略图，其他的有缩略图数组才数据elyk
            $file = Request::file('file');
            if(!isset($this->fileExt[$fileExt])){throw new Exception('后缀错误啦');}
            $originName = '';
            $ext = pathinfo($file->getInfo('name'), PATHINFO_EXTENSION);
            //图片存的路径
            $imgUrl= $this->fileDirect .  date("Y/m/d");
            if(!empty($file)){
                $originName = $file->getInfo('name');
                $info = $file->validate(['size'=>20*1024*1024,'ext'=>$this->fileExt[$fileExt]])->rule('uniqid')->move($imgUrl);
                $error = $file->getError();
                //验证文件后缀后大小
                if(!empty($error)){
                    throw new Exception($file->getError());
                }
                if($info){
                    // 成功上传后 获取上传信息
                    //获取图片的名字
                    $imgName = $info->getFilename();
                    //获取图片的路径
                    $photo=$imgUrl . "/" . $imgName;

                }else{
                    // 上传失败获取错误信息
                    throw new Exception($file->getError());
                }
            }else{
                $photo = '';
            }
            if($photo !== ''){
                //判断是否为gif图，不是才判断是否要走缩略图
                if(strtolower($ext) != 'gif'){
                    if(isset($this->_thumb_size[$type])){
                        $this->newCreateThumbImg($photo,$this->_thumb_size[$type]);
                    }
                }

                //$videUrl 类型1、3、4、5为图片，若是gif则为静态图，2为视频连接
                //$photo 类型 1 3 4 5为原图，2为视频封面图
                //$thumb_img 类型 1 2 3为裁剪图，展示正方形图片，4 5为原图
                $videUrl = str_replace("../public",'',$photo);
                $thumb_img = '';
                //处理视频封面图，这里处理视频和gif图
                if($type == 2){
                    $videoImg = $this->GetCoveImg($config['save_way'],$photo,$config);
                    $photo = "../public".$videoImg;
                }
                if(strtolower($ext) == 'gif'){
                    $videoImg = $this->GetCoveImg($config['save_way'],$photo,$config);
                    $videUrl = $videoImg;//gif的静态图放在video_url里
                }

                //todo 生成壁纸、背景图的剪切图
                if(in_array($type,[1,2,3])){
                    $thumb_img = $this->getSpecialThumbImg($config['save_way'],$photo,$config);
                }else{
                    $thumb_img = str_replace("../public",'',$photo);
                }

                $photo = str_replace("../public",'',$photo);
                if($config['is_editor']){
                    $photo = $config['mini_domain'].$photo;
                }
                return json(array('error'=>0,'code'=>1,'msg'=>'上传成功','path'=>$photo,'photo'=>$photo,'url'=>$photo,'state'=>'SUCCESS','origin_name'=>$originName,'title'=>$originName,'video_url'=>$videUrl,'thumb_img'=>$thumb_img));
            }else{
                return json(array('code'=>400,'error'=>400,'msg'=>'上传失败','path'=>'','url'=>'','state'=>'ERROR','title'=>'','video_url'=>''));
            }
        }catch (Exception $exception){
            return json(array('code'=>400,'error'=>400,'msg'=>$exception->getMessage(),'path'=>'','url'=>'','state'=>'ERROR','title'=>'','e'=>$exception->getMessage()));
        }
    }
    //本地图片生成缩略图
    protected function newCreateThumbImg($originImg,$thumbSize){
        $newImg = [];
        $fileNameStr = explode(".",$originImg);
        $imageExt = end($fileNameStr); unset($fileNameStr[count($fileNameStr)-1]);


        if('gif' === $imageExt){
            //gif 直接复制原图
            foreach ($thumbSize as $v){
                $newImgName = implode(".",$fileNameStr) . '@' . $v . '.' . $imageExt;
                copy($originImg,$newImgName);
                $newImg[] = $newImgName;
            }
        }
        else{
            //对原图进行比例裁剪
            foreach ($thumbSize as $v){
                $image = \think\Image::open($originImg);
                // 按照原图的比例生成一个最大为150*150的缩略图并保存为thumb.png
                $newImgName = implode(".",$fileNameStr) . '@' . $v . '.' . $imageExt;
                $v2 = explode("x",$v);
                $image->thumb($v2[0], $v2[1])->save($newImgName);
                $newImg[] = $newImgName;
            }
        }

        return $newImg;

    }
    ///////////////////////////////////////////
    ///
    ///
    //////////////////////////////////////////////////
    /// 上传七牛云
    public function uploadFileQiniu($config){
        $fileExt = Request::param('fileExt','images');//默认传图片
        $file = request()->file('file');  //获取到上传的文件
        $type = Request::param('fileType',0);//上传素材类型，默认0-不处理缩略图，其他的有缩略图数组才数据elyk
        $originName = $file->getInfo('name');
        $ext = pathinfo($file->getInfo('name'), PATHINFO_EXTENSION);
        // 尝试执行
        try {
            $path = $file->getRealPath();
            if(!isset($this->fileExt[$fileExt])){throw new Exception('后缀错误啦');}
            if(!in_array(strtolower($ext),explode(",",$this->fileExt[$fileExt]))){throw new Exception($ext.'后缀错误');}
            $fileName = 'wallpaper/img/'.date("Y/m/d") .'/'. uniqid() . '.' . $ext;

            $auth = new Auth($config['qiniu_keyid'], $config['qiuniu_keysecret']);
            $token = $auth->uploadToken($config['qiniu_bucket']);
            $upload = new UploadManager();
            list($ret, $err) = $upload->putFile($token, $fileName, $path);
            if($err){throw new Exception('七牛上传失败');}

            $path = $config['qiniu_new_domain'].'/'.$ret['key'];

            //生成缩略图
            if(strtolower($ext) != 'gif'){
                if(isset($this->_thumb_size[$type])){
                    $this->ossQiniuCreateThumbImg($file,$fileName,$config,$this->_thumb_size[$type]);
                }
            }

            //todo 处理视频封面图、gif图静态封面图
            $videUrl = $path;
            if($type == 2){
                //ffmpeg只能处理本地文件，所以需要将该文件临时上传到本地后，进行切分然后再删除本地文件
                $imgUrl= $this->fileDirect .  date("Y/m/d");
                if(!empty($file)){
                    $originName = $file->getInfo('name');
                    $info = $file->validate(['size'=>10*1024*1024,'ext'=>$this->fileExt[$fileExt]])->rule('uniqid')->move($imgUrl);
                    $error = $file->getError();

                    //验证文件后缀后大小
                    if(!empty($error)){
                        throw new Exception($file->getError());
                    }
                    if($info){
                        // 成功上传后 获取上传信息
                        //获取图片的名字
                        $imgName = $info->getFilename();
                        //获取图片的路径
                        $photo=$imgUrl . "/" . $imgName;

                    }else{
                        // 上传失败获取错误信息
                        throw new Exception($file->getError());
                    }
                }else{
                    $photo = '';
                }
                if($photo == ''){throw new Exception('local img fail');}
                $videoImg = $this->GetCoveImg($config['save_way'],$photo,$config);
                $path = $videoImg;

                //删除旧数据
                $fileDel = str_replace("../public",'',$photo);
                @unlink($_SERVER['DOCUMENT_ROOT'] . $fileDel);
            }
            if(strtolower($ext) == 'gif'){
                //ffmpeg只能处理本地文件，所以需要将该文件临时上传到本地后，进行切分然后再删除本地文件
                $imgUrl= $this->fileDirect .  date("Y/m/d");
                if(!empty($file)){
                    $originName = $file->getInfo('name');
                    $info = $file->validate(['size'=>10*1024*1024,'ext'=>$this->fileExt[$fileExt]])->rule('uniqid')->move($imgUrl);
                    $error = $file->getError();

                    //验证文件后缀后大小
                    if(!empty($error)){
                        throw new Exception($file->getError());
                    }
                    if($info){
                        // 成功上传后 获取上传信息
                        //获取图片的名字
                        $imgName = $info->getFilename();
                        //获取图片的路径
                        $photo=$imgUrl . "/" . $imgName;

                    }else{
                        // 上传失败获取错误信息
                        throw new Exception($file->getError());
                    }
                }else{
                    $photo = '';
                }
                if($photo == ''){throw new Exception('local img fail');}
                $videoImg = $this->GetCoveImg($config['save_way'],$photo,$config);
                $videUrl = $videoImg;

                //删除旧数据
                $fileDel = str_replace("../public",'',$photo);
                @unlink($_SERVER['DOCUMENT_ROOT'] . $fileDel);
            }


            //todo 生成壁纸、背景图的剪切图
            if(in_array($type,[1,2,3])){
                $thumb_img = $this->getSpecialThumbImg($config['save_way'],$path,$config);
            }else{
                $thumb_img = $path;
            }

            return json(array('error'=>0,'code'=>1,'msg'=>'上传成功','path'=>$path,'photo'=>$path,'url'=>$path,'origin_name'=>$originName,'state'=>'SUCCESS','title'=>$path,'video_url'=>$videUrl,'thumb_img'=>$thumb_img));
        } catch (Exception $e) {
            return json(array('error'=>404,'code'=>400,'msg'=>$e->getMessage(),'photo'=>'','url'=>'','state'=>'ERROR','title'=>'','e'=>$e->getMessage()));
        }
    }
    //七牛云oss图片生成缩略图
    public function ossQiniuCreateThumbImg($file,$fileName,$config,$thumbSize){
        //得到要存储oss那边的原图路径及后缀
        $fileNameStr = explode(".",$fileName);
        $imageExt = end($fileNameStr);
        unset($fileNameStr[count($fileNameStr)-1]);

        $auth = new Auth($config['qiniu_keyid'], $config['qiuniu_keysecret']);
        $token = $auth->uploadToken($config['qiniu_bucket']);
        $upload = new UploadManager();

        //先在本地裁剪，然后上传oss后再删除本地图片
        //图片存的路径
        $imgUrl= '../public/static/uploads/wallpaper';
        $photo = '';$imgName='';
        if(!empty($file)){
            $info = $file->rule('uniqid')->move($imgUrl);
            if($info){
                // 成功上传后 获取上传信息
                //获取图片的名字
                $imgName = $info->getFilename();
                //获取图片的路径
                $photo=$imgUrl . "/" . $imgName;
            }else{
                // 上传失败获取错误信息
                throw new Exception($file->getError());
            }
        }

        if($photo){
            foreach ($thumbSize as $v){
                //要生成的缩略图路径
                $fileName = implode(".",$fileNameStr) .'@' . $v. '.' . $imageExt;
                if($imageExt == 'gif'){
                    //原图存储一份到oss
                    //执行七牛云上传
                    $upload->putFile($token, $fileName, $photo);
                }
                else{
                    $image = Image::open($photo);
                    $thumbName = $imgUrl . "/" .$v.'-'. $imgName;
                    $thumbSize = explode("x",$v);
                    $image->thumb($thumbSize[0],$thumbSize[1])->save($thumbName);

                    $upload->putFile($token, $fileName, $thumbName);

                    $fileDel = str_replace("../public",'',$thumbName);
                    @unlink($_SERVER['DOCUMENT_ROOT'] . $fileDel);
                }
            }
            //删除旧数据
            $fileDel = str_replace("../public",'',$photo);
            @unlink($_SERVER['DOCUMENT_ROOT'] . $fileDel);

        }
    }
    //////////////////////////////////////////////////

    /**
     * 视频切封面图
     * @param $storage 资源引擎
     * @param string $path 文件路径
     * @param $sourceConfig 文件资源配置
     */
    private function GetCoveImg($storage,$path = '',$sourceConfig){
        if($path == ''){
            return '';
        }
        $ffmpeg = FFMpeg::create(array(
            //程序安装目录，不加可能会无法运行
            'ffmpeg.binaries'  => Config::get('params.ffmpeg'),
            'ffprobe.binaries' =>  Config::get('params.ffprobe'),

        ));
        $videoname = $path;//视频地址
        $video = $ffmpeg->open($videoname);

        //判断是视频还是gif，视频切0。1帧，gif切0。01帧
        $second = 0.1;
        $fileNameStr = explode(".",$path);
        $imageExt = end($fileNameStr); unset($fileNameStr[count($fileNameStr)-1]);
        if($imageExt == 'gif'){$second  = 0.01;}
        $frame = $video->frame(TimeCode::fromSeconds($second));//获取第几帧

        $filename = uniqid().".jpg";//获取图片命名

        $frame->save($filename);//获取图片


        if (!is_dir($this->fileDirect .  date("Y/m/d"))){//是否已有文件夹

            mkdir($this->fileDirect .  date("Y/m/d"));//没有则新建文件夹

        }

        $file = $this->fileDirect .  date("Y/m/d").'/'.$filename;
        copy($filename,$file); //拷贝到新目录

        //删除复制前的素材
        @unlink($_SERVER['DOCUMENT_ROOT'] .'/'. $filename);

        if($storage == 1){//阿里云上传
            //将图片上传到oss然后返回
            //实例化对象 将配置传入
            $ossClient = new OssClient($sourceConfig['aliyun_keyid'],
                $sourceConfig['aliyun_keysecret'], $sourceConfig['aliyun_endpoint']);

            $fileNameOss = 'wallpaper/img/'.date("Y/m/d") .'/'. $filename;

            $result = $ossClient->uploadFile($sourceConfig['aliyun_buckey'],
                $fileNameOss, $file);


            $path = '';
            if ($result['info']['url']) {
                if (!empty($sourceConfig['aliyun_new_domain'])) {
                    $path = str_replace($sourceConfig['aliyun_old_domain'], $sourceConfig['aliyun_new_domain'], $result['info']['url']);
                } else {
                    $path = str_replace('http', 'https', $result['info']['url']);
                }
            }
            //删除旧数据
            $fileDel = str_replace("../public",'',$file);
            @unlink($_SERVER['DOCUMENT_ROOT'] . $fileDel);
            return $path;
        }
        elseif($storage == 2){//七牛云上传
            //将图片上传到oss然后返回
            //实例化对象 将配置传入
            $fileNameOss = 'wallpaper/img/'.date("Y/m/d") .'/'. $filename;
            $auth = new Auth($sourceConfig['qiniu_keyid'], $sourceConfig['qiuniu_keysecret']);
            $token = $auth->uploadToken($sourceConfig['qiniu_bucket']);
            $upload = new UploadManager();
            list($ret, $err) = $upload->putFile($token, $fileNameOss, $file);
            $path = '';
            if(!$err){
                $path = $sourceConfig['qiniu_new_domain'].'/'.$ret['key'];
            }

            //删除旧数据
            $fileDel = str_replace("../public",'',$file);
            @unlink($_SERVER['DOCUMENT_ROOT'] . $fileDel);
            return $path;
        }
        else{
            return str_replace("../public",'',$file);
        }
    }

    /**
     * 特殊类型切正方形图片
     * @param $storage 资源引擎
     * @param string $path 文件路径
     * @param $sourceConfig 文件资源配置
     */
    private function getSpecialThumbImg($storage,$path = '',$sourceConfig){
        if($path == ''){
            return '';
        }

        $fileNameStr = explode(".",$path);
        $imageExt = end($fileNameStr); unset($fileNameStr[count($fileNameStr)-1]);
        if($imageExt == 'gif'){return str_replace("../public",'',$path);}

        if (!is_dir($this->fileDirect .  date("Y"))){//是否已有文件夹
            mkdir($this->fileDirect .  date("Y"));//没有则新建文件夹
        }

        //判断是否为远程图片，是的话需要存储到本地，做裁剪后删除
        $filename = uniqid().'_thumb.'.$imageExt;
        $localFile = $this->fileDirect .  date("Y").'/local_'.$filename;
        if($storage != 0){
            $img = file_get_contents($path);
            file_put_contents($localFile, $img);
            $path = $localFile;
        }

        $file = $this->fileDirect .  date("Y").'/'.$filename;
        $image = \think\Image::open($path);
        $image->thumb(300,300,Image::THUMB_CENTER)->save($file);

        if($storage == 1){//阿里云
            //将图片上传到oss然后返回
            //实例化对象 将配置传入
            $ossClient = new OssClient($sourceConfig['aliyun_keyid'],
                $sourceConfig['aliyun_keysecret'], $sourceConfig['aliyun_endpoint']);

            $fileNameOss = 'wallpaper/img/'.date("Y/m/d") .'/'. $filename;

            $result = $ossClient->uploadFile($sourceConfig['aliyun_buckey'],
                $fileNameOss, $file);


            $path = '';
            if ($result['info']['url']) {
                if (!empty($sourceConfig['aliyun_new_domain'])) {
                    $path = str_replace($sourceConfig['aliyun_old_domain'], $sourceConfig['aliyun_new_domain'], $result['info']['url']);
                } else {
                    $path = str_replace('http', 'https', $result['info']['url']);
                }
            }
            //删除旧数据
            $fileDel = str_replace("../public",'',$file);
            @unlink($_SERVER['DOCUMENT_ROOT'] . $fileDel);
            $fileDel = str_replace("../public",'',$localFile);
            @unlink($_SERVER['DOCUMENT_ROOT'] . $fileDel);
            return $path;
        }
        elseif($storage == 2){//七牛云
            //将图片上传到oss然后返回
            //实例化对象 将配置传入
            $fileNameOss = 'wallpaper/img/'.date("Y/m/d") .'/'. $filename;
            $auth = new Auth($sourceConfig['qiniu_keyid'], $sourceConfig['qiuniu_keysecret']);
            $token = $auth->uploadToken($sourceConfig['qiniu_bucket']);
            $upload = new UploadManager();
            list($ret, $err) = $upload->putFile($token, $fileNameOss, $file);
            $path = '';
            if(!$err){
                $path = $sourceConfig['qiniu_new_domain'].'/'.$ret['key'];
            }

            //删除旧数据
            $fileDel = str_replace("../public",'',$file);
            @unlink($_SERVER['DOCUMENT_ROOT'] . $fileDel);
            $fileDel = str_replace("../public",'',$localFile);
            @unlink($_SERVER['DOCUMENT_ROOT'] . $fileDel);
            return $path;
        }
        else{
            return str_replace("../public",'',$file);
        }
    }
}
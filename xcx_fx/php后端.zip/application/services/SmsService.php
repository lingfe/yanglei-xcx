<?php


namespace app\services;


use sms\SmsSingleSender;
use think\facade\Config;
use think\facade\Session;

class SmsService
{
    public function sendcode($phoneNumbers,$code){
        //腾讯短信验证码
        // 短信应用 SDK AppID
        $appid = Config::get('params.sms.appid'); // SDK AppID 以1400开头
        // 短信应用 SDK AppKey
        $appkey = Config::get('params.sms.appkey');
        // 需要发送短信的手机号码
        // 短信模板 ID，需要在短信控制台中申请
        $templateId = Config::get('params.sms.template');  // NOTE: 这里的模板 ID`7839`只是示例，真实的模板 ID 需要在短信控制台中申请
        $smsSign = Config::get('params.sms.sign_name'); // NOTE: 签名参数使用的是`签名内容`，而不是`签名ID`。这里的签名"腾讯云"只是示例，真实的签名需要在短信控制台申请

        try {
            $params = [$code,Config::get('params.sms.expire_time')];
            $ssender = new SmsSingleSender($appid, $appkey);
            $result = $ssender->sendWithParam("86", $phoneNumbers, $templateId, $params, $smsSign, "", "");
            $rsp = json_decode($result);
            return json(["result"=>$rsp->result,"code"=>$code]);
        } catch(\Exception $e) {
            return json(["result"=>1,"code"=>$code,'e'=>$e->getMessage()]);
        }
    }

    //验证邮件验证码是否正确
    public function check($code,$sessionName){
        $secode = Session::get($sessionName);
        if (empty($code) || empty($secode)) {
            return false;
        }
        // session 过期
        if (time() - $secode['verify_time'] > $secode['verify_expire']) {
            Session::delete($sessionName);
            return false;
        }

        if ($code == $secode['verify_code']) {
            Session::delete($sessionName);
            return true;
        }
    }
}
<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/5/23
 * Time: 16:48
 */

namespace app\http\exception;


use Exception;
use think\exception\Handle;
use think\facade\Request;

class Http extends Handle
{
    public function render(Exception $exception)
    {
        $params = [];
        $params['projectName'] = "oct-youban";
        $params['level'] = 5;
        $params['title'] = "500：".$exception->getMessage();
        $params['value'] = $exception->getCode();
        $params['message'] = $exception->getFile()."：".$exception->getLine();
        $params['bizcode'] = 8;
        $params['subcode'] = 8001;

        writeLog('======================','系统异常内容');
        writeLog(Request::get(),'系统异常内容');
        writeLog(Request::post(),'系统异常内容');
        writeLog($_SERVER,'系统异常内容');
        writeLog($params,'系统异常内容');
        writeLog('======================','系统异常内容');
        if(Request::isAjax()){
            wapAjaxReturn(400,$exception->getMessage(),$params);
        }else{
//            exit(header('Location:'.url('error')));
        }
        return parent::render($exception);

    }

}
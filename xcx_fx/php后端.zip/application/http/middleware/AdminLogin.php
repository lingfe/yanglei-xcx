<?php

namespace app\http\middleware;


use think\facade\Request;
use think\facade\Session;

class AdminLogin
{
    public $_notNeedLogin = [
        'admin/login','admin/login/deal','admin/analysis'
    ];
    public function handle($request, \Closure $next)
    {

        /*
         * 因为redis公用了同一套，所以直接判断session信息
         *
         * */
        //获取session的登陆信息 判断是否有
        $userId = Session::get('userId');
        if(empty($userId) && !in_array(Request::path(),$this->_notNeedLogin)){
            //判断是异步请求还是同步请求，异步以json返回

            if(Request::isAjax()){
                wapAjaxReturn(10020,'请登陆');
            }
            //跳转登陆
            return redirect('/admin/login');
        }

        return $next($request);

    }

}

<?php

namespace app\http\middleware;

use app\common\model\Config;
use app\common\model\Project;
use think\Exception;

/**
 * 用于验证当前请求是否为小程序端请求，判断appid
 * Class MiniProgram
 * @package app\http\middleware
 */
class MiniProgram
{
    public function handle($request, \Closure $next)
    {
        $httpReferer = isset($_SERVER['HTTP_REFERER'])?$_SERVER['HTTP_REFERER']:'';
//        if(empty($httpReferer)){throw new Exception('当前是非法请求');}

        $config = Config::getAllConfig();
        $canGo = false;
        if(!empty($config['ks_appid'])){
            if(is_int(strpos($httpReferer,$config['ks_appid']))){$canGo= true;};
        }
        if(!empty($config['wx_appid'])){
            if(is_int(strpos($httpReferer,$config['wx_appid']))){$canGo= true;};
        }
        if(!empty($config['dy_appid'])){
            if(is_int(strpos($httpReferer,$config['dy_appid']))){$canGo= true;};
        }
        if(!empty($config['qq_appid'])){
            if(is_int(strpos($httpReferer,$config['qq_appid']))){$canGo= true;};
        }

//        if(!$canGo){throw new Exception('你不按正常的来访问');}

        return $next($request);
    }
}

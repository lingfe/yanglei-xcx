<?php


namespace app\http\middleware;


use app\common\model\Expert;
use think\Exception;
use think\facade\Config;
use think\facade\Request;
use think\facade\Session;
use think\facade\Url;

class WechatLogin
{
    //不用校验登陆路由
    public $notValidate = array('index/wecaht/callback','userLogin/deal','userLogin','userLoginPwd'
    ,'userRegister');

    public $canEnter = array('user/improve','logout');//不受限达人信息审核的功能入口
    public function handle($request, \Closure $next)
    {
        $config = \app\common\model\Config::getAllConfig();
        if(empty($config['open_expert'])){throw  new Exception('系统已关闭使用');}

        $wechatUserId = Session::get('wechatUserId');
        if(empty($wechatUserId) && !in_array(Request::path(),$this->notValidate)){
            $locationUrl = Request::isAjax()?'':urlencode(urlencode($request->url(true)));
            //微信授权处理逻辑
//            $wechatInfo['appid'] = Config::get('params.user_appid');
//            $wechatInfo['appsecret'] = Config::get('params.user_appsecret');
//            //跳转微信授权接口
//            //-------生成唯一随机串防CSRF攻击
//            $state  = md5(uniqid(rand(), TRUE));
//            $callbackUrl = urlencode(Url::build('wecaht/callback',"",'',true)."?callbackUrl={$locationUrl}");
//            $wxurl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=".$wechatInfo['appid']."&redirect_uri=".$callbackUrl."&response_type=code&scope=snsapi_userinfo&state=".$state."#wechat_redirect";
//            header('Location:'.$wxurl);
//            exit;

            //密码登陆处理逻辑
//             return redirect('/userLoginPwd?callbackUrl='.$locationUrl);
             return redirect('/userLoginPwd');
            exit;
        }
        if(Request::isAjax()){
            if(!in_array(Request::path(),$this->notValidate)){//需要校验登陆
                $user = Expert::where(['user_id'=>Session::get('wechatUserId')])->find();
                if($user == null){wapAjaxReturn(400,'无法操作');}
                if(!in_array(Request::path(),$this->canEnter)){//不受达人限制
                    if(empty($user['wechat_num'])){wapAjaxReturn(400,'请完善达人信息');}
                    if($user['is_reviewed'] == 0){wapAjaxReturn(400,'当前您的账号正在审核中');}
                    if($user['is_reviewed'] == 2){wapAjaxReturn(400,'达人信息没通过，请重新编辑');}
                    if($user['is_freeze'] == 1){wapAjaxReturn(400,'当前您的账号被封，无法操作');}
                }
            }
        }
        return $next($request);
    }
}
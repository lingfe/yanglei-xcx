<?php
/**
 * Created by PhpStorm.
 * User: Kyle
 * Date: 2019/7/17
 * Time: 12:11
 */

namespace app\http\middleware;


use think\facade\Request;
use think\facade\Session;
//后台登陆校验
class LoginExistValidate
{
    public function handle($request, \Closure $next)
    {
        //获取session的登陆信息 判断是否有
        $userId = Session::get('username');
        if(!empty($userId)){
            //跳转登陆
            return redirect($_SERVER['REQUEST_SCHEME']."://".$_SERVER['HTTP_HOST'].'/admin');
        }
        return $next($request);
    }
}
<?php

namespace app\http\middleware;

use think\facade\Config;

class Cors
{
    public function handle($request, \Closure $next)
    {

        $response = $next($request);
        $origin = isset($_SERVER['HTTP_ORIGIN'])? $_SERVER['HTTP_ORIGIN'] : '';
        if(!empty($origin)){
            $response->header('Access-Control-Allow-Origin', $origin);
        }else{
            $response->header('Access-Control-Allow-Origin','*');
        }

        $response->header('Access-Control-Allow-Methods', 'GET, POST, PATCH, PUT, OPTIONS');
        $response->header('Access-Control-Allow-Headers', 'x-requested-with,content-type');
        $response->header('Access-Control-Max-Age', '3628800');
        $response->header('Access-Control-Allow-Credentials', 'true');
        $response->header('Content-Type', 'application/json;charset=utf-8');
        return $response;
    }
}

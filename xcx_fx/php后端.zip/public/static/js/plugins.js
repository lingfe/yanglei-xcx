(function($) {
	$.extend({
		$toast: function(text, time) {
			let toastEl = null;
			let toastTime = null;

			function run() {
				let isShow = false;
				const delay = time || 2000;

				if (isShow) {
					toastEl.innerHTML = text;
				} else {
					toastEl = document.createElement('div');
					toastEl.className = 'pu-toast';
					toastEl.innerHTML = `<span>${text}</span>`;
					$(document.body).append(toastEl);
				}
				isShow = true;
				if (toastTime) clearTimeout(toastTime);
				toastTime = setTimeout(function() {
					isShow = false;
					clearTimeout(toastTime);
					$(toastEl).remove();
					toastEl = null;
				}, delay);
			}
			return run();
		}
	});
})(window.jQuery);
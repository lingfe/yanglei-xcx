// 复制函数
function Copy(str) {
    var save = function(e) {
        e.clipboardData.setData('text/plain', str);
        e.preventDefault();
    };
    document.addEventListener('copy', save);
    document.execCommand('copy');
    document.removeEventListener('copy', save);
    layer.msg('复制成功',{icon:1})
}


<?php
//000002592000
 exit();?>
{"mini_domain":"https:\/\/cs.dyhot.cn","save_way":"1","aliyun_buckey":"yunyunqutu","aliyun_keyid":"LTAI5tGVWWkLxQDpt3p11zuv","aliyun_keysecret":"5oOxCZ9t94sBqYKtS57WeiXelxCZ4c","aliyun_endpoint":"oss-cn-guangzhou.aliyuncs.com","aliyun_old_domain":"http:\/\/yunyunqutu.oss-cn-guangzhou.aliyuncs.com","aliyun_new_domain":"https:\/\/yunyunqutu.oss-cn-guangzhou.aliyuncs.com"}